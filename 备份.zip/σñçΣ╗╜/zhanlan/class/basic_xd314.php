<?php

const SIGN_XD = '';
class basic_xd314{//-----ϵͳ�����ļ������ڹ���ҳ����ṩ���ݣ�
	
	public function a(){//------------------------------------------------------------------------------------------------------------------------------------------------ʵ��

			return "ok";
		
	}
public function get_pluginvar($plugin,$key){//----------------------------------------------------------------------------------��ȡ�������
  $array1=$mysql_xd314->search('pre_common_plugin'," WHERE    identifier='".$plugin."'")[0];//------------------------------------------------------------��������($TableName����,$object���Ҷ���,$operation��������)
  $array=$mysql_xd314->search('pre_common_pluginvar'," WHERE    pluginid=".$array1[pluginid]."    AND   variable='".$key."'")[0];//------------------------------------------------------------��������($TableName����,$object���Ҷ���,$operation��������)
	return $array[value];	
	}
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------���ݿ���
public function datadase_create(){//-----------------------------------------------------------------------------------�������ݿ�
			$a=DB::query("CREATE TABLE pre_xd_demand(
	`yid` int(11) NOT NULL,`x` text NULL,`x1` text NULL,`x2` text NULL,`x3` text NULL,`x4` text NULL,`x5` text NULL,`x6` text NULL,`x7` text NULL,`x8` text NULL,`x9` text NULL,`x10` text NULL,`x11` text NULL,`x12` text NULL,`x13` text NULL,`x14` text NULL,`x15` text NULL,`x16` text NULL,PRIMARY KEY (`yid`)
) ENGINE=MyISAM
DEFAULT CHARACTER SET=utf8
CHECKSUM=0
DELAY_KEY_WRITE=0;");
}

public function shu($t){//-----------------------------------------------------------------------------------------------------------��������  $t
 if($t>=10000){$t1=floor($t/10000).'��';
}else if($t==''){$t1=0;
}else if($t>=100000000){$t1=floor($t/100000000).'��';
}else{$t1=$t;}
return  	$t1;
}

public function timearray($time) //--------------------------------------------------------------------------------------------------------------------------��ȡʱ��($timeΪʱ���) ���������ʽ���طֱ��Ӧ������ʱ����
{  
    $Y=date("Y",$time);  
    $m=date("m",$time);  
    $d=date("d",$time);  
    $H=date("H",$time);  
    $i=date("i",$time);  
    $s=date("s",$time);  
    return array($Y,$m,$d,$H,$i,$s);             
}  




public  function mult_iconv($data,$in_charset="gbk",$out_charset="utf-8")//------------------------------------------------------ת��
{
    if(substr($out_charset,-8)=='//IGNORE'){
        $out_charset=substr($out_charset,0,-8);
    }
    if(is_array($data)){
        foreach($data as $key => $value){
            if(is_array($value)){
                $key=iconv($in_charset,$out_charset.'//IGNORE',$key);
                $rtn[$key]=mult_iconv($in_charset,$out_charset,$value);
            }elseif(is_string($key) || is_string($value)){
                if(is_string($key)){
                    $key=iconv($in_charset,$out_charset.'//IGNORE',$key);
                }
                if(is_string($value)){
                    $value=iconv($in_charset,$out_charset.'//IGNORE',$value);
                }
                $rtn[$key]=$value;
            }else{
                $rtn[$key]=$value;
            }
        }
    }elseif(is_string($data)){
        $rtn=iconv($in_charset,$out_charset.'//IGNORE',$data);
    }else{
        $rtn=$data;
    }
    return $rtn;
}

public  function  shangchuanimg(array $file){//--------------------------------------------------------------------�ϴ�ͼƬ    ������array $_G,array $file,$name
//echo '<script language="JavaScript">alert("'.$file['tmp_name'].'");</script>';
$arrType=array('image/jpg','image/gif','image/png','image/bmp','image/jpeg');
$max_size='10000000000';      // ����ļ����ƣ���λ��byte��
    $upfile='../hl_img/'.date('Y',time());  //ͼƬĿ¼·��
     $upfile1='../hl_img1/'.date('Y',time());
   if($_SERVER['REQUEST_METHOD']=='POST'){ //�ж��ύ��ʽ�Ƿ�ΪPOST
     if(!is_uploaded_file($file['tmp_name'])){ //�ж��ϴ��ļ��Ƿ����
    return 'not use post';
    exit;
    }
  if($file['size']>$max_size){  //�ж��ļ���С�Ƿ����500000�ֽ�
   return 'over max size';
    exit;
   } 
  if(!in_array($file['type'],$arrType)){  //�ж�ͼƬ�ļ��ĸ�ʽ
   return 'not type';
     exit;
   }
  if(!file_exists($upfile)){  // �жϴ���ļ�Ŀ¼�Ƿ����
   mkdir($upfile,0777,true);
   }
       if(!file_exists($upfile1)){  // �жϴ���ļ�Ŀ¼�Ƿ����
           mkdir($upfile1,0777,true);
       }
$imageSize=getimagesize($file['tmp_name']);
$img=$imageSize[0].'*'.$imageSize[1];
$c=strrev($file['name']);
$ftype=explode('.',$c); 
$ftype=strrev($ftype[0]);
   if($ftype=="PNG"){$ftype="png";}
 if($ftype=="JPG"){$ftype="jpg";}
$fname=time().'-'.$file['size'].'.'.$ftype;
   $picName=$upfile.'/'.$fname;
   if(file_exists($picName)){
    return 'file_exists';
    exit;
     }
   if(!move_uploaded_file($file['tmp_name'],$picName)){
   return move_uploaded_file($file['tmp_name'],$picName);
     exit;
   }
      }
    
   
    $path=$upfile1.'/'.$fname;
    list($width,$height) = getimagesize($picName);//��ȡԭͼ��ߴ�Ŀ�����߶�
    $c1=201111;//�趨��ͼƬ�������ػ�
    if($width*$height>=$c1){$c=$width/$height; $c=$c1/$c;$_height=sqrt($c);$_width=$c1/$_height;$_height=round($_height);$_width=round($_width);
    }else{$_height=$width;$_width=$height;}
    $_img = imagecreatetruecolor($_width,$_height);//Ϊ��ͼ�񴴽�һ������
    if($ftype=="png"){ $img = imagecreatefrompng($picName);}
    else if($ftype=="jpg"){ $img = imagecreatefromjpeg($picName);}
    else if($ftype=="gif"){ $img = imagecreatefromgif($picName);}
    else if($ftype=="jpeg"){ $img = imagecreatefromjpeg($picName);}
    else if($ftype=="wbmp"){ $img = imagecreatefromwbmp($picName);}
    imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
    imagejpeg($_img,$path,0, 100);
    imagepng($_img,$path,0, 100);
    ImageDestroy( $_img);
    chmod($path, 0777);
    chmod($picName, 0777);
return  explode('hl_img/',$picName)[1];
}

  





}

?>

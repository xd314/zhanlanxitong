/**
*公用函数封装
*/
"use strict"
var xd314 = {
Height:window.screen.availHeight,
Width:window.screen.availWidth,
Id : {},
DATA : {
				method: 'POST',
				url: '',
				data: {},
				success: function (respone) {}
				},
AJAX: function(opt) {opt = opt || {};
  opt.method = opt.method.toUpperCase() || 'POST';
  opt.url = opt.url || '';
  opt.async = opt.data || null;
  opt.success = opt.success || function () { };
  var xmlHttp = null;
  if (XMLHttpRequest) {
    xmlHttp = new XMLHttpRequest();
  } else {
    xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
  }
  var params = [];
  for (var key in opt.data) {
    params.push(key + '=' + opt.data[key]);
  }
  var postData = params.join('&');
  console.log(postData);
  if (opt.method.toUpperCase() === 'POST') {
    xmlHttp.open(opt.method, opt.url, opt.async);
    xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
    xmlHttp.send(postData);
  } else if (opt.method.toUpperCase() === 'GET') {
    xmlHttp.open(opt.method, opt.url + '?' + postData, opt.async);
    xmlHttp.send(null);
  }
  xmlHttp.onreadystatechange = function () {
    if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
      console.log(xmlHttp.responseText);
      console.log('AJAX Success!');
      opt.success(JSON.parse(xmlHttp.responseText));
    }
  }
},

IdInit:function(idarray) {
var idarray1=new Array();
for (var key in idarray) {  
idarray1[idarray[key]]=document.getElementById(idarray[key]);
}
this.Id = idarray1;
},

Id1:function(value) {
return document.getElementById(value);
},
Class:function(cla) {
return document.getElementsByClassName(cla);
},


Show:function(txt,clo = true) {
  var x1 = document.getElementById('xd314_message');
  x1.innerHTML='<div style="position:fixed;top:90%;left:25%;z-index:99;border:1px solid #8E8E8E;border-radius:3px;background-color:#8E8E8E;width:50%;text-align:center;color:white;font-size:20px;">'+txt+'</div>';
  x1.style.display = 'block';
  if (clo == true) {
    setTimeout(function () {
      x1.style.display = 'none';
    },1000)
  }
},

HideShow:function() {
  document.getElementById('xd314_message').style.display = 'none';
},

GetState:function() {
  return window.location.search.split('?state=')[1];
},

Href:function(url, op = true) {
  if (op) {
    window.open(url);
  } else {
    window.location.href = url;
  }
},
Scroll:function(scrollID, scrollFunc) {
  if ((document.getElementById(scrollID).scrollHeight - document.getElementById(scrollID).clientHeight) == document.getElementById(scrollID).scrollTop) {
    scrollFunc(); 
  }
},
Cookie:function(key){
    var k=document.cookie.split(key+'=')[1];
    if(k==undefined){
        return 'undefined';
    }else{
        return k.split(';')[0];
    }
},
ShowInit:function(){
  var tempHTML = document.createElement("div");
  tempHTML.id = "xd314_message";
  tempHTML.style.display = "none";
  document.body.appendChild(tempHTML);
}
}

var tool=xd314;


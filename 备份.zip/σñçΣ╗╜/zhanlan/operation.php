<?php
header('Access-Control-Allow-Origin:*');
require_once('class/mysql_xd314.php');
$mysql_xd314=new  mysql_xd314;
if(!empty($_GET['type'])){$_POST['type']=$_GET['type'];}
switch ($_POST['type']){
case '1':
/*
    $a=$mysql_xd314->modify('pre_notes'," SET state=0 WHERE id=719");
$fso=opendir('');
$a=0;
while($flist=readdir($fso)){
    if($flist!="."&&$flist!=".."){
        $pimg[]=$flist;
        $a+=1;
    }
}
closedir($fso);
print_r($pimg);
*/
echo 'no on';
break;
case '2'://创建表格
$array=$mysql_xd314->search('pre_notes'," WHERE  id>=700 ORDER BY id DESC");

echo json_encode(array('data'=>$array));//data用户
break;   
case '3'://备份数据库

break;
default:     
break;
}
?>

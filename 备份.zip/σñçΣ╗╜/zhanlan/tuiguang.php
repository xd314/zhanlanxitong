<?php
header('Access-Control-Allow-Origin:*');
require_once('class/mysql_xd314.php');
require_once('class/basic_xd314.php');
$mysql_xd314=new  mysql_xd314;
$basic_xd314=new  basic_xd314;
switch ($_POST["caidan"]){
    case 'FanKuiTuiSong'://反馈推送信息。在页面和短信上分别通知
        $usertrack=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND   openid='".$_POST['openid']."'",' id,chpid,chpjiage,chpshuliang,chpname ');
        $usertrack1=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND state1=1 AND  openid='".$_POST['openid']."'",' id,chpid,chpname ');
        $usertrack2=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND  state1=2 AND openid='".$_POST['openid']."'",' id,chpid,chpname ');
        $usertrack3=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND  state1=3 AND openid='".$_POST['openid']."'",' id,chpid,chpname ');
        $usertrack4=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND state1=4 AND openid='".$_POST['openid']."'",' id,chpid,chpname ');
        $usertrack5=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND  state1=5 AND openid='".$_POST['openid']."'",' id,chpid,chpname ');
        
        if(count($usertrack4)>0){//用户已评价
            $track=$usertrack4;
            $FeedbackPush='e';
        }else if(count($usertrack3)>0){//用户已收到货物
            $track=$usertrack3;
            $FeedbackPush='d';
        }else if(count($usertrack2)>0){//商家已完成订单
            $track=$usertrack2;
            $FeedbackPush='c';
        }else if(count($usertrack1)>0){//用户已支付
            $track=$usertrack1;
            $FeedbackPush='b';
        }else if(count($usertrack)>0){//订单建立
            $track=$usertrack;
            $FeedbackPush='a';
        }else{
            $FeedbackPush='';
            $track=[];
        }
        
        
        echo json_encode(array('data'=>$FeedbackPush,'track'=>$track[0]['chpid']));
        break;
case 'shezhiliucheng'://设置流程
if(!empty($_POST['trackid'])&&!empty($_POST['liucheng'])){
    $a=$mysql_xd314->modify('pre_usertrack'," SET state1=".intval($_POST['liucheng'])." WHERE  id=".intval($_POST['trackid']));
    if(intval($_POST['liucheng'])==2){
    $usertrack=$mysql_xd314->search('pre_usertrack'," WHERE id=".intval($_POST['trackid']))[0];
    $user=$mysql_xd314->search('pre_user'," WHERE openid='".$usertrack['openid']."'");
    $post_data=array('caidan'=>'fasong1','phone'=>$user[0]['phone'],'moban'=>'SMS_157453045','name'=>$usertrack['chpname']);
    $code=json_decode(send_post('https://www.axd-t.com/dysms/msg.php',$post_data),true);
    }
            echo json_encode(array('state'=>'success'));
        }else{
            echo json_encode(array('state'=>'fail'));
        }
break;
case 'tgy'://推广员设置
if(!empty($_POST['id'])){
         $a=$mysql_xd314->modify('pre_user'," SET x=1 WHERE  id=".$_POST['id']);//x为1时为推广员
 echo json_encode(array('state'=>'success'));
}else{
 echo json_encode(array('state'=>'fail'));
}
 break;
case 'tgezhi':
if(!empty($_POST['zid'])){
$a=$mysql_xd314->modify('pre_usertrack'," SET state=2 WHERE  id=".$_POST['zid']);
 echo json_encode(array('state'=>'success'));
}else{
 echo json_encode(array('state'=>'fail'));
}
 break;
case 'twancheng':
if(!empty($_POST['zid'])){
         $a=$mysql_xd314->modify('pre_usertrack'," SET state=1 WHERE  id=".$_POST['zid']);
 echo json_encode(array('state'=>'success'));
}else{
 echo json_encode(array('state'=>'fail'));
}
 break;
case 'tshanchu':
if(!empty($_POST['zid'])){
         $a=$mysql_xd314->delete('pre_usertrack'," WHERE id=".$_POST['zid']);
 echo json_encode(array('state'=>'success'));
}else{
 echo json_encode(array('state'=>'fail'));
}
 break;

case 'M8':
        $chpk=$mysql_xd314->search('pre_chpk'," WHERE tid=".$_POST['tid']);
        echo json_encode(array('data'=>$chpk[0]));//data为数据,页码
        break;
    case 'M8a':
            $a=$mysql_xd314->modify('pre_chpk'," SET x='".$_POST['leibie1']."',x1='".$_POST['leibie2']."',title='".$_POST['title']."',tubiao='".$_POST['tubiao']."',xiangqing='".$_POST['xiangqing']."',x24='".$_POST['shangjia']."',jiage='".$_POST['jiage']."' WHERE  tid=".$_POST['tid']);
        echo json_encode(array('data'=>'success'));//data为数据,页码
        break;
    case 'M7':
        $usertrack=$mysql_xd314->search('pre_usertrack'," WHERE id=14");
        $chpk=$mysql_xd314->search('pre_chpk'," WHERE tid=".$usertrack[0]['chpid']);
        $user=$mysql_xd314->search('pre_user'," WHERE openid='".$usertrack[0]['openid']."'");
        $usertrack[0]['chpid']=$chpk[0]['title'];
        $usertrack[0]['name']=$user[0]['name'];
        $usertrack[0]['phone']=$user[0]['phone'];
        
        echo json_encode(array('data'=>$usertrack[0]));//data为数据,页码
        break;
    case 'M7a':
        $usertrack=$mysql_xd314->search('pre_usertrack'," WHERE id=".$_POST['tid'],' id ');
        
            $a=$mysql_xd314->modify('pre_usertrack'," SET chpshuliang='".$_POST['shuling']."',beizhu='".$_POST['beizhu']."' WHERE  id=".$_POST['tid']);
        
        echo json_encode(array('data'=>'ok'));//data为数据,页码
        break;
     
case 'userlist'://用户
        if(empty($_POST['pageid'])){$_POST['pageid']=0;}
$array=$mysql_xd314->search('pre_user',"");
$paging=$mysql_xd314->paging($array,$_POST['pageid'],5);
        $array=$mysql_xd314->search('pre_user'," LIMIT ".$paging[0].",".$paging[1]);

        
echo json_encode(array('data'=>$array,'paging'=>$paging));//data用户
break;
case 'shanchu'://删除追踪
        if(!empty($_POST['zid'])){
        $array=$mysql_xd314->delete('pre_usertrack'," WHERE id=".$_POST['zid']);
            echo json_encode(array('state'=>'success'));
        }else{
           echo json_encode(array('state'=>'fail'));
        }
        
break;
case 'tucaolist'://吐槽列表
        if(empty($_POST['pageid'])){$_POST['pageid']=0;}
        $array=$mysql_xd314->search('pre_words',"");
        $paging=$mysql_xd314->paging($array,$_POST['pageid'],5);
        $array=$mysql_xd314->search('pre_words'," LIMIT ".$paging[0].",".$paging[1]);
        
        
        echo json_encode(array('data'=>$array,'paging'=>$paging));//data用户
        break;
    case 'shanchu'://删除追踪
        if(!empty($_POST['zid'])){
            $array=$mysql_xd314->delete('pre_usertrack'," WHERE id=".$_POST['zid']);
            echo json_encode(array('state'=>'success'));
        }else{
            echo json_encode(array('state'=>'fail'));
        }
        
break;
case 'tracklist'://追踪
        if(empty($_POST['pageid'])){$_POST['pageid']=0;}
$array=$mysql_xd314->search('pre_usertrack'," WHERE NOT state=1");
        $paging=$mysql_xd314->paging($array,$_POST['pageid'],5);
        $array=$mysql_xd314->search('pre_usertrack'," WHERE NOT state=1 ORDER BY state1 DESC LIMIT ".$paging[0].",".$paging[1]);

$array1=array();
foreach($array as $key=>$value){
          $user=$mysql_xd314->search('pre_user'," WHERE openid='".$value['openid']."'");
            if(count($user)>0){
                $user=$user[0];
                $user['name']?$array1['name']=$user['name']:$array1['name']='';
                $user['phone']?$array1['phone']=$user['phone']:$array1['phone']='';
            }
                  $array1['chpname']=$value['chpname'];
                  $array1['jiage']=$value['chpjiage'];
                  $value['chpshuliang']?$array1['chpshuliang']=$value['chpshuliang']:'';
                  $array1['time']=date('Y-m-d h:i',$value['time']);
                  $array1['id']=$value['id'];
                  $array1['state1']=$value['state1'];
                  $array1['state']=$value['state'];
            $array[$key]=$array1;
        }
        
        
echo json_encode(array('data'=>$array,'paging'=>$paging));//data为数据,页码
break;
case 'wanchenglist'://完成列表
        if(empty($_POST['pageid'])){$_POST['pageid']=0;}
        $array=$mysql_xd314->search('pre_usertrack'," WHERE state=1");
        $paging=$mysql_xd314->paging($array,$_POST['pageid'],5);
        $array=$mysql_xd314->search('pre_usertrack'," WHERE state=1 LIMIT ".$paging[0].",".$paging[1]);
        
        $array1=array();
        foreach($array as $key=>$value){
            $user=$mysql_xd314->search('pre_user'," WHERE openid='".$value['openid']."'");
            if(count($user)>0){
                $user=$user[0];
                $user['name']?$array1['name']=$user['name']:$array1['name']='';
                $user['phone']?$array1['phone']=$user['phone']:$array1['phone']='';
            }
            $array1['chpname']=$value['chpname'];
            $array1['jiage']=$value['chpjiage'];
            $value['chpshuliang']?$array1['chpshuliang']=$value['chpshuliang']:'';
            $array1['time']=date('Y-m-d h:i',$value['time']);
            $array1['id']=$value['id'];
            $array1['state1']=$value['state1'];
            $array1['state']=$value['state'];
            $array[$key]=$array1;
        }
        
        
        echo json_encode(array('data'=>$array,'paging'=>$paging));//data为数据,页码
break;
case 'chplist'://产品
 if(empty($_POST['pageid'])){$_POST['pageid']=0;}
$array=$mysql_xd314->search('pre_chpk'," WHERE x='产品'  AND  x1='鲜花' AND x24=1  ");
$paging=$mysql_xd314->paging($array,$_POST['pageid'],5);
$array=$mysql_xd314->search('pre_chpk'," WHERE x='产品'  AND  x1='鲜花' AND x24=1  LIMIT ".$paging[0].",".$paging[1]);
echo json_encode(array('data'=>$array,'paging'=>$paging));//data为数据,页码
break;
case 'article':
$array=$mysql_xd314->search('pre_chpk',"   WHERE x='文章' AND x1='鲜花' ",' tid,title ');
echo json_encode(array('data'=>$array));//data为数据,页码 
break;
case 'article1':
$array=$mysql_xd314->search('pre_chpk',"  WHERE  tid=".intval($_POST['tid']))[0];
echo json_encode(array('data'=>$array));//data为数据,页码 
break;

default:
echo json_encode('aaaaaaa');
break;
}
    
    function send_post($url, $post_data) {
        $postdata = http_build_query($post_data);
        $options = array(
                         'http' => array(
                                         'method' => 'POST',
                                         'header' => 'Content-type:application/x-www-form-urlencoded',
                                         'content' => $postdata,
                                         'timeout' => 15 * 60 // 超时时间（单位:s）
                                         )
                         );
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        return $result;
    }
?>

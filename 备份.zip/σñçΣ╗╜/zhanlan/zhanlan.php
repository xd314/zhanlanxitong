<?php
header('Access-Control-Allow-Origin:*');
require_once('class/mysql_xd314.php');
require_once('class/basic_xd314.php');
require_once('class/user_xd314.php');
$mysql_xd314=new  mysql_xd314;
$basic_xd314=new  basic_xd314;
$user_xd314=new  user_xd314;
switch ($_POST["caidan"]){
case 'main':
if(empty($_POST['page'])){$_POST['page']=0;}
$array=$mysql_xd314->search('pre_chpk',"   WHERE x='产品'   AND x1='奇石' ");
$fy=$basic_xd314->body_fy($array,$_POST['page'],1);//---------------------------------------列表(输出区间限制数组array($t2,$t3,$t,$t1,$y,$y1))   参数：array $array  列表数据,$y1  页码(固定为$_GET[ft0]),$t1每页条数
$array=$mysql_xd314->search('pre_chpk',"   WHERE x='产品'  AND x1='奇石'   LIMIT   ".$fy[0].",".$fy[3]);
//$array[0]=$basic_xd314->mult_iconv($array[0],"gb2312","utf-8");

echo json_encode(array('data'=>$array,'page'=>$fy[4]));//data为数据,页码 
break;
case 'main1':
$array=$mysql_xd314->search('pre_chpk',"    WHERE  tid=".$_POST['tid']);
echo json_encode(array('data'=>$array));//data为数据,页码 
break;
case 'nlist':
$array=$mysql_xd314->search('pre_chpk',"    WHERE x='产品'   AND x1='奇石' ",' tid,title ');
echo json_encode(array('data'=>$array));//data为数据,页码 
break;
case 'article':
$array=$mysql_xd314->search('pre_chpk',"   WHERE x='文章'  AND x1='奇石' ",' tid,title ');
echo json_encode(array('data'=>$array));//data为数据,页码 
break;
case 'article1':
$array=$mysql_xd314->search('pre_chpk',"  WHERE  tid=".intval($_POST['tid']))[0];
echo json_encode(array('data'=>$array));//data为数据,页码 
 
break;

default:
echo json_encode('aaaaaaa');
break;
}
?>
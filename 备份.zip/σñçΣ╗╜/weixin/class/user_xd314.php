<?php
require_once('class/mysql_xd314.php');
class user_xd314{//-----用户类（用于用于处理和用户相关的数据）
	public function a(){//------------------------------------------------------------------------------------------------------------------------------------------------实验
			return "ok";	
  }

  public function register($name,$password){//-----------------------------------------------------------------------------注册
    $mysql_xd314=new  mysql_xd314;
    if(!empty($name)&&!empty($password)){
      $UserInfo=$this->getUserInfoByName($name);
      if(empty($UserInfo['id'])){
     $salt=rand(1000,9999);
     $password=md5(md5($password).$salt);
     $a=$mysql_xd314->increase('pre_whn_controller'," SET name='".$name."',password='".$password."',time=".time().",salt=".$salt);//------------------------------------------------------------查找数据($TableName表名,$object查找对象,$operation查找条件)
     return  true;
      }else{
        return  'AlreadyExisted';
      }
    }else{
      return  'ParameterDeletion';
    }
  }
  public function getUserInfoById($id){//---------------------------------------------------------------------------获取用户信息
    $mysql_xd314=new  mysql_xd314;
    if(!empty($id)){
      $array=$mysql_xd314->search('pre_whn_controller',"   WHERE  id=".$id)[0];
      if(count($array)>0){
      return $array;
      }else{
      return true;  
      }
    }else{
      return  'ParameterDeletion';
    }
  }

  public function getUserInfoByName($name){//---------------------------------------------------------------------------获取用户信息
    $mysql_xd314=new  mysql_xd314;
    if(!empty($name)){
      $array=$mysql_xd314->search('pre_whn_controller'," WHERE  name='".$name."'")[0];
      if(count($array)>0){
        return $array;
        }else{
        return true;  
        }
    }else{
      return  'ParameterDeletion';
    }
  }

  public function login($name,$password){//-----------------------------------------------------------------------------登录
    $mysql_xd314=new  mysql_xd314;
    if(!empty($name)&&!empty($password)){
      $UserInfo=$this->getUserInfoByName($name);
     $password=md5(md5($password).$UserInfo['salt']);
     if($password==$UserInfo['password']){
      $sign=md5(md5($UserInfo['id'].time()).rand(1000,9999));
      $time=time()+60;
      setcookie('sign',$sign,$time);  
      $mysql_xd314->modify('pre_whn_controller'," SET  login_cookie='".$sign."',login_time=".$time."  WHERE  id=".$UserInfo['id']);
      return  true;
     }else{
      return  false;
     } 
    }else{
      return  'ParameterDeletion';
    }
  }


  public function CheckLogin($sign){//-----------------------------------------------------------------------------检查登录（$sign）
    $mysql_xd314=new  mysql_xd314;
    if(!empty($_COOKIE["sign"])){
      $controller=$mysql_xd314->search('pre_whn_controller',"   WHERE  login_cookie='".$_COOKIE["sign"]."'")[0];
      if($controller['login_time']<time()){
        return false;
      }else{
        return true;
      }     
      }else{
      return false;
      }
  }
 
}
?>
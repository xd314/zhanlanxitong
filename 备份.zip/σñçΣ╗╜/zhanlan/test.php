<?php
    header('Access-Control-Allow-Origin:*');
    require_once('class/basic_xd314.php');
    $basic_xd314=new  basic_xd314;
    $a=$basic_xd314->shangchuanimg($_FILES['f']);
  
echo $a.'健康健康健康'.$_POST['canshu'].$_POST['tid'];
?>

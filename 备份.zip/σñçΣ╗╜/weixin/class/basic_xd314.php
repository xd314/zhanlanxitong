<?php

const SIGN_XD = '';
class basic_xd314{//-----ϵͳ�����ļ������ڹ���ҳ����ṩ���ݣ�
	
	public function a(){//------------------------------------------------------------------------------------------------------------------------------------------------ʵ��

			return "ok";
		
	}
public function get_pluginvar($plugin,$key){//----------------------------------------------------------------------------------��ȡ�������
  $array1=$mysql_xd314->search('pre_common_plugin'," WHERE    identifier='".$plugin."'")[0];//------------------------------------------------------------��������($TableName����,$object���Ҷ���,$operation��������)
  $array=$mysql_xd314->search('pre_common_pluginvar'," WHERE    pluginid=".$array1[pluginid]."    AND   variable='".$key."'")[0];//------------------------------------------------------------��������($TableName����,$object���Ҷ���,$operation��������)
	return $array[value];	
	}
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------���ݿ���
public function datadase_create(){//-----------------------------------------------------------------------------------�������ݿ�
			$a=DB::query("CREATE TABLE pre_xd_demand(
	`yid` int(11) NOT NULL,`x` text NULL,`x1` text NULL,`x2` text NULL,`x3` text NULL,`x4` text NULL,`x5` text NULL,`x6` text NULL,`x7` text NULL,`x8` text NULL,`x9` text NULL,`x10` text NULL,`x11` text NULL,`x12` text NULL,`x13` text NULL,`x14` text NULL,`x15` text NULL,`x16` text NULL,PRIMARY KEY (`yid`)
) ENGINE=MyISAM
DEFAULT CHARACTER SET=utf8
CHECKSUM=0
DELAY_KEY_WRITE=0;");
}

public function shu($t){//-----------------------------------------------------------------------------------------------------------��������  $t
 if($t>=10000){$t1=floor($t/10000).'��';
}else if($t==''){$t1=0;
}else if($t>=100000000){$t1=floor($t/100000000).'��';
}else{$t1=$t;}
return  	$t1;
}

public function timearray($time) //--------------------------------------------------------------------------------------------------------------------------��ȡʱ��($timeΪʱ���) ���������ʽ���طֱ��Ӧ������ʱ����
{  
    $Y=date("Y",$time);  
    $m=date("m",$time);  
    $d=date("d",$time);  
    $H=date("H",$time);  
    $i=date("i",$time);  
    $s=date("s",$time);  
    return array($Y,$m,$d,$H,$i,$s);             
}  

public function  zhfuzhx($me,$df,$number,$zhekou=1,$leixing,$dsjjb,$tzid,$spid){//------------------------------------֧��ִ��($me���,$df�Է�,$number���,$zhekou�ۿ�,$leixing֧������,$dsjjb���ͼ���,$tzid����id,$spid��Ƶ)
$leixing=$this->array_iconv($leixing,'utf-8','gbk');
$cou= DB::fetch_all("SELECT * FROM " .DB::table('common_member_count')."  WHERE   uid=".$me)[0];
$cou[extcredits3]=$cou[extcredits3]-$number*$zhekou;
$a= DB::query("UPDATE ".DB::table('common_member_count')." SET   extcredits3='".$cou[extcredits3]."'     WHERE uid=".$me);
$cou1= DB::fetch_all("SELECT * FROM " .DB::table('common_member_count')."  WHERE   uid=".$df)[0];
$cou1[extcredits3]=$cou1[extcredits3]+$number*$zhekou;
$cou1[extcredits4]=$cou1[extcredits4]+$number*$zhekou;
$cou1a[extcredits3]=$number*$zhekou;
$a= DB::query("UPDATE ".DB::table('common_member_count')." SET   extcredits3='".$cou1[extcredits3]."',extcredits4='".$cou1[extcredits4]."'     WHERE uid=".$df);
$array= DB::fetch_all("SELECT * FROM ".DB::table('whn_shouyi')."   ORDER BY  yid  DESC")[0];
$yid=$array[yid]+1;
$a= DB::query("INSERT ".DB::table('whn_shouyi')." VALUES (".$yid.",'".$df."','".$me."','','".time()."','".$leixing."','".$cou1a[extcredits3]."','".$dsjjb."','','','','".$tzid."','".$spid."','','','','','','','','','','','','','')");
return  $cou1a[extcredits3];
}

public  function array_iconv($str, $in_charset="gbk", $out_charset="utf-8")//------------------------------------------------------ת��
{
 if(is_array($str))
 {
 foreach($str as $k => $v)
 {
  $str[$k] = array_iconv($v);
 }
 return $str;
 }
 else
 {
 if(is_string($str))
 {
  // return iconv('UTF-8', 'GBK//IGNORE', $str);
  return mb_convert_encoding($str, $out_charset, $in_charset);
 }
 else
 {
  return $str;
 }
 }
}


public  function mult_iconv($data,$in_charset="gbk",$out_charset="utf-8")//------------------------------------------------------ת��
{
    if(substr($out_charset,-8)=='//IGNORE'){
        $out_charset=substr($out_charset,0,-8);
    }
    if(is_array($data)){
        foreach($data as $key => $value){
            if(is_array($value)){
                $key=iconv($in_charset,$out_charset.'//IGNORE',$key);
                $rtn[$key]=mult_iconv($in_charset,$out_charset,$value);
            }elseif(is_string($key) || is_string($value)){
                if(is_string($key)){
                    $key=iconv($in_charset,$out_charset.'//IGNORE',$key);
                }
                if(is_string($value)){
                    $value=iconv($in_charset,$out_charset.'//IGNORE',$value);
                }
                $rtn[$key]=$value;
            }else{
                $rtn[$key]=$value;
            }
        }
    }elseif(is_string($data)){
        $rtn=iconv($in_charset,$out_charset.'//IGNORE',$data);
    }else{
        $rtn=$data;
    }
    return $rtn;
}


public  function  dzh($uid,$ty){//----------------------------------------��ַ����   ������$uid�û�uid��$ty�ļ�����
switch ($ty){
case 'file':
return './wjx_file/2018';
break;
case 'y':
return './wjx/'.$uid.'/y';
break;
case 't':
return './wjx/'.$uid.'/t';
break;
case 't1':
return './wjx/'.$uid.'/t1';
break;
case 't2':
return './wjx/'.$uid.'/t2';
break;
case 'y':
return './wjxa/y';
break;
case 'hdp':
return './wjx/'.$uid.'/hdp';
break;
case 'mp':
return './wjx/'.$uid.'/mp';
break;
default:
//echo '<script language="JavaScript">alert("'.lang('plugin/xd', 'mp58').'");</script>';	
break;
}
}

public  function  shangchuant_file(array $_G,array $file,$key=0){//----------------------------------------�ϴ��ļ�(��Ƶ)     ������array $_G,array $file,$key �ļ�ָ��
//echo '<script language="JavaScript">alert("'.$file['tmp_name'][$key].'");</script>';
$arrType=array('video/mp4');
$max_size='10000000000';      // ����ļ����ƣ���λ��byte��
$upfile=$this->dzh(1,'file');  //ͼƬĿ¼·��
   if($_SERVER['REQUEST_METHOD']=='POST'){ //�ж��ύ��ʽ�Ƿ�ΪPOST
     if(!is_uploaded_file($file['tmp_name'])){ //�ж��ϴ��ļ��Ƿ����
    echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd11').'</div>';
    exit;
    }
   if(!in_array($file['type'],$arrType)){  //�ж�ͼƬ�ļ��ĸ�ʽ
     echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd13').'</div>';
     exit;
   }
  if($file['size']>$max_size){  //�ж��ļ���С�Ƿ����500000�ֽ�
     echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd12').'</div>';
    exit;
   } 
  if(!file_exists($upfile)){  // �жϴ���ļ�Ŀ¼�Ƿ����
   mkdir($upfile,0777,true);
   } 


$ftype=explode('.',$file['name']); 
   $picName=$upfile.'/'.$_G['uid'].'a'.$_G['timestamp'].'.'.$ftype[1];

   if(file_exists($picName)){
    echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd14').'</div>';
    exit;
     }
   if(!move_uploaded_file($file['tmp_name'],$picName)){  
    echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd15').'</div>';
   
    }else{ 	 echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd16').'</div>';   
	}
   }

return  $ftype=explode('./',$picName)[1]; 
}


public  function  shangchuant1(array $_G,array $file,$key){//----------------------------------------�ϴ�ͼƬ1     ������array $_G,array $file,$key �ļ�ָ��
//echo '<script language="JavaScript">alert("'.$file['tmp_name'][$key].'");</script>';
$arrType=array('image/jpg','image/gif','image/png','image/bmp','image/jpeg');
$max_size='10000000000';      // ����ļ����ƣ���λ��byte��
$upfile=$this->dzh($_G[uid],'t');  //ͼƬĿ¼·��
   if($_SERVER['REQUEST_METHOD']=='POST'){ //�ж��ύ��ʽ�Ƿ�ΪPOST
     if(!is_uploaded_file($file['tmp_name'][$key])){ //�ж��ϴ��ļ��Ƿ����
    echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd11').'</div>';
    exit;
    }
   
  if($file['size'][$key]>$max_size){  //�ж��ļ���С�Ƿ����500000�ֽ�
     echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd12').'</div>';
    exit;
   } 
  if(!in_array($file['type'][$key],$arrType)){  //�ж�ͼƬ�ļ��ĸ�ʽ
     echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd13').'</div>';
     exit;
   }
  if(!file_exists($upfile)){  // �жϴ���ļ�Ŀ¼�Ƿ����
   mkdir($upfile,0777,true);
   } 


      $imageSize=getimagesize($file['tmp_name'][$key]);
   $img=$imageSize[0].'*'.$imageSize[1];
$c=strrev($file['name'][$key]);
$ftype=explode('.',$c); 
$ftype=strrev($ftype[0]);
   if($ftype=="PNG"){$ftype="png";}
 if($ftype=="JPG"){$ftype="jpg";}
$fname=$_G['timestamp'].'-'.$_G['uid'].$key.'.'.$ftype;
   $picName=$upfile.'/'.$fname;

   if(file_exists($picName)){
    echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd14').'</div>';
    exit;
     }
   if(!move_uploaded_file($file['tmp_name'][$key],$picName)){  
    echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd15').'</div>';
   
    }
   else{ 	 echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd16').'</div>';   }
      }
$path=$this->dzh($_G[uid],'t1').'/'.$fname; 
        list($width,$height) = getimagesize($picName);//��ȡԭͼ��ߴ�Ŀ�����߶�
$c1=501111;//�趨��ͼƬ�������ػ�
if($width*$height>=$c1){$c=$width/$height; $c=$c1/$c;$_height=sqrt($c);$_width=$c1/$_height;$_height=round($_height);$_width=round($_width); 
}else{$_height=$width;$_width=$height;}
        $_img = imagecreatetruecolor($_width,$_height);//Ϊ��ͼ�񴴽�һ������
 if($ftype=="png"){ $img = imagecreatefrompng($picName);}
else if($ftype=="jpg"){ $img = imagecreatefromjpeg($picName);}
else if($ftype=="gif"){ $img = imagecreatefromgif($picName);}
else if($ftype=="jpeg"){ $img = imagecreatefromjpeg($picName);}
else if($ftype=="wbmp"){ $img = imagecreatefromwbmp($picName);}
imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
//imagecopy($_img,$img, 0, 0, $_width,$_height,$width,$height); 
        imagejpeg($_img,$path,0, 100);
 imagepng($_img,$path,0, 100);
        ImageDestroy( $_img);  
$path=$this->dzh($_G[uid],'t2').'/'.$fname; 
      
      

  list($width,$height) = getimagesize($picName);//��ȡԭͼ��ߴ�Ŀ�����߶�
if($width>$height){
$wh=($width-$height)/2;
$wh1=$height;
$_img = imagecreatetruecolor($wh1,$wh1);//Ϊ��ͼ�񴴽�һ������
imagecopy($_img,$img,0,0,$wh,0,$wh1,$wh1); 
   // imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
//imagecopyresized($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
}else{
$wh=($height-$width)/2;
$wh1=$width;
$_img = imagecreatetruecolor($wh1,$wh1);//Ϊ��ͼ�񴴽�һ������
imagecopy($_img,$img,0,0,0,$wh,$wh1,$wh1); //�����޷����ڳߴ磬�ɼ���
//imagecopyresized($_img,$img,0,0,0,0,$wh1,$wh1,$width,$height);//���ƿɵ��ڳߴ磬���ɼ���
    //imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
}
     $_img1= imagecreatetruecolor(200,200);//Ϊ��ͼ�񴴽�һ������
  imagecopyresized($_img1,$_img,0,0,0,0,200,200,$wh1,$wh1);      
//imagecopy($_img,$img, 0, 0, $_width,$_height,$wh1,$wh1); 
        imagejpeg($_img1,$path,0, 100);
       imagepng($_img1,$path,0, 100);
        ImageDestroy( $_img);  
        ImageDestroy( $_img1);  
        ImageDestroy($img);  
//$a= DB::query("UPDATE ".DB::table('whn_dizhi')." SET x9='".$fname."' WHERE yid=".$name);
return  $fname;
}

public  function get_avatar($uid, $size = 'middle', $type = '') {
	$size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
	$uid = abs(intval($uid));
	$uid = sprintf("%09d", $uid);
	$dir1 = substr($uid, 0, 3);
	$dir2 = substr($uid, 3, 2);
	$dir3 = substr($uid, 5, 2);
	$typeadd = $type == 'real' ? '_real' : '';
	return 'uc_server/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).$typeadd."_avatar_$size.jpg";
}

public  function  shangchuant_touxiang(array $_G,array $file,$key){//-------------------------------------------------------------------------------------�ϴ�ͼƬ_ͷ��     ������array $_G,array $file,$name
//echo '<script language="JavaScript">alert("'.lang('plugin/xd', 'mp58').'");</script>';	
$arrType=array('image/jpg','image/gif','image/png','image/bmp','image/jpeg');
$max_size='10000000000';      // ����ļ����ƣ���λ��byte��

if($_SERVER['REQUEST_METHOD']=='POST'){ //�ж��ύ��ʽ�Ƿ�ΪPOST
 if($file['size']>$max_size){  //�ж��ļ���С�Ƿ����500000�ֽ�
     echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd12').'</div>';
    exit;
   } 

  if(!in_array($file['type'],$arrType)){  //�ж�ͼƬ�ļ��ĸ�ʽ
     echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd13').'</div>';
     exit;
  }

$c=strrev($file['name']);
$ftype=explode('.',$c); 
$ftype=strrev($ftype[0]);
if($ftype=="PNG"){$ftype="png";}
if($ftype=="JPG"){$ftype="jpg";}
$path=$this->dzh($_G[uid],'t').$file['name'];
$path1=$this->get_avatar($_G[uid],'middle');
$path2=$this->get_avatar($_G[uid],'small');
$path3=$this->get_avatar($_G[uid],'big');

 if(!move_uploaded_file($file['tmp_name'],$path)){  
 echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd15').'</div>';
 exit;
 }
 else{ echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd16').'</div>'; }
 }

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if($ftype=="png"){ $img = imagecreatefrompng($path);}
else if($ftype=="jpg"){ $img = imagecreatefromjpeg($path);}
else if($ftype=="gif"){ $img = imagecreatefromgif($path);}
else if($ftype=="jpeg"){ $img = imagecreatefromjpeg($path);}
else if($ftype=="wbmp"){ $img = imagecreatefromwbmp($path);}
 list($width,$height) = getimagesize($path);//��ȡԭͼ��ߴ�Ŀ�����߶�
if($width>$height){
$wh=($width-$height)/2;
$wh1=$height;
$_img = imagecreatetruecolor($wh1,$wh1);//Ϊ��ͼ�񴴽�һ������
imagecopy($_img,$img,0,0,$wh,0,$wh1,$wh1); 
   // imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
//imagecopyresized($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
}else{
$wh=($height-$width)/2;
$wh1=$width;
$_img = imagecreatetruecolor($wh1,$wh1);//Ϊ��ͼ�񴴽�һ������
imagecopy($_img,$img,0,0,0,$wh,$wh1,$wh1); //�����޷����ڳߴ磬�ɼ���
//imagecopyresized($_img,$img,0,0,0,0,$_width,$_height,$width,$height);//���ƿɵ��ڳߴ磬���ɼ���
    //imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
}
     $_img1= imagecreatetruecolor(100,100);//Ϊ��ͼ�񴴽�һ������
  imagecopyresized($_img1,$_img,0,0,0,0,100,100,$wh1,$wh1);      
//imagecopy($_img,$img, 0, 0, $_width,$_height,$wh1,$wh1); 
        imagejpeg($_img1,$path1,0, 100);
       imagepng($_img1,$path1,0, 100);
        ImageDestroy( $_img);  
        ImageDestroy( $_img1);  
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
 list($width,$height) = getimagesize($path);//��ȡԭͼ��ߴ�Ŀ�����߶�
if($width>$height){
$wh=($width-$height)/2;
$wh1=$height;
$_img = imagecreatetruecolor($wh1,$wh1);//Ϊ��ͼ�񴴽�һ������
imagecopy($_img,$img,0,0,$wh,0,$wh1,$wh1); 
   // imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
//imagecopyresized($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
}else{
$wh=($height-$width)/2;
$wh1=$width;
$_img = imagecreatetruecolor($wh1,$wh1);//Ϊ��ͼ�񴴽�һ������
imagecopy($_img,$img,0,0,0,$wh,$wh1,$wh1); //�����޷����ڳߴ磬�ɼ���
//imagecopyresized($_img,$img,0,0,0,0,$_width,$_height,$width,$height);//���ƿɵ��ڳߴ磬���ɼ���
    //imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
}
     $_img1= imagecreatetruecolor(50,50);//Ϊ��ͼ�񴴽�һ������
  imagecopyresized($_img1,$_img,0,0,0,0,50,50,$wh1,$wh1);      
//imagecopy($_img,$img, 0, 0, $_width,$_height,$wh1,$wh1); 
        imagejpeg($_img1,$path2,0, 100);
       imagepng($_img1,$path2,0, 100);
        ImageDestroy( $_img);  
        ImageDestroy( $_img1);  
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
 list($width,$height) = getimagesize($path);//��ȡԭͼ��ߴ�Ŀ�����߶�
if($width>$height){
$wh=($width-$height)/2;
$wh1=$height;
$_img = imagecreatetruecolor($wh1,$wh1);//Ϊ��ͼ�񴴽�һ������
imagecopy($_img,$img,0,0,$wh,0,$wh1,$wh1); 
   // imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
//imagecopyresized($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
}else{
$wh=($height-$width)/2;
$wh1=$width;
$_img = imagecreatetruecolor($wh1,$wh1);//Ϊ��ͼ�񴴽�һ������
imagecopy($_img,$img,0,0,0,$wh,$wh1,$wh1); //�����޷����ڳߴ磬�ɼ���
//imagecopyresized($_img,$img,0,0,0,0,$_width,$_height,$width,$height);//���ƿɵ��ڳߴ磬���ɼ���
    //imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
}
     $_img1= imagecreatetruecolor(200,200);//Ϊ��ͼ�񴴽�һ������
  imagecopyresized($_img1,$_img,0,0,0,0,200,200,$wh1,$wh1);      
//imagecopy($_img,$img, 0, 0, $_width,$_height,$wh1,$wh1); 
        imagejpeg($_img1,$path3,0, 100);
       imagepng($_img1,$path3,0, 100);
        ImageDestroy( $_img);  
        ImageDestroy( $_img1);  
        ImageDestroy($img);  
$result = unlink($path);
return  $path;
}

public  function  shangchuant(array $_G,array $file,$name){//--------------------------------------------------------------------�ϴ�ͼƬ(��ƵԤ��ͼ)     ������array $_G,array $file,$name
//echo '<script language="JavaScript">alert("'.$file['tmp_name'].'");</script>';
$arrType=array('image/jpg','image/gif','image/png','image/bmp','image/jpeg');
$max_size='10000000000';      // ����ļ����ƣ���λ��byte��
$upfile=$this->dzh($_G[uid],'t');  //ͼƬĿ¼·��
   if($_SERVER['REQUEST_METHOD']=='POST'){ //�ж��ύ��ʽ�Ƿ�ΪPOST
     if(!is_uploaded_file($file['tmp_name'])){ //�ж��ϴ��ļ��Ƿ����
    echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd11').'</div>';
    exit;
    }
   
  if($file['size']>$max_size){  //�ж��ļ���С�Ƿ����500000�ֽ�
     echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd12').'</div>';
    exit;
   } 
  if(!in_array($file['type'],$arrType)){  //�ж�ͼƬ�ļ��ĸ�ʽ
     echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd13').'</div>';
     exit;
   }
  if(!file_exists($upfile)){  // �жϴ���ļ�Ŀ¼�Ƿ����
   mkdir($upfile,0777,true);
   } 


      $imageSize=getimagesize($file['tmp_name']);
   $img=$imageSize[0].'*'.$imageSize[1];
$c=strrev($file['name']);
$ftype=explode('.',$c); 
$ftype=strrev($ftype[0]);
   if($ftype=="PNG"){$ftype="png";}
 if($ftype=="JPG"){$ftype="jpg";}
$fname=$_G['timestamp'].'-'.$_G['uid'].'.'.$ftype;
   $picName=$upfile.'/'.$fname;

   if(file_exists($picName)){
    echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd14').'</div>';
    exit;
     }
   if(!move_uploaded_file($file['tmp_name'],$picName)){  
    echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd15').'</div>';
   
    }
   else{ 	 echo '<div   style="font-size:30px;margin-top:40%;margin-left:5%;color:#FF0000">'.lang('plugin/xd', 'xd16').'</div>';   }
      }
$path=$this->dzh($_G[uid],'t1').'/'.$fname; 
        list($width,$height) = getimagesize($picName);//��ȡԭͼ��ߴ�Ŀ�����߶�
$c1=501111;//�趨��ͼƬ�������ػ�
if($width*$height>=$c1){$c=$width/$height; $c=$c1/$c;$_height=sqrt($c);$_width=$c1/$_height;$_height=round($_height);$_width=round($_width); 
}else{$_height=$width;$_width=$height;}
        $_img = imagecreatetruecolor($_width,$_height);//Ϊ��ͼ�񴴽�һ������
 if($ftype=="png"){ $img = imagecreatefrompng($picName);}
else if($ftype=="jpg"){ $img = imagecreatefromjpeg($picName);}
else if($ftype=="gif"){ $img = imagecreatefromgif($picName);}
else if($ftype=="jpeg"){ $img = imagecreatefromjpeg($picName);}
else if($ftype=="wbmp"){ $img = imagecreatefromwbmp($picName);}
imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
//imagecopy($_img,$img, 0, 0, $_width,$_height,$width,$height); 
        imagejpeg($_img,$path,0, 100);
 imagepng($_img,$path,0, 100);
        ImageDestroy( $_img);  
$path=$this->dzh($_G[uid],'t2').'/'.$fname; 
      
      

  list($width,$height) = getimagesize($picName);//��ȡԭͼ��ߴ�Ŀ�����߶�
if($width>$height){
$wh=($width-$height)/2;
$wh1=$height;
$_img = imagecreatetruecolor($wh1,$wh1);//Ϊ��ͼ�񴴽�һ������
imagecopy($_img,$img,0,0,$wh,0,$wh1,$wh1); 
   // imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
//imagecopyresized($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
}else{
$wh=($height-$width)/2;
$wh1=$width;
$_img = imagecreatetruecolor($wh1,$wh1);//Ϊ��ͼ�񴴽�һ������
imagecopy($_img,$img,0,0,0,$wh,$wh1,$wh1); //�����޷����ڳߴ磬�ɼ���
//imagecopyresized($_img,$img,0,0,0,0,$wh1,$wh1,$width,$height);//���ƿɵ��ڳߴ磬���ɼ���
    //imagecopyresampled($_img,$img,0,0,0,0,$_width,$_height,$width,$height);
}
     $_img1= imagecreatetruecolor(200,200);//Ϊ��ͼ�񴴽�һ������
  imagecopyresized($_img1,$_img,0,0,0,0,200,200,$wh1,$wh1);      
//imagecopy($_img,$img, 0, 0, $_width,$_height,$wh1,$wh1); 
        imagejpeg($_img1,$path,0, 100);
       imagepng($_img1,$path,0, 100);
        ImageDestroy( $_img);  
        ImageDestroy( $_img1);  
        ImageDestroy($img);  
//$a= DB::query("UPDATE ".DB::table('whn_dizhi')." SET x9='".$fname."' WHERE yid=".$name);
return  $fname;
}


//============================================================================================================================================================�ͻ���

public function total_shangchuanwz($dizhi_b,$dizhi_b1){//----------------------------------------------------------------------------------�ϴ����֣�$url        ($dizhi_b��post��ַ,$dizhi_b1  post��ַ1,��
echo   '
<form id="wz1" action="'.$dizhi_b.'" method="post"     accept-charset="utf-8">
  <input name="upfilewz" id="upfilewz" type="hidden"  />
</form>
<script language="javascript" type="text/javascript">
function wz(){
var  a=document.getElementById("wz").value;
if(a==""){alert("���벻��Ϊ�գ�");}else{
document.getElementById("upfilewz").value=document.getElementById("wz").value;
document.getElementById("wz1").submit();
}
 }
</script>
';
}

public function total_shangchuant($dizhi_b,$dizhi_b1){//----------------------------------------------------------------------------------�ϴ�ͼƬ��$url        ($dizhi_b��post��ַ,$dizhi_b1  post��ַ1,��
echo   '
<form id="t1" action="'.$dizhi_b.'" method="post" enctype="multipart/form-data">
 <input name="upfilet" id="upfilet" type="file"  accept="image/*;capture=camera"     style="display:none"  onchange="t1()"/>
</form>
<script language="javascript" type="text/javascript">
function t(){
var upfile=document.getElementById("upfilet");
upfile.click();
 }
function t1(){
var a1=document.getElementById("t1");
a1.submit();
 }
</script>
';
}
public function total_shangchuany($dizhi_b,$dizhi_b1){//----------------------------------------------------------------------------------�ϴ����֣�$url        ($dizhi_b��post��ַ,$dizhi_b1  post��ַ1,��
echo   '
<form id="yy1" action="'.$dizhi_b.'" method="post" enctype="multipart/form-data">
  <input name="upfiley" id="upfiley" type="file"   style="display:none"  onchange="y1()"/>
</form>
<script language="javascript" type="text/javascript">
function y(){
alert("�������ɳ���60���ӣ�");
var upfile=document.getElementById("upfiley");
upfile.click();
 }
function y1(){
var a1=document.getElementById("yy1");
a1.submit();
 }
</script>
';
}
public function total_shangchuanshp($dizhi_b,$dizhi_b1){//----------------------------------------------------------------------------------�ϴ���Ƶ��$url        ($dizhi_b��post��ַ,$dizhi_b1  post��ַ1,��
echo   '
<form id="shpp1" action="'.$dizhi_b.'" method="post" enctype="multipart/form-data">
  <input name="upfileshp" id="upfileshp" type="file"   accept="video/*;capture=camcorder"    style="display:none"  onchange="shp1()"/>
</form>
<script language="javascript" type="text/javascript">
function shp(){
alert("��Ƶ���ɳ���30���ӣ�");
var upfile=document.getElementById("upfileshp");
upfile.click();
 }
function shp1(){
var a1=document.getElementById("shpp1");
a1.submit();
 }
</script>
';
}
public function total_shangchuanw($dizhi_b,$dizhi_b1){//----------------------------------------------------------------------------------�ϴ��ļ���$url        ($dizhi_b��post��ַ,$dizhi_b1  post��ַ1,��
echo   '
<form id="a1" action="'.$dizhi_b.'" method="post" enctype="multipart/form-data">
  <input name="upfile" id="upfile" type="file"   style="display:none"  onchange="b(this)"/>
<script language="javascript" type="text/javascript">
function a(){
alert("�������ɳ���60���ӣ�");
var upfile=document.getElementById("upfile");
upfile.click();
 }
function b(){
var a1=document.getElementById("a1");
a1.submit();
 }
</script>
';
}


public function dengjitubiao($extcredits4){//----------------------------------------------------------------------------------�û��ȼ�  
if($extcredits4<=1){
	return  '0';				
}else if($extcredits4<=5){
	return  '1';		
}else if($extcredits4<=10){
	return  '2';			
}else if($extcredits4<=20){
	return  '3';			
}else if($extcredits4<=40){
	return  '4';		
}else if($extcredits4<=80){
	return  '5';	
}else if($extcredits4<=160){
	return '6';	
}else if($extcredits4<=320){
	return  '7';	
}else if($extcredits4<=640){
	return  '8';
}else if($extcredits4<=1780){
	return  '9';
}else if($extcredits4<=3560){
	return  '10';
}else if($extcredits4<=10240){
	return  '11';
}else if($extcredits4<=40480){
	return  '12';
}else if($extcredits4<=110960){
	return  '13';
}else if($extcredits4<=691920){
	return  '14';
}else if($extcredits4<=999999){
	return  '15';
}
}



public function   alyicon_css(){//-----------------------------------------------------------------------------------����ͼ��   
echo  '
<style>
@font-face {
  font-family: \'iconfont\';  
  src: url(\'//at.alicdn.com/t/font_366477_d4wcrd14y5geqaor.eot\');
  src: url(\'//at.alicdn.com/t/font_366477_d4wcrd14y5geqaor.eot?#iefix\') format(\'embedded-opentype\'),
  url(\'//at.alicdn.com/t/font_366477_d4wcrd14y5geqaor.woff\') format(\'woff\'),
  url(\'//at.alicdn.com/t/font_366477_d4wcrd14y5geqaor.ttf\') format(\'truetype\'),
  url(\'//at.alicdn.com/t/font_366477_d4wcrd14y5geqaor.svg#iconfont\') format(\'svg\');
}
.iconfont{
    font-family:"iconfont" !important;
    font-size:16px;font-style:normal;
    -webkit-font-smoothing: antialiased;
    -webkit-text-stroke-width: 0.2px;
    -moz-osx-font-smoothing: grayscale;}
</style>
';
}

public function feiniao_cj(){//---------------------------------------------------------------------------------������ʽ
echo  '
<link rel="stylesheet" href="source/plugin/'.SIGN_XD.'/static/css/style.css">
<link rel="stylesheet" href="source/plugin/'.SIGN_XD.'/static/css/animation.css">
<script src="source/plugin/'.SIGN_XD.'/static/js/rem.js"></script>
';
}

public function iconfont_css(){//---------------------------------------------------------------------------------ͼ��
echo  '
<link rel="stylesheet" type="text/css" href="source/plugin/'.SIGN_XD.'/static/css/iconfont.css">
';
}



public function head_lianjie(){//----------------------------------------------------------------------------------����
echo  '
<style>
@font-face {
  font-family: \'iconfont\';  
  src: url(\'//at.alicdn.com/t/font_366477_d4wcrd14y5geqaor.eot\');
  src: url(\'//at.alicdn.com/t/font_366477_d4wcrd14y5geqaor.eot?#iefix\') format(\'embedded-opentype\'),
  url(\'//at.alicdn.com/t/font_366477_d4wcrd14y5geqaor.woff\') format(\'woff\'),
  url(\'//at.alicdn.com/t/font_366477_d4wcrd14y5geqaor.ttf\') format(\'truetype\'),
  url(\'//at.alicdn.com/t/font_366477_d4wcrd14y5geqaor.svg#iconfont\') format(\'svg\');
}
.iconfont{
    font-family:"iconfont" !important;
    font-size:16px;font-style:normal;
    -webkit-font-smoothing: antialiased;
    -webkit-text-stroke-width: 0.2px;
    -moz-osx-font-smoothing: grayscale;}
</style>
';
echo  '
<link rel="stylesheet" type="text/css" href="source/plugin/'.SIGN_XD.'/static/css/iconfont.css">
<link rel="stylesheet" href="source/plugin/'.SIGN_XD.'/main.css">
<link rel="stylesheet" href="source/plugin/'.SIGN_XD.'/static/css/style.css">
<link rel="stylesheet" href="source/plugin/'.SIGN_XD.'/static/css/animation.css">
<script  type="text/javascript"  src="source/plugin/'.SIGN_XD.'/static/js/jquery-1.9.1.min.js"></script>
<script    type="text/javascript"   src="source/plugin/'.SIGN_XD.'/static/js/sq-3.0.0.js"></script>
<script src="source/plugin/'.SIGN_XD.'/static/js/rem.js"></script>
<script src="source/plugin/xd/static/js/jquery.similar.msgbox.js"></script>


';
}

public function vue_js(){//---------------------------------------------------------------------------------vue
echo  '
<script src="source/plugin/'.SIGN_XD.'/static/js/vue.min.js"></script>
';
}

public function jquery_js(){//----------------------------------------------------------------------------------jquery
echo  '
<script src="source/plugin/'.SIGN_XD.'/static/js/jquery-1.9.1.min.js"></script>
';
}

public function xiaoyun_js(){//-------------------------------------------------------------------------------С��js
echo  '
<script    type="text/javascript"   src="source/plugin/'.SIGN_XD.'/static/js/sq-3.0.0.js"></script>
';
}

public function erweima_js(){//---------------------------------------------------------------------------------���ɶ�ά��js
echo  '
 <script type="text/javascript" src="source/plugin/'.SIGN_XD.'/static/js/jquery.qrcode.min.js"></script>
';
}

public function baidu_js(){//----------------------------------------------------------------------------------�ٶȵ�ͼ��js
echo  '
<script type="text/javascript" src="https://api.map.baidu.com/api?v=2.0&ak=x2wdWWgqQ3iqSmYIKWk2xozRIj6TRNpZ">
<script type="text/javascript" src="http://api.map.baidu.com/library/CityList/1.2/src/CityList_min.js"></script>
<script type="text/JavaScript" src="http://api.map.baidu.com/library/SearchInfoWindow/1.5/src/SearchInfoWindow_min.js" charset="UTF-8"></script>
';
}

public function system_start1($title,$keywords,$description,$head){//-----------------------------------------------------------------------------------html�ļ����忪ͷ  $title,$keywords,$description,$head
echo  '
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width,minimum-scale=1.0,initial-scale=1.0,user-scalable=0" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="format-detection" content="telephone=no">
<title>'.$title.'</title>
<meta name="keywords" content="'.$keywords.'">
<meta name="description" content="'.$description.'">
'.$head.'
</head>
<body>

';
}

public function system_start($canshu,$title,$keywords,$description,$head,$body_backcolor='#F0F0F0'){//-----------------------------------------------------------------------------------html�ļ����忪ͷ $canshu����0��ֵ,  $title,$keywords,$description,$head,$body_backcolor������ɫ
echo  '
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,minimum-scale=1.0,initial-scale=1.0,user-scalable=0" />
<meta name="x5-fullscreen" content="true">
<meta name="full-screen" content="yes">
<meta name="format-detection" content="telephone=no">  
<title>'.$title.'</title>
<meta name="keywords" content="'.$keywords.'">
<meta name="description" content="'.$description.'">
'.$head.'
<link rel="stylesheet" href="source/plugin/'.SIGN_XD.'/static/css/xd314.css">
</head>
<body   style="background:'.$body_backcolor.'"         onscroll="myFunction()">
<input  id="canshu"   name="canshu"   type="hidden"    value="'.$canshu.'"  />
<input  id="canshu1"   name="canshu1"   type="hidden"    value=""  />
<input  id="canshu2"   name="canshu2"   type="hidden"    value=""  />
<input  id="canshu3"   name="canshu3"   type="hidden"    value=""  />
<input  id="canshu4"   name="canshu4"   type="hidden"    value=""  />
<input  id="canshu5"   name="canshu5"   type="hidden"    value=""  />
<input  id="canshu6"   name="canshu6"   type="hidden"    value=""  />
<input  id="neirong"   name="neirong"   type="hidden"    value=""  />
<input  id="caidan"   name="caidan"   type="hidden"    value=""  />
';
}

	






public function system_end1(){//-----------------------------------------------------------------------------------html�ļ������β
echo   '
</body>
</html>
';

	}
public function system_end($name,$url,$before,$after,$post){//-----------------------------html�ļ������β (��ajax)  $name ajax������ ����a��ҳ����,b���Ƿ���ʾ���ض���Ĭ�ϼ��أ�,$url ajaxͨ�ŵ�ַ,$beforeͨ��֮ǰ����,$afterͨ��֮�����,$post �Ƿ�ΪPOST
if(empty($name)||$name==''){$name='ajax(a)';}
if($post==1){$post='"POST"';}else{$post='"GET"';}
if(empty($send)||$send==''){$send='null';}
echo   '
<div id="dengdai" class="loaddiv" style="display: none;margin-left:9%;">
	<div class="circle-loader"><div class="circle-line"><div class="circle circle-blue"></div><div class="circle circle-blue"></div><div class="circle circle-blue"></div></div><div class="circle-line"><div class="circle circle-yellow"></div><div class="circle circle-yellow"></div><div class="circle circle-yellow"></div></div><div class="circle-line"><div class="circle circle-red"></div><div class="circle circle-red"></div><div class="circle circle-red"></div></div><div class="circle-line"><div class="circle circle-green"></div><div class="circle circle-green"></div><div class="circle circle-green"></div></div></div>
</div>
<script language="javascript" type="text/javascript">

function kong(){
	
}
function '.$name.'
{
if(b!=1){document.getElementById("dengdai").style.display="block";}
var caidan=document.getElementById("caidan").value;var canshu=document.getElementById("canshu").value;var canshu1=document.getElementById("canshu1").value;var canshu2=document.getElementById("canshu2").value;
var canshu3=document.getElementById("canshu3").value;var canshu4=document.getElementById("canshu4").value;var canshu5=document.getElementById("canshu5").value;var canshu6=document.getElementById("canshu6").value;
var neirong=document.getElementById("neirong").value;
'.$before.'
if (xmlHttp==null)
  {
  alert ("Browser does not support HTTP Request");
  return;
  } 
var url='.$url.';
xmlHttp.onreadystatechange=function (){ if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete"){ var resp=xmlHttp.responseText;
document.getElementById("dengdai").style.display="none";
'.$after.'
}}
xmlHttp.open('.$post.',url,true);
xmlHttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=UTF-8");
xmlHttp.send("ym="+a+"&caidan="+caidan+"&canshu1="+canshu1+"&canshu="+canshu+"&canshu2="+canshu2+"&canshu3="+canshu3+"&canshu4="+canshu4+"&canshu5="+canshu5+"&neirong="+neirong+"&canshu6="+canshu6);
} 

var xmlHttp;
xmlHttp=GetXmlHttpObject();
function GetXmlHttpObject(){var xmlHttp=null;try { xmlHttp=new XMLHttpRequest(); }catch (e) { try  {  xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");  } catch (e)  {  xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");  } }return xmlHttp;}
</script>
</body>
</html>
';
}


public function total_popup($id,$css,$position,$content){//-----------------------------------------------------------------------------------������   $id,$css,$position,$content      ������ťidΪ$id.a
echo   '
<div  id="'.$id.'"    style="position:fixed;z-index:9;top:0px;left:0px;width:100%;height:600px;display:none">
<div     style="position:fixed;z-index:9;'.$position.';width:100%;text-align:center;border:0px solid #F0F0F0;'.$css.'">
  '.$content.'
  </div>  </div>
<script>
$("#'.$id.'a").click(function(){
$("#'.$id.'").fadeIn(500);
});
$("#'.$id.'").click(function(){
$("#'.$id.'").fadeOut(500);
});
</script>
';
}

public function total_popup1($id,$css,$position,$content){//-----------------------------------------------------------------------------------������1   $id,$css,$position,$content      ������ťidΪ$id.a
echo   '
<div  id="'.$id.'"    style="position:fixed;z-index:9;top:0px;left:0px;width:100%;height:600px">
<div     style="position:fixed;z-index:9;'.$position.';width:100%;text-align:center;border:0px solid #F0F0F0;'.$css.'">
  '.$content.'
  </div>  </div>
<script>
$("#'.$id.'a").click(function(){
$("#'.$id.'").fadeIn(500);
});
$("#'.$id.'").click(function(){
$("#'.$id.'").fadeOut(500);
});
</script>
';
}






//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------body��
public function body_fy(array $array,$y1,$t1){//--------------------------------------��ҳ(���������������array($t2,$t3,$t,$t1,$y,$y1))   ������array $array  �б�����,$y1  ҳ��(�̶�Ϊ$_GET[ft0]),$t1ÿҳ����
$t=count($array);//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------������
if(empty($t1)){
$t1=30;//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ÿҳ����
}
$y=intval($t/$t1)+1;//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------��ҳ��
$t2=$y1*$t1;//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------��ʼ����
$t3=($y1+1)*$t1;//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------��������
//$arr=array($t2,$t3,$t,$t1,$y,$y1);//��ʼ���ţ��������ţ���������ÿҳ��������ҳ��,ҳ��
return  array($t2,$t3,$t,$t1,$y,$y1);//��ʼ���ţ��������ţ���������ÿҳ��������ҳ��,ҳ��
}






public function body_fyb_ajax($t2,$t3,$t,$t1,$y,$y1,$woheni){//---------------------------------------��ҳb ajax  ������$t2,$t3,$t,$t1,$y,$y1,��ʼ���ţ��������ţ���������ÿҳ��������ҳ��,ҳ�룻,$woheni��
echo  '<div   id="ff"  style="margin-top:8px"><input   id="yyy"   type="hidden"  value="'.$y1.'"></input>';
if(empty($y1)){$y1=0;}
//$y1=iconv('gb2312','gbk',$y1);
$TH='document.getElementById("fy").value='.$y1.';';
if($y>1){
if($y1>0){$x1=$y1-1;}else{$x1=$y1;}
if($y1<($y-1)){$x2=$y1+1;}else{$x2=$y1;}
echo  '<div  style=""><table  style="width:100%;height:30px"  border="0" cellspacing="0" cellpadding="0" ><tr  align="center"  style="background:#ADADAD"><td  style="width:25%;"  align="center"><a  href="javascript:void(0);" onclick="fy(\''.$x1.'\')" style="color:black"><div   style="background:#4F4F4F;color:#d0d0d0;font-size:25px"><<</div></a></td><td style="width:50%"><div  style="width:90%;overflow:scroll">
<select name="fy" id="fy" style="width:40%"  onchange="fy1()"  >';
for ($x=0; $x<$y; $x++) {$xx=$x;echo  '<option value="'.$xx.'">'.$xx.'</option>';}
echo  '</select></div></td><td  style="width:25%"  align="center"><a  href="javascript:void(0);" '; if($y1>=($y-1)){echo 'onclick="fy2()"';}else{echo 'onclick="fy(\''.$x2.'\')"';} echo  '  style="color:black"       class="fyclick"><div   style="background:#4F4F4F;color:#d0d0d0;font-size:25px">>></div></a></td></tr></table></div><div  style="filter:alpha(opacity=100);opacity:0;height:'.$woheni.'; ">woheni</div></div>
';
}else{
echo  '<div  style="filter:alpha(opacity=100);opacity:0;height:'.$woheni.';">woheni</div>';
}
}



public function body_fyb_ajax1($t2,$t3,$t,$t1,$y,$y1,$woheni,$func='fy',$fid='ff',$tishi='',$gundong='gdong',$ddl='��������'){//---------------------------------------��ҳb(�ۼ�) ajax  ������$t2,$t3,$t,$t1,$y,$y1,��ʼ���ţ��������ţ���������ÿҳ��������ҳ��,ҳ�룻woheni��,$func��������,$fid��ҳid��,$tishi��ť��ʾ,$gundong����id���,$ddl�����׵ı�־
echo  '<div   id="'.$fid.'"  style="margin-top:8px"><input   id="yyy"   type="hidden"  value="'.$y1.'"></input>';
$shy=$t-$t3;
if($shy<=0){$shy=$ddl;}else{if($tishi==''){$shy='����'.$shy.'����Ϣ,�����鿴';}else{$shy=$tishi;}}
if(empty($y1)){$y1=0;}
//$y1=iconv('gb2312','gbk',$y1);
$TH='document.getElementById("fy").value='.$y1.';';
if($y>=1){
if($y1>0){$x1=$y1-1;}else{$x1=$y1;}
if($y1<($y-1)){$x2=$y1+1;}else{$x2=$y1;}
echo  '<div  style=""><table  style="width:100%;height:30px"  border="0" cellspacing="0" cellpadding="0" ><tr  align="center"  style="">
';

echo  '<td  style="width:25%"  align="center">';
if($shy=="��������"){
echo  '<a  href="javascript:void(0);" onclick="kong()" style="color:black"      class="fyclick"      id="'.$gundong.'">';
}else{
echo '<a  href="javascript:void(0);" onclick="'.$func.'(\''.$x2.'\')" style="color:black"     class="fyclick"    id="'.$gundong.'">';
}

echo  '<div   style="color:#9D9D9D;font-size:15px">'.$shy.'</div></a></td></tr></table></div><div style="filter:alpha(opacity=100);opacity:0;height:'.$woheni.';">woheni</div></div>
';
}else{
echo  '<div style="filter:alpha(opacity=100);opacity:0;height:'.$woheni.';">woheni</div></div>';
}
}




}

?>
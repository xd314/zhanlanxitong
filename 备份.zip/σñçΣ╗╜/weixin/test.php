<?php
/*
*调用微信接口的固定php文件。
*by xd314 2018.12.11
*/
require_once('class/wx_config.php');
header('Access-Control-Allow-Origin:*');
    $post_data=array();
    $result=json_decode(send_post('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$wxgzhappid.'&secret='.$wxgzhsecret,$post_data),true);
  //建立会话
    //$post_data="{\"openid\": \"ois3fspkfu2sqq73bdiJDBB09d4Q\",\"kf_account\": \"kf2002@hlxh999999999\"}";
    //$result1=json_decode(http_post_data('https://api.weixin.qq.com/customservice/kfsession/create?access_token='.$result['access_token'],$post_data),true);
    
//发送信息
    $post_data="{\"touser\": \"ois3fspkfu2sqq73bdiJDBB09d4Q\",\"msgtype\": \"text\",\"text\": {\"content\": \"Hello World\"}}";
    $result1=json_decode(http_post_data('https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token='.$result['access_token'],$post_data),true);
    
    //$post_data=array("touser"=>"ois3fskhDWKjppQEJyrQicfvsHw4","msgtype"=>"text","text"=>array("content"=>"Hello World"));
    //$result1=json_decode(send_post('https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token='.$result['access_token'],$post_data),true);
print_r($result1);
function send_post($url, $post_data) {
  $postdata = http_build_query($post_data);
  $options = array(
    'http' => array(
      'method' => 'POST',
      'header' => 'Content-type:application/x-www-form-urlencoded',
      'content' => $postdata,
      'timeout' => 15 * 60 // 超时时间（单位:s）
    )
  );
  $context = stream_context_create($options);
  $result = file_get_contents($url, false, $context);
  return $result;
}
    
    function http_post_data($url, $data_string) {
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                                   'Content-Type: application/json; charset=utf-8',
                                                   'Content-Length: ' . strlen($data_string))
                    );
        ob_start();
        curl_exec($ch);
        $return_content = ob_get_contents();
        //echo $return_content."<br>";
        ob_end_clean();
        
        $return_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        //  return array($return_code, $return_content);
        return  $return_content;
    }
    
   
?>

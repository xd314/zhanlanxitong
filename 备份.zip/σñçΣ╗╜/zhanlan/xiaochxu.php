<?php
header('Access-Control-Allow-Origin:*');
require_once('class/mysql_xd314.php');
require_once('class/basic_xd314.php');
require_once('class/user_xd314.php');
$mysql_xd314=new  mysql_xd314;
$basic_xd314=new  basic_xd314;
$user_xd314=new  user_xd314;
switch ($_POST["caidan"]){
case 'login'://登陆
        $post_data = array();
        $array=json_decode(send_post('https://api.weixin.qq.com/sns/jscode2session?appid=wx4ae0d9cc5bbf8920&secret=30da86e45429f93d8fbb574a7e4f5727&js_code='.$_POST['code'].'&grant_type=authorization_code', $post_data),true);
        if(!login($array['openid'])){
        echo json_encode(array('openid'=>''));//data为数据
        }else{
            echo json_encode(array('openid'=>$array['openid']));//data为数据
        }
break;
    case 'pay':
        if(!empty($_POST['number'])){
            $user=$mysql_xd314->search('pre_user'," WHERE openid='".$_POST['openid']."'")[0];
            $nonce_str=str_rand();
            $time=time();
            if(empty($_POST['out_trade_no'])){$_POST['out_trade_no']=$user['id'].'axdt'.$time;}
            $ip=get_ip();
            $mysql_xd314->delete('pre_xd314_pay',"  WHERE state=0 AND payuid=".$user['id']);
            $_POST['number']=$_POST['number']*100;
            $mysql_xd314->increase('pre_xd314_pay'," SET orderid='".$_POST['out_trade_no']."',transaction_id='',title='鲜花',money=".$_POST['number'].",source='axdt_pay',paytype='wx',identification='',establish_time=".time().",pay_time=0,state=0,notify_url='https://axd-t.com/weixin/NotifyCoursePayment.php',objectid=".$_POST['objectid'].",touid=0,payuid=".$user['id']);
            
            $stringA='appid=wx4ae0d9cc5bbf8920&body=axdt_pay&device_info=axdt&mch_id=1507891651&nonce_str='.$nonce_str.'&notify_url='.$_POST['notify_url'].'&openid='.$_POST['openid'].'&out_trade_no='.$_POST['out_trade_no'].'&spbill_create_ip='.$ip.'&total_fee='.$_POST['number'].'&trade_type=JSAPI&key=123456qwerty098765poiuytzxcvbnas';
            $sign=strtoupper(md5($stringA));
            $post_data='
            <xml>
            <appid><![CDATA[wx4ae0d9cc5bbf8920]]></appid>
            <body><![CDATA[axdt_pay]]></body>
            <device_info><![CDATA[axdt]]></device_info>
            <mch_id><![CDATA[1507891651]]></mch_id>
            <nonce_str><![CDATA['.$nonce_str.']]></nonce_str>
            <notify_url><![CDATA['.$_POST['notify_url'].']]></notify_url>
            <openid><![CDATA['.$_POST['openid'].']]></openid>
            <out_trade_no><![CDATA['.$_POST['out_trade_no'].']]></out_trade_no>
            <spbill_create_ip><![CDATA['.$ip.']]></spbill_create_ip>
            <total_fee><![CDATA['.$_POST['number'].']]></total_fee>
            <trade_type><![CDATA[JSAPI]]></trade_type>
            <sign><![CDATA['.$sign.']]></sign>
            </xml>';
            //print_r($_COOKIE);
            $data=https_post('https://api.mch.weixin.qq.com/pay/unifiedorder',$post_data);
            $data=xmlToArray($data);
           ///*
            $data1['appId']='wx4ae0d9cc5bbf8920';
            $data1['timeStamp']=''.$time;
            $data1['nonceStr']=$data['nonce_str'];
            $data1['prepay_id']=$data['prepay_id'];
            $data1['package']='prepay_id='.$data['prepay_id'];
            $data1['signType']='MD5';
            $str='appId='.$data1['appId'].'&nonceStr='.$data1['nonceStr'].'&package='.$data1['package'].'&signType='.$data1['signType'].'&timeStamp='.$data1['timeStamp'].'&key=123456qwerty098765poiuytzxcvbnas';
            $data1['paySign']=strtoupper(md5($str));
            $data1['url']='https://axd-t.com/weixin/wx_index.php?state=xh';
            //*/
            echo json_encode(array('data'=>$data1,'state'=>'success'));//data为数据
        }else{
            echo json_encode(array('state'=>'fail'));//data为数据
        }
        break;
case 'FanKuiTuiSong'://反馈推送信息。在页面和短信上分别通知
$usertrack=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND   openid='".$_POST['openid']."'",' id,chpjiage,chpshuliang,chpname ');
$usertrack1=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND state1=1 AND  openid='".$_POST['openid']."'",' id,chpname ');
$usertrack2=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND  state1=2 AND openid='".$_POST['openid']."'",' id,chpname ');
$usertrack3=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND  state1=3 AND openid='".$_POST['openid']."'",' id,chpname ');
$usertrack4=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND state1=4 AND openid='".$_POST['openid']."'",' id,chpname ');
$usertrack5=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND  state1=5 AND openid='".$_POST['openid']."'",' id,chpname ');

if(count($usertrack4)>0){//用户已评价
    $track=$usertrack4;
$FeedbackPush='感谢您的光临，我将再接再厉，精益求精，努力为您提供更好的服务！您可以在【相关信息】【自我介绍】中关注本店公众号获取更多本店信息！';
$a=$mysql_xd314->modify('pre_usertrack'," SET state=1 WHERE id=".$usertrack4[0]['id']);
}else if(count($usertrack3)>0){//用户已收到货物
    $track=$usertrack3;
$FeedbackPush='请点击<span style="color:#FF9797;" onclick="tucao1()">此处</span>给个评价或者建议吧！非常感谢！';
}else if(count($usertrack2)>0){//商家已完成订单
    $track=$usertrack2;
$FeedbackPush='产品【'.$usertrack2[0]['chpname'].'】已完成订单，请查看是否收到货物！如果收到请点击<span style="color:#FF9797;" onclick="shezhiliucheng(\''.$usertrack2[0]['id'].'\',3)">此处</span>确定收到！';
}else if(count($usertrack1)>0){//用户已支付
    $track=$usertrack1;
$FeedbackPush='产品【'.$usertrack1[0]['chpname'].'】已支付，请等待商家制作';
}else if(count($usertrack)>0){//订单建立
    $track=$usertrack;
    $FeedbackPush='产品【'.$usertrack[0]['chpname'].'】已提交订单！请点<span style="color:#FF9797;" onclick="pay(\''.$usertrack[0]['id'].'\', \''.$usertrack[0]['chpjiage'].'\', \''.$usertrack[0]['chpshuliang'].'\')">此处</span>完成支付！之后才可以提供商品服务！';
}else{
    $FeedbackPush='';
       $track=[];
}     
        
        
echo json_encode(array('data'=>$FeedbackPush,'track'=>$track[0]));
break;
case 'tucao':
if(!empty($_POST['tucao'])&&!empty($_POST['openid'])){
$a=$mysql_xd314->increase('pre_words'," SET words='".$_POST['tucao']."',openid='".$_POST['openid']."',time='".time()."',x1='".$_POST['trackid']."'");
$a=$mysql_xd314->modify('pre_usertrack'," SET state1=4 WHERE id=".$_POST['trackid']);
echo json_encode(array('state'=>'已发送'));
}else{
echo json_encode(array('state'=>'Missing'));
}
break;
case 'shezhiliucheng':
if(!empty($_POST['state'])&&!empty($_POST['trackid'])){
$a=$mysql_xd314->modify('pre_usertrack'," SET state1=".$_POST['state']." WHERE id=".$_POST['trackid']);
            echo json_encode(array('state'=>true));
    }else{
        echo json_encode(array('state'=>'Missing')); 
    }
break;
case 'main1':
$array=$mysql_xd314->search('pre_chpk',"    WHERE  tid=".$_POST['tid']);
        $fso=opendir('../hl_product/hl'.$_POST['tid'].'/');
        $a=0;
        while($flist=readdir($fso)){
            if($flist!="."&&$flist!=".."){
                $pimg[]='https://www.axd-t.com/hl_product/hl'.$_POST['tid'].'/'.$flist;
                $a+=1;
            }
        }
        closedir($fso);
echo json_encode(array('data'=>$array,'data1'=>$pimg));
break;
case 'nlist':
$array=$mysql_xd314->search('pre_chpk',"    WHERE x='产品'  AND  x1='鲜花'  AND x24='1'   ORDER BY  tid  ASC");
echo json_encode(array('data'=>$array));//data为数据,页码 
break;
case 'yigou':
$array=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1 AND  openid='".$_POST['openid']."'");
foreach($array as $key=>$value){
if(empty($value['chpname'])){$value['chpname']='';}
if(empty($value['chpjiage'])){$value['chpjiage']='';}
if(empty($value['chptubiao'])){$value['chptubiao']='';}
//$chpk=$mysql_xd314->search('pre_chpk',"  WHERE  tid=".$value['chpid'],' tubiao ')[0];
$value['title']=$value['chpname'];
$value['jiage']=$value['chpjiage'];
$value['tubiao']=$value['chptubiao'];
$value['time']=date('Y-m-d h:i',$value['time']);
$value['fk']='<view>aaaaaa</view>';
$array[$key]=$value;
}
echo json_encode(array('data'=>$array));//data为数据,页码 
break;
case 'article':
$array=$mysql_xd314->search('pre_chpk',"   WHERE x='文章' AND x1='鲜花' ",' tid,title,tubiao ');
echo json_encode(array('data'=>$array));//data为数据,页码 
break;
case 'shdz':
$user=$mysql_xd314->search('pre_user'," WHERE openid='".$_POST['openid']."'");
$array1=$mysql_xd314->search('pre_usertrack'," WHERE openid='".$_POST['openid']."' AND chpid=".$_POST['tid']." AND NOT state=1");
if(count($array1)>0){
    $array['shuliang']=$array1[0]['chpshuliang'];
    $array['kapian']=$array1[0]['kapian'];
    $array['dizhi']=$array1[0]['dizhi'];
    $array['beizhu']=$array1[0]['beizhu'];
}else{
$array['shuliang']='';
    $array['kapian']='';
    $array['dizhi']='';
    $array['beizhu']='';
}

echo json_encode(array('data'=>$array,'phone'=>$user[0]['phone']));//data为数据,页码
break;
case 'yhxinxi':
$aa=$mysql_xd314->search('pre_user'," WHERE openid='".$_POST['openid']."'")[0];
$array=array();
$array['phone']=$aa['phone'];
echo json_encode(array('data'=>$array));
break;
case 'fs':
$usertrack=$mysql_xd314->search('pre_usertrack'," WHERE openid='".$_POST['openid']."' AND chpid='".$_POST['tid']."' AND  NOT state=1 ",' id ');
$chpk=$mysql_xd314->search('pre_chpk',"    WHERE tid=".$_POST['tid'],' title,jiage,tubiao ')[0];
if(empty($_POST['shuling'])||$_POST['shuling']==''){$_POST['shuling']=1;}
if(count($usertrack)<1){
$a=$mysql_xd314->increase('pre_usertrack'," SET chpid='".$_POST['tid']."',chpshuliang='".$_POST['shuling']."',kapian='".$_POST['kapian']."',dizhi='".$_POST['dizhi']."',beizhu='".$_POST['beizhu']."',openid='".$_POST['openid']."',time='".time()."',tuiguang='".$_POST['tuiguang']."',state=0,chpname='".$chpk['title']."',chpjiage='".$chpk['jiage']."',chptubiao='".$chpk['tubiao']."'");
}else{
$a=$mysql_xd314->modify('pre_usertrack'," SET kapian='".$_POST['kapian']."',dizhi='".$_POST['dizhi']."',beizhu='".$_POST['beizhu']."' WHERE openid='".$_POST['openid']."' AND chpid='".$_POST['tid']."' AND  state=0");
}

echo json_encode(array('data'=>'ok'));
break;
case 'fsyonghu':
if(!empty($_POST['phone'])&&!empty($_POST['openid'])){
    $_POST['caidan']='yanzheng';
    $post_data=$_POST;
    $code=json_decode(send_post('https://www.axd-t.com/dysms/msg.php',$post_data),true);
    if($_POST['yanzheng']==$code){
$a=$mysql_xd314->modify('pre_user'," SET phone='".$_POST['phone']."' WHERE openid='".$_POST['openid']."'");
        $usertrack=$mysql_xd314->search('pre_usertrack'," WHERE openid='".$_POST['openid']."' AND chpid='".$_POST['tid']."' AND  NOT state=1 ",' id ');
        $chpk=$mysql_xd314->search('pre_chpk',"    WHERE tid=".$_POST['tid'],' title,jiage,tubiao ')[0];
        if(empty($_POST['shuling'])||$_POST['shuling']==''){$_POST['shuling']=1;}
        if(count($usertrack)<1){
            $a=$mysql_xd314->increase('pre_usertrack'," SET chpid='".$_POST['tid']."',chpshuliang='".$_POST['shuling']."',kapian='".$_POST['kapian']."',dizhi='".$_POST['dizhi']."',beizhu='".$_POST['beizhu']."',openid='".$_POST['openid']."',time='".time()."',tuiguang='".$_POST['tuiguang']."',state=0,chpname='".$chpk['title']."',chpjiage='".$chpk['jiage']."',chptubiao='".$chpk['tubiao']."'");
        }else{
            $a=$mysql_xd314->modify('pre_usertrack'," SET kapian='".$_POST['kapian']."',dizhi='".$_POST['dizhi']."',beizhu='".$_POST['beizhu']."' WHERE openid='".$_POST['openid']."' AND chpid='".$_POST['tid']."' AND  state=0");
        }
       
        echo json_encode(array('state'=>'已提交'));
}else{
    echo json_encode(array('state'=>'请填写验证码！'.$_POST['yanzheng'].'|'.$code));
}
}else{
    echo json_encode(array('state'=>'请填写完整！'.$_POST['phone'].'|'.$_POST['openid']));
}
break;
default:
echo json_encode('参数缺失');
break;
}


                                      function https_post($url,$data,$ssl = false)
                                      {
                                      $ch = curl_init ();
                                      curl_setopt ( $ch, CURLOPT_URL, $url );
                                      curl_setopt ( $ch, CURLOPT_CUSTOMREQUEST, "POST" );
                                      curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
                                      curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, FALSE );
                                      if($ssl) {
                                      curl_setopt ( $ch,CURLOPT_SSLCERT,$this->sslcert_path);
                                      curl_setopt ( $ch,CURLOPT_SSLKEY,$this->sslkey_path);
                                      }
                                      curl_setopt ( $ch, CURLOPT_FOLLOWLOCATION, 1 );
                                      curl_setopt ( $ch, CURLOPT_AUTOREFERER, 1 );
                                      curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data );
                                      curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
                                      $result = curl_exec($ch);
                                      if (curl_errno($ch)) {
                                      return 'Errno: '.curl_error($ch);
                                      }
                                      curl_close($ch);
                                      return $result;
                                      }
                                      
                                      function xmlToArray($xml)
                                      {
                                      libxml_disable_entity_loader(true);
                                      $xmlstring = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA);
                                      $val = json_decode(json_encode($xmlstring),true);
                                      return $val;
                                      }
                                      
                                      
                                      function str_rand($length = 32, $char = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') {
                                      if(!is_int($length) || $length < 0) {
                                      return false;
                                      }
                                      
                                      $string = '';
                                      for($i = $length; $i > 0; $i--) {
                                      $string .= $char[mt_rand(0, strlen($char) - 1)];
                                      }
                                      
                                      return $string;
                                      }
                                      
                                      function get_ip()
                                      {
                                      foreach (array(
                                                     'HTTP_CLIENT_IP',
                                                     'HTTP_X_FORWARDED_FOR',
                                                     'HTTP_X_FORWARDED',
                                                     'HTTP_X_CLUSTER_CLIENT_IP',
                                                     'HTTP_FORWARDED_FOR',
                                                     'HTTP_FORWARDED',
                                                     'REMOTE_ADDR') as $key) {
                                      if (array_key_exists($key, $_SERVER)) {
                                      foreach (explode(',', $_SERVER[$key]) as $ip) {
                                      $ip = trim($ip);
                                      if ((bool) filter_var($ip, FILTER_VALIDATE_IP,
                                                            FILTER_FLAG_IPV4 |
                                                            FILTER_FLAG_NO_PRIV_RANGE |
                                                            FILTER_FLAG_NO_RES_RANGE)) {
                                      return $ip;
                                      }
                                      }
                                      }
                                      }
                                      return null;
                                      }

                                      
function send_post($url, $post_data) {
    $postdata = http_build_query($post_data);
    $options = array(
      'http' => array(
        'method' => 'POST',
        'header' => 'Content-type:application/x-www-form-urlencoded',
        'content' => $postdata,
        'timeout' => 15 * 60 // 超时时间（单位:s）
      )
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    return $result;
  }
    
    function login($openid){
        $mysql_xd314=new  mysql_xd314;
        if(!empty($openid)){
            //$xiaochxu=array();
            $xiaochxu=$mysql_xd314->search('pre_user'," WHERE openid='".$openid."' ");
            
            if(count($xiaochxu)<1){
                //echo   json_encode($xiaochxu);
                $xiaochxu1=$mysql_xd314->search('pre_user'," ORDER BY  id  DESC "," id ")[0];
                $xiaochxu1['id']=$xiaochxu1['id']+1;
                $mysql_xd314->increase('pre_user'," SET id=".$xiaochxu1['id'].",time='".time()."',openid='".$openid."' ");
                // $mysql_xd314->modify('pre_wjx'," SET x='aaa',yid=1");
            }
            //echo   json_encode($xiaochxu);
            return true;//---------------------------------------------------登录
        }else{
            //echo $openid;
            return false;//---------------------------------------------------没有登录
        }
    }

?>

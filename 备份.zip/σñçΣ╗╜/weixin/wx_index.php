<?php
require_once('class/wx_config.php');
require_once('class/mysql_xd314.php');
if(empty($_GET['code'])){
  $appid = $wxgzhappid;
  $redir = urlencode('https://'.$domainname.'/weixin/wx_index.php');
  $authPage = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$appid.'&redirect_uri='.$redir.'&response_type=code&scope=snsapi_base&state='.$_GET['state'].'#wechat_redirect';
  header('location:'.$authPage);
  exit();
  }else{
        $post_data=array();
        $openid=json_decode(send_post('https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$wxgzhappid.'&secret='.$wxgzhsecret.'&code='.$_GET['code'].'&grant_type=authorization_code',$post_data),true);
        setcookie('openid',$openid['openid'],time()+7200,'/');
$mysql_xd314=new  mysql_xd314;
//exit($_COOKIE["openid"]);
      if(!login($openid['openid'])){exit('登录失败');}
      $user=$mysql_xd314->search('pre_user'," WHERE openid='".$openid['openid']."'")[0];
//login($openid['openid']);exit($openid['openid']);
$xddata=explode('-',$_GET['state']);//0为页面名，1为页面状态，2为分享者openid，3为打开的页面功能代号。
      if(!empty($xddata[2])&&$xddata[2]!=''){
        setcookie('tuiguang',$xddata[2],time()+7200,'/');
      }
 if(empty($xddata[3])||$xddata[3]==''){
         $xddata[3]=0;
      }
setcookie('func',$xddata[3],time()+7200,'/');//设置打开的页面功能
switch($xddata[0]){
case 'zpay'://支付 $_GET['state']格式：支付-（价格数）-（支付者uid）-（对象id）
$usertrack=$mysql_xd314->search('pre_usertrack',"  WHERE  state=0  AND  state1=0 AND NOT x2='1'  AND openid='".$openid['openid']."'",' id,chpjiage,chpshuliang,chpname ');
        $zjiage=0;
        $sycp='';
        $zshuliang=0;
foreach($usertrack as $key=>$value){
    $sycp=$sycp.$value['id'].'-';
    $zjiage=0.1;
    $zshuliang=$zshuliang+intval($value['chpshuliang']);
}
$out_trade_no=$usertrack[0]['id'].'t'.time();
setcookie('wxnumber',$zjiage,time()+7200,'/');
$xddata[1]=$zjiage*100;//以分为单位
setcookie('out_trade_no',$out_trade_no,time()+7200,'/');
setcookie('wxcid',$usertrack[0]['id'],time()+7200,'/');
setcookie('notify_url','https://axd-t.com/weixin/NotifyCoursePayment1.php',time()+7200,'/');
$mysql_xd314->delete('pre_xd314_pay',"  WHERE state1=0 AND payuid=".$user['id']);
$mysql_xd314->increase('pre_xd314_pay'," SET orderid='".$out_trade_no."',transaction_id='',title='鲜花',money=".$xddata[1].",source='xd314_pay',paytype='wx',identification='',establish_time=".time().",pay_time=0,state=0,notify_url='https://axd-t.com/weixin/NotifyCoursePayment1.php',objectid='".$sycp."',touid=0,payuid=".$user['id'].",openid='".$openid['openid']."'");
        //exit($sycp);
echo ' <script>window.location.href = "https://'.$domainname.'/weixin/wxpay.html";</script>';
break;
case 'pay'://支付 $_GET['state']格式：支付-（价格数）-（支付者uid）-（对象id）
$out_trade_no=$xddata[3].'t'.time();
setcookie('wxnumber',$xddata[1],time()+7200,'/');
$xddata[1]=$xddata[1]*100;//以分为单位
setcookie('out_trade_no',$out_trade_no,time()+7200,'/');
setcookie('wxcid',$xddata[3],time()+7200,'/');
setcookie('notify_url','https://axd-t.com/weixin/NotifyCoursePayment.php',time()+7200,'/');
$mysql_xd314->delete('pre_xd314_pay',"  WHERE state=0 AND payuid=".$user['id']);
$mysql_xd314->increase('pre_xd314_pay'," SET orderid='".$out_trade_no."',transaction_id='',title='鲜花',money=".intval($xddata[1]).",source='xd314_pay',paytype='wx',identification='',establish_time=".time().",pay_time=0,state=0,notify_url='https://axd-t.com/weixin/NotifyCoursePayment.php',objectid='".$xddata[3]."',touid=0,payuid=".$user['id'].",,openid='".$openid['openid']."'");
echo ' <script>window.location.href = "https://'.$domainname.'/weixin/wxpay.html";</script>';
break;
case 'xh2'://鲜花 $_GET['state']格式：xh-（价格数）-产品id-推广者id-功能id
if(empty($xddata[1])){//目标地址的参数最多不能超过一个。否则微信接口设置签字将不会通过。
echo ' <script>window.location.href = "https://'.$domainname.'/zhanlan/xh2.html?state=277";</script>';
}else{
echo ' <script>window.location.href = "https://'.$domainname.'/zhanlan/xh2.html?state='.$xddata[1].'";</script>';
}
break;
case 'xh1'://鲜花 $_GET['state']格式：xh-（价格数）-产品id-推广者id-功能id
if(empty($xddata[1])){//目标地址的参数最多不能超过一个。否则微信接口设置签字将不会通过。
echo ' <script>window.location.href = "https://'.$domainname.'/zhanlan/xh.html?state=277";</script>';
}else{
echo ' <script>window.location.href = "https://'.$domainname.'/zhanlan/xh.html?state='.$xddata[1].'";</script>';
}
break;
case 'xh'://鲜花 $_GET['state']格式：xh-（价格数）-产品id-推广者id-功能id
if(empty($xddata[1])){//目标地址的参数最多不能超过一个。否则微信接口设置签字将不会通过。
echo ' <script>window.location.href = "https://'.$domainname.'/zhanlan/xh1.html?yuangong=16";</script>';
}else{
echo ' <script>window.location.href = "https://'.$domainname.'/zhanlan/xh1.html?yuangong='.$xddata[1].'";</script>';
}
break;
case 'manage'://管理
echo ' <script>window.location.href = "https://'.$domainname.'/zhanlan/manage.html";</script>';
break;
case 'qishi'://原石文化
echo ' <script>window.location.href = "https://'.$domainname.'/zhanlan/main.html";</script>';
break;
default:
echo 'asdfhjkl';
break;
}

}

function login($openid){
$mysql_xd314=new  mysql_xd314;
if(!empty($openid)){
  //$xiaochxu=array();
$xiaochxu=$mysql_xd314->search('pre_user'," WHERE openid='".$openid."' ");

if(count($xiaochxu)<1){
  //echo   json_encode($xiaochxu);
  $xiaochxu1=$mysql_xd314->search('pre_user'," ORDER BY  id  DESC "," id ")[0];
    $xiaochxu1['id']=$xiaochxu1['id']+1;
  $mysql_xd314->increase('pre_user'," SET id=".$xiaochxu1['id'].",time='".time()."',openid='".$openid."' ");
 // $mysql_xd314->modify('pre_wjx'," SET x='aaa',yid=1");
}
//echo   json_encode($xiaochxu);
return true;//---------------------------------------------------登录
}else{
  //echo $openid;
return false;//---------------------------------------------------没有登录
}
}

function send_post($url, $post_data) {
  $postdata = http_build_query($post_data);
  $options = array(
    'http' => array(
      'method' => 'POST',
      'header' => 'Content-type:application/x-www-form-urlencoded',
      'content' => $postdata,
      'timeout' => 15 * 60 // 超时时间（单位:s）
    )
  );
  $context = stream_context_create($options);
  $result = file_get_contents($url, false, $context);
  return $result;
}
?>

<?php
require_once('class/mysql_xd314.php');
$mysql_xd314=new  mysql_xd314;
//echo $mysql_xd314->a();
$xml=file_get_contents('php://input', 'r'); 
// 转成php数组
$data=xmlToArray($xml);
$out_trade_no=$data["out_trade_no"];
//$aa=implode('|',$_SERVER)
    $pay=$mysql_xd314->search('pre_xd314_pay',"  WHERE orderid='".$data["out_trade_no"]."'");
    if($pay[0]['state']==0){
        $post_data=array('caidan'=>'fasong1','phone'=>19952110314,'moban'=>'SMS_157448090','name'=>$pay[0]['objectid']);
        $code=json_decode(send_post('https://www.axd-t.com/dysms/msg.php',$post_data),true);
        
        $user=$mysql_xd314->search('pre_user',"  WHERE openid='".$pay[0]['openid']."'");
        $post_data=array('caidan'=>'fasong1','phone'=>$user[0]['phone'],'moban'=>'SMS_157448090','name'=>$pay[0]['objectid']);
        $code=json_decode(send_post('https://www.axd-t.com/dysms/msg.php',$post_data),true);
        $mysql_xd314->modify('pre_xd314_pay'," SET transaction_id='".$data['transaction_id']."',state=1,pay_time=".time()."  WHERE orderid='".$data["out_trade_no"]."'");
        $pay=$mysql_xd314->search('pre_xd314_pay',"  WHERE orderid='".$data["out_trade_no"]."'");
        $a=$mysql_xd314->modify('pre_usertrack'," SET state1=1,x3='".$data["out_trade_no"]."'  WHERE state=0  AND  state1=0 AND NOT x2='1'  AND openid='".$pay[0]['openid']."'");
    }

function xmlToArray($xml)
    {
        libxml_disable_entity_loader(true);
        $xmlstring = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA);
        $val = json_decode(json_encode($xmlstring),true);
        return $val;
    }
    
    function send_post($url, $post_data) {
        $postdata = http_build_query($post_data);
        $options = array(
                         'http' => array(
                                         'method' => 'POST',
                                         'header' => 'Content-type:application/x-www-form-urlencoded',
                                         'content' => $postdata,
                                         'timeout' => 15 * 60 // 超时时间（单位:s）
                                         )
                         );
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        return $result;
    }

?>

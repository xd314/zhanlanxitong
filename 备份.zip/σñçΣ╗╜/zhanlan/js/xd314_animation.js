//展览系统动画js文件
//黄楼鲜花礼品 徐丹 2019.1.19
var animation={SetOpacity:function(ev,v){
    ev.filters?ev.style.filter='alpha(opacity='+v+')':ev.style.opacity=v/100}}
function fadeIn(elem,toumingdu=90){
    elem.style.opacity=0;elem.style.display="block";var i1;var val=0;(function fn(){animation.SetOpacity(elem,val);val+=2;if(val<=toumingdu){setTimeout(fn,20)}})()}
function fadeOut(elem){
    elem.style.opacity=0.9;var i1;var val=90;(function fn1(){animation.SetOpacity(elem,val);val-=2;if(val>1){setTimeout(fn1,15)}else{elem.style.display="none"}})()}

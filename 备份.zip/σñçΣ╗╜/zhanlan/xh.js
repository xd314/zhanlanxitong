//鲜花展览系统js文件
//黄楼鲜花礼品 徐丹 2019.1.19
//alert(xd314.Cookie('openid'));

if (xd314.Cookie('openid') == 'undefined') { xd314.Href('https://axd-t.com/weixin/wx_index.php?state=xh-' + xd314.GetState()); }
xd314.ShowInit();
 loading();
xd314.IdInit(["beizhu2","beizhu1","M12","yanzheng","M11","body", "wych", "yigou", "M9","M", "M2", "M4", "lis", "Mb", "M5", "M8", "M7","M7a", "phone", "shuliang","M10","beizhu4","beizhu3","phone3"]);
//xd314.Id.body.onscroll = function () { reset(); };
xd314.Id.M4.style.height = xd314.Height * 60 / 100 + 'px';
xd314.Id.M8.style.height = document.body.clientHeight + 'px';
xd314.Id.M9.style.height = xd314.Height * 45 / 100 + 'px';
var x = 0;
var tid;
var product = [];
var track = [];
var user = [];
var pimg = [];
var scrolltop;
var fsong=0;
var fsshouhuo=1;
function conf() {
    xd314.DATA = {
    method: 'POST',
    url: 'https://www.axd-t.com/weixin/xd314_weixin.php',
    data: {
    caidan: 'access',
    cururl: window.location.href
    },
    success: function (respone) {
        xdwx.Config();
    }
    };
    xd314.AJAX(xd314.DATA);
}

wx.ready(function () {
         sharepongyouquan();
         FanKuiTuiSong();
         });

function sharepongyouquan() {//product.title
    wx.onMenuShareTimeline({
                           title: product.title,
                           link: 'https://axd-t.com/weixin/wx_index.php?state=xh1-' + product.tid + '-' + xd314.Cookie('openid')+'-0',
                           imgUrl: product.tubiao,
                           success: function () { }
                           });
    wx.onMenuShareAppMessage({
                             title: product.title,
                             desc: '呵护健康美好生活',
                             link: 'https://axd-t.com/weixin/wx_index.php?state=xh1-' + product.tid + '-' + xd314.Cookie('openid')+'-0',
                             imgUrl: product.tubiao,
                             success: function () { }
                             
                             });
}

function FanKuiTuiSong() {
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    xd314.DATA.data = {
    caidan: 'FanKuiTuiSong',
    openid: xd314.Cookie('openid')
    };
    xd314.DATA.success = function (respone) {
        track=respone.track;
        xd314.S_O('div',xd314.Id.body,'addshouhuoxinxi','addshouhuoxinxi','aaaaaa',function(e){xd314.Click(xd314.Id1('beizhu1'),function(){  xd314.Id.M11.style.display = 'none';
          xd314.EmptyChild(e);
     
xd314.S_O('div',e,'addshouhuoxinxia','addshouhuoxinxib','点击添加',function(e1){xd314.Click(e1,shouhuo);});
 //xd314.click('addshouhuoxinxia',function(e){ e.style.display='none';});
            xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
            xd314.DATA.data = {
            caidan: 'shouhuoxinxi',
            openid: xd314.Cookie('openid')
            };
            xd314.DATA.success = function (respone) {
     if(respone.data.length<1){
      shouhuo();
    e1.style.display='none';
    }else{
        for (var i = 0; i < respone.data.length; i++) {
 xd314.S_O('div',e,'addshouhuoxinxi'+i,'addshouhuoxinxia','',function(e2){
           xd314.S_O('span',e2,'neirong'+i,'shanchu1','',function(e3){e3.innerHTML ='姓名：'+respone.data[i].name+'<br/>电话：'+respone.data[i].phone+'<br/>地址：'+respone.data[i].dizhi;
                      xd314.Click(e3,function(){xd314.Id1('beizhu1').value=e3.innerHTML;e.style.display='none';});
                     
                     });
           
           
           xd314.S_O('div',e2,'shanchu'+respone.data[i].id,'shanchu','-',function(e3a){
                     xd314.Click(e3a,function(){
                                 if(confirm("确定删除么?")){
                                 xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
                                 xd314.DATA.data = {
                                 caidan: 'dizhishanchu',
                                 id:e3a.id.split('shanchu')[1]
                                 };
                                 xd314.DATA.success = function (respone1){
                                                               // alert(respone.data[i].name);
                                  alert(respone1.state);
                                 //xd314.D_S_O(e2);
                                 //xd314.Id1('beizhu1').Click();
                                // 'addshouhuoxinxi'+i
                                 xd314.D_S_O(e2);
                                 };
                                 xd314.AJAX(xd314.DATA);
                                 }
                                 });
                     
                     });
          });
    }
}
   //e.innerHTML=respone;
            e.style.display='block';
 };
   xd314.AJAX(xd314.DATA);

    });
                  xd314.Click(xd314.Id1('M2'),function(){
                              e.style.display='none';
                              });
                  });
        shdz();
        if (xd314.Cookie('func') == 1) {
            fsong=1;
            xd314.Id1('M7a').style.display='block';
            xd314.Id1('goumai').innerHTML='提交';
        }else if (xd314.Cookie('func') == 2){
            
        }else{
            shdz();
        }
    };
    xd314.AJAX(xd314.DATA);
}

function loading(){
   xd314.Show('<div class="column" style=" display: flex;justify-content: center;"><div class="container animation-1"><div class="shape shape1"></div><div class="shape shape2"></div><div class="shape shape3"></div><div class="shape shape4"></div></div></div>','33%',false);
}

window.onload = function () {
    if (xd314.GetState() == 'undefined') {
        tid = 1;
    } else {
        tid = xd314.GetState();
    }
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    xd314.DATA.data = {
    caidan: 'main1',
    id: tid
    };
    xd314.DATA.success = function (respone) {
        console.log(respone);
        product = respone.data[0];
        xiangqing(respone.data[0]);
        conf();
    };
    xd314.AJAX(xd314.DATA);
}

function jian(){
    var a=xd314.Id.shuliang;
    if(a.value>=1){a.value=a.value-1;}
}

function jia() {
    var a=xd314.Id.shuliang;
    a.value=parseInt(a.value)+1;
}

function shdz() {
    reset();
    xd314.Id.wych.style.opacity = 0;
    xd314.DATA.data = {
    caidan: 'shdz',
    tid: tid,
    openid: xd314.Cookie('openid')
    };
    xd314.DATA.success = function (respone) {
        if(respone.data.shuliang<1){
            xd314.Id.shuliang.value = 1;
        }else{
            xd314.Id.shuliang.value = respone.data.shuliang;
        }
       
        xd314.Id.beizhu1.value = respone.data.dizhi;
        xd314.Id.beizhu2.value = respone.data.beizhu;
        xd314.Id1('phone1').value = respone.phone;
        //xd314.Id.M10.style.display = 'block';
        console.log(respone.data);
        xd314.HideShow();
    };
    xd314.AJAX(xd314.DATA);
}

function tucao1() {
    reset();
    xd314.Id.M12.style.display = 'block';
}
function tucao() {
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    xd314.DATA.data = {
    caidan: 'tucao',
    tucao:xd314.Id1('tucao').value,
    trackid:track.id,
    openid: xd314.Cookie('openid')
    };
    xd314.DATA.success = function (respone) {
        alert(respone.state);
        xd314.Id.M12.style.display = 'none';
        FanKuiTuiSong();
    };
    xd314.AJAX(xd314.DATA);
}

function yhxinxi(){
    if (xd314.Id.M11.style.display = 'none') {
       loading();
        xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
        xd314.DATA.data = {
        caidan: 'yhxinxi',
        openid: xd314.Cookie('openid'),
        access_t:xd314.Cookie('access_t')
        };
        xd314.DATA.success = function (respone) {
            xd314.Id.phone.value = respone.data.phone;
            xd314.Id1('addshouhuoxinxi').style.display='none';
             xd314.Id.M11.style.display = 'block';
            xd314.HideShow();
        };
        xd314.AJAX(xd314.DATA);
    } else {
        xd314.Id.M11.style.display = 'none';
    }
}

function fs() {
    if(fsong==0){
        fsong=1;
        xd314.Id1('M7a').style.display='block';
        xd314.Id1('goumai').innerHTML='提交';
    }else{
        fsong=0;
        if (xd314.Cookie('openid') != 'undefined') {
            loading();
            if(xd314.Id.shuliang.value<1){alert('产品数为零！');exit;}
            xd314.DATA.data = {
            caidan: 'fs',
            shuling: xd314.Id.shuliang.value,
            dizhi: xd314.Id.beizhu1.value,
            beizhu: xd314.Id.beizhu2.value,
            tid: tid,
            tuiguang:xd314.Cookie('tuiguang'),
            openid: xd314.Cookie('openid')
            };
            xd314.DATA.success = function (respone) {
                xd314.Show('<div style="background:#003E3E;">已确定</div>');
                xd314.HideShow();
                if (respone.usertrack.state1 < 1) { xd314.Href('https://axd-t.com/weixin/wx_index.php?state=xh2'); }
            };
            xd314.AJAX(xd314.DATA);
        } else {
            alert('未登录！');
        }
    }
}

function fsshxx(){
    if(fsshouhuo==0){
        fsshouhuo=1;
        xd314.Id1('M10').style.display='block';
    }else{
        fsshouhuo=1;
        if (xd314.Cookie('openid') != 'undefined') {
            if (xd314.Id.beizhu4.value != ''&&xd314.Id.beizhu3.value != ''&&xd314.Id.phone3.value != '') {
            loading();
             xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
            xd314.DATA.data = {
            caidan: 'fsshxx',
            name: xd314.Id.beizhu4.value,
            dizhi: xd314.Id.beizhu3.value,
            phone: xd314.Id.phone3.value,
            openid: xd314.Cookie('openid')
            };
            xd314.DATA.success = function (respone) {
                alert(respone.state);
               // xd314.Show('<div style="background:#003E3E;">'+respone.state+'</div>');
                xd314.HideShow();
                xd314.Id1('addshouhuoxinxi').style.display='none';
               xd314.Id.M10.style.display='none';
                xd314.Id.beizhu1.value='姓名：'+xd314.Id.beizhu4.value+'<br/>电话：'+xd314.Id.phone3.value+'<br/>地址：'+xd314.Id.beizhu3.value;
            };
            xd314.AJAX(xd314.DATA);
            } else {
                alert('请把收货信息填完整！');
            }
        } else {
            alert('未登录！');
        }
    }
}


function shouhuo(){
     xd314.Id1('addshouhuoxinxi').style.display='none';
        xd314.Id.M10.style.display='block';
}


function shezhiliucheng(trackid,sta) {//设置流程
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    xd314.DATA.data = {
    caidan: 'shezhiliucheng',
    trackid: trackid,
    state:sta
    };
    xd314.DATA.success = function (respone) {
        alert('已完成订单！');
        reset();
        FanKuiTuiSong();
    };
    xd314.AJAX(xd314.DATA);
}

function fsyonghu() {
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    if (xd314.Cookie('openid') != 'undefined') {
        if(xd314.Id.phone.value.length==0){
            alert('请填写手机号！');
        }else if(xd314.Id.yanzheng.value.length==0){
            alert('请填写验证码！');
        }else{
          loading();
            xd314.DATA.data = {
            caidan: 'fsyonghu',
            phone: xd314.Id.phone.value,
            yanzheng: xd314.Id.yanzheng.value,
            openid: xd314.Cookie('openid')
            };
            xd314.DATA.success = function (respone) {
                xd314.Show('<div   style="background:#003E3E;">'+respone.state+'</div>');
                if(respone.state=='已绑定'){
                    xd314.Id1('phone1').value=xd314.Id.phone.value;
                }
                xd314.Id.M11.style.display = 'none';
                    xd314.HideShow();
            };
            xd314.AJAX(xd314.DATA);
        }
    } else {
        alert('未登录！');
    }
}

function fsyanzheng() {
     loading();
    xd314.DATA.url = 'https://www.axd-t.com/dysms/msg.php';
    xd314.DATA.data = {
    caidan: 'fasong',
    phone: xd314.Id.phone.value
    };
    xd314.DATA.success = function (respone) {
        xd314.Show('<div  style="background:#003E3E;">'+respone.date.Message+'</div>');
        xd314.Id1('yzhm').style.color="white";xd314.Id1('yzhm').onclick='';var i=60;var timer=setInterval(function(){xd314.Id1('yzhm').innerHTML="重新发送("+i+")";i=i-1;
                                                                                                          if(i==0){
                                                                                                          clearInterval(timer);
                                                                                                          xd314.Id1('yzhm').innerHTML="发送手机验证码！";
                                                                                                          xd314.Id1('yzhm').style.color="#FF9797";
                                                                                                          xd314.Id1('yzhm').addEventListener('click',fsyanzheng,false);
                                                                                                          }
                                                                                                          },1000);
            xd314.HideShow();
    };
    xd314.AJAX(xd314.DATA);
}



function now(pg, func = 0) {
    xd314.Href('https://axd-t.com/weixin/wx_index.php?state=xh-' + pg + '--' + func);
}



function nlist() {
}

function scroll() {
    xd314.Id.body.scrollTop = scrolltop;
}

function article() {
    if (xd314.Id.M5.style.display == "block") {
        xd314.Id.M5.style.display = "none";
        xd314.Id.M8.style.display = "none";
        xd314.Id.M2.style.display = "block";
        xd314.Id.Mb.innerHTML = "相关信息";
        xd314.Id.Mb.style.opacity = 0.9;
    } else {
        reset();
        xd314.Id.Mb.style.opacity = 0;
        xd314.Id.Mb.innerHTML = "收起";
        xd314.Id.M5.style.display = "block";
        xd314.Id.M5.innerHTML = "";
        xr2();
    }
}

function article1(ti) {

}

function reset() {
    //  xd314.Id.lis.innerHTML = "目录";
    //  xd314.Id.yigou.style.opacity = 0.9;
    xd314.Id.lis.style.opacity = 0.9;
    xd314.Id.Mb.innerHTML = "相关信息";
    xd314.Id.Mb.style.opacity = 1;
    xd314.Id.M4.style.display = 'none';
    xd314.Id.M5.style.display = "none";
    // xd314.Id.wych.style.opacity = 0.9;
    xd314.Id.M9.style.display = "none";
    xd314.Id.M10.style.display = "none";
    xd314.Id.M8.style.display = "none";
    xd314.Id.body.onscroll ='';
    xd314.Id.M.style.display = "none";
    xd314.Id.M7a.style.display = 'none';
    xd314.Id.M12.style.display = 'none';
    xd314.Id1('goumai').innerHTML='购买';
    fsong=0;
    xd314.Id.M11.style.display = 'none';
    xd314.HideShow();
}


function pay(chpid, jiage, shuliang) {
    jiage = jiage * shuliang;
    xd314.Href('https://axd-t.com/weixin/wx_index.php?state=pay-' + jiage + '-' + xd314.Cookie('openid') + '-' + chpid, true);
}
function pay1(){
    xd314.Href('https://axd-t.com/weixin/wx_index.php?state=zpay-0-' + xd314.Cookie('openid') + '-0', true);
}

function yigou() {
     loading();
    xd314.Id.M9.style.display = "none";
    if (xd314.Id.M9.style.display == "block") {
        xd314.Id.M9.style.display = "none";
        xd314.Id.yigou.style.opacity = 0.9;
        xd314.Id.body.onscroll = '';
        //xd314.Id.M10.style.display = "block";
    } else {
        xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
        xd314.DATA.data = {
        caidan: 'yigou',
        openid: xd314.Cookie('openid')
        };
        xd314.DATA.success = function (respone) {
            reset();//alert(respone);
            fadeIn(xd314.Id.M9);
            xd314.Id.yigou.style.opacity = 0;
            data = respone.data;
            var htm = xd314.Id.M9;
            var state;
            var zshuliang=0;
            var zjiage=0;
            for (var i = 0; i < data.length; i++) {
                zshuliang=zshuliang+parseFloat(data[i].chpshuliang);
                zjiage=zjiage+(data[i].jiage*data[i].chpshuliang);
            }
            
            if(data[0].state1==0){
                xd314.Id.M9.innerHTML = '未支付订单：<div style="text-align:left;">总数量：'+zshuliang+'</br>总价格：'+zjiage+'</br><span style="color:#FF9797;" onclick="pay1()">支付</span></div><div>以下为订单详情：</div>';
            }else{
                xd314.Id.M9.innerHTML = '<div>以下为订单详情：</div>';
            }
            
            for (var i = 0; i < data.length; i++) {
                if(data[i].state1==0){//用户已下单
                    state='已提交订单！<br/>请点<span style="color:#FF9797;" onclick="pay(\'' + data[i].id + '\',\'' + data[i].jiage + '\',\'' + data[i].chpshuliang + '\')">此处</span>完成支付！之后才可以提供商品服务！';
                }else if(data[i].state1==1){//用户已支付
                    state='已支付，请等待商家制作！';
                }else if(data[i].state1==2){//商家确定完成
                    state='已支付<br/>已完成订单<br/>请查看是否收到货物！如果收到请点击<span style="color:#FF9797;" onclick="shezhiliucheng(\''+data[i].id+'\',3)">此处</span>确定收到！';
                }else if(data[i].state1==3){//用户确定收货
                    state='已支付<br/>已完成订单<br/>请点击<span style="color:#FF9797;" onclick="tucao1()">此处</span>给个评价或者建议吧！非常感谢!';
                }else if(data[i].state1==4){//用户已评价
                    state='已支付<br/>已完成订单<br/>已评价，感谢了！';
                }
                htm.innerHTML = htm.innerHTML + '<div id="' + data[i].id + '"  class="yigou"><img class="yigouimg"  src="' + data[i].tubiao + '"></img><br/><span class="yigoufont">' + data[i].title + '</span><br/>价格：' + data[i].jiage + '数量：' + data[i].chpshuliang + '<br/>地址：' + data[i].dizhi + '<br/>备注：' + data[i].beizhu + '<span style="margin:8px;color:#FF9797;float:right;"  onclick="now(\'' + data[i].chpid + '\',1)">修改订单</span><br/>时间：' + data[i].time + '<br/>'+state+'</div>';
            }
            if(data.length<1){htm.innerHTML = '还没有订单！';}
            scrolltop = xd314.Id.body.scrollTop;
            xd314.Id.body.onscroll = function () { xd314.Id.body.scrollTop = scrolltop; }
            //xd314.Id.M10.style.display = "block";
             xd314.HideShow();
        };
        xd314.AJAX(xd314.DATA);
        
    }
}


function xiangqing(data) {
    xd314.Id1('title').innerHTML = '<img style="width:100%;" src="https://axd-t.com/hl_img1/'+data.tubiao+ '"></img>'+data.title+'<span style="color:#FF9797;">(¥' + data.jiage + ')</span>';
    xd314.Id1('xiangqing').innerHTML = data.xiangqing;
    //var htm = xd314.Id1('xiangqing');
    //for (var i = 0; i < pimg.length; i++) {
      //  htm.innerHTML = htm.innerHTML + '<img id="img' + i + '" style="width:100%;margin-bottom:4px;" src="' + pimg[i] + '"  ></img>';
   // }
}

function xr1(data) {

}

function xr2(data) {
    var htm = xd314.Id.M5;
     htm.innerHTML = htm.innerHTML + '<div  style="margin:15px;font-size:18px;border-bottom:0px  solid  white;text-align:center;"  onclick="xd314.Href(\'https://axd-t.com/weixin/wx_index.php?state=xh\')">进入首页</div>';
    htm.innerHTML = htm.innerHTML + '<div  style="margin:15px;font-size:18px;border-bottom:0px  solid  white;text-align:center;"  onclick="xd314.Href(\'https://axd-t.com/weixin/wx_index.php?state=xh2\')">订单服务</div>';
    
}


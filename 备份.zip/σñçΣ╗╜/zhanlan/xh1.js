//鲜花展览系统js文件
//黄楼鲜花礼品 徐丹 2019.1.19
//alert(xd314.Cookie('openid'));

if (xd314.Cookie('openid') == 'undefined') { xd314.Href('https://axd-t.com/weixin/wx_index.php?state=xh-' + xd314.GetState()); }
xd314.ShowInit();
loading();
xd314.IdInit(["beizhu2","beizhu1","M12","yanzheng","M11","body", "wych", "yigou", "M9", "M", "M2", "M4", "lis", "Mb", "M5", "M8", "M7", "phone", "chanpin", "shuliang", "beizhu"]);
xd314.Id.body.onscroll = function () { reset(); };
xd314.Id.M4.style.height = xd314.Height * 60 / 100 + 'px';
xd314.Id.M8.style.height = document.body.clientHeight + 'px';
xd314.Id.M2.style.height = document.body.clientHeight + 'px';
xd314.Id.M9.style.height = xd314.Height * 45 / 100 + 'px';
var x = 0;
var tid;
var product = [];
var track = [];
var user = [];
var pimg = [];
var scrolltop;
function conf() {
    xd314.DATA = {
        method: 'POST',
        url: 'https://www.axd-t.com/weixin/xd314_weixin.php',
        data: {
            caidan: 'access',
            cururl: window.location.href
        },                                         
        success: function (respone) {
            xdwx.Config();
        }
    };
    xd314.AJAX(xd314.DATA);
}

wx.ready(function () {
    sharepongyouquan();
      FanKuiTuiSong();
});

function sharepongyouquan() {//product.title
    wx.onMenuShareTimeline({
        title: '黄楼鲜花礼品（传递美好心情）',
        link: 'https://axd-t.com/weixin/wx_index.php?state=xh-' + product.tid + '-' + xd314.Cookie('openid')+'-0',
        imgUrl: product.tubiao,
        success: function () { }
    });
    wx.onMenuShareAppMessage({
        title: '黄楼鲜花礼品',
        desc: '传递美好心情',
        link: 'https://axd-t.com/weixin/wx_index.php?state=xh-' + product.tid + '-' + xd314.Cookie('openid')+'-0',
        imgUrl: product.tubiao,
        success: function () { }

    });
}

function FanKuiTuiSong() {
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    xd314.DATA.data = {
        caidan: 'FanKuiTuiSong',
        openid: xd314.Cookie('openid')
    };
    xd314.DATA.success = function (respone) {
        track=respone.track;
        if (xd314.Cookie('func') == 1) {
            if(respone.data!=''&&respone.data!=undefined){
                xd314.Id.yigou.style.display = "block";
                xd314.Id.yigou.style.opacity = 0;
            }
        shdz();
        }else if (xd314.Cookie('func') == 2){
            if(respone.data!=''&&respone.data!=undefined){
                xd314.Id.yigou.style.display = "block";
                xd314.Id.yigou.style.opacity = 0;
            }
        yigou();
        }else{
            if(respone.data!=''&&respone.data!=undefined){
                xd314.Id1('Ma').innerHTML = respone.data+'<div style="width:100%;text-align:right;" onclick="reset()">关闭</div>';
            xd314.Id.M.style.display = "block";
           // xd314.Id.yigou.style.display = "block";
            //xd314.Id.yigou.style.opacity = 0;
            }
        }
        xd314.HideShow();
    };
    xd314.AJAX(xd314.DATA);
}

function loading(){
    xd314.Show('<div class="column" style=" display: flex;justify-content: center;"><div class="container animation-1"><div class="shape shape1"></div><div class="shape shape2"></div><div class="shape shape3"></div><div class="shape shape4"></div></div></div>','33%',false);
}

window.onload = function () {
    if (xd314.GetState() == undefined) {
        tid = 16;
    } else {
        tid = xd314.GetState();
    }
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    xd314.DATA.data = {
        caidan: 'listyuangong',
        tid: tid
    };
    xd314.DATA.success = function (respone) {
        product = respone.data[0];
        xiangqing(respone.data);
        conf();
    };
    xd314.AJAX(xd314.DATA);
}

function shdz() {}


function tucao1() {
    reset();
   xd314.Id.M12.style.display = 'block';
}
function tucao() {
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    xd314.DATA.data = {
    caidan: 'tucao',
    tucao:xd314.Id1('tucao').value,
    trackid:track.id,
    openid: xd314.Cookie('openid')
    };
    xd314.DATA.success = function (respone) {
        alert(respone.state);
        xd314.Id.M12.style.display = 'none';
        FanKuiTuiSong();
    };
    xd314.AJAX(xd314.DATA);
}

function yhxinxi(){}

function fs() {}

function shezhiliucheng(trackid,sta) {//设置流程
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
            xd314.DATA.data = {
                caidan: 'shezhiliucheng',
                trackid: trackid,
                state:sta
            };
            xd314.DATA.success = function (respone) {
                alert('已完成订单！');
                reset();
                 FanKuiTuiSong();
            };
            xd314.AJAX(xd314.DATA);
}

function fsyonghu() {}

function fsyanzheng() {}



function now(pg, func = 0) {
    xd314.Href('https://axd-t.com/weixin/wx_index.php?state=xh-' + pg + '--' + func);
}



function nlist() {
  
}

function scroll() {
    xd314.Id.body.scrollTop = scrolltop;
}

function article() {
    if (xd314.Id.M5.style.display == "block") {
        xd314.Id.M5.style.display = "none";
        xd314.Id.M8.style.display = "none";
        xd314.Id.M2.style.display = "block";
        xd314.Id.Mb.innerHTML = "相关信息";
        xd314.Id.Mb.style.opacity = 0.9;
    } else {
        reset();
        xd314.Id.Mb.style.opacity = 0;
        xd314.Id.Mb.innerHTML = "收起";
        xd314.Id.M5.style.display = "block";
        xd314.Id.M5.innerHTML = "";
        xr2();
    }
}

function article1(ti) {}

function reset() {
    xd314.Id.lis.innerHTML = "目录";
   // xd314.Id.yigou.style.opacity = 0.9;
    xd314.Id.lis.style.opacity = 0.9;
    xd314.Id.Mb.innerHTML = "相关信息";
    xd314.Id.Mb.style.opacity = 1;
    xd314.Id.M4.style.display = 'none';
    xd314.Id.M5.style.display = "none";
    xd314.Id.wych.style.opacity = 0.9;
    xd314.Id.M9.style.display = "none";
    xd314.Id.M8.style.display = "none";
    xd314.Id.body.onscroll = '';
    xd314.Id.M.style.display = "none";
    xd314.Id.M7.style.display = 'none';
    xd314.Id.M11.style.display = 'none';
    xd314.Id.M12.style.display = 'none';
}


function pay(chpid, jiage, shuliang) {}

function yigou() {}


function xiangqing(data) {
  var htm1 = xd314.Id1('xiangqing');
    for(var i = 0;i<data.length;i++){
        htm1.innerHTML=htm1.innerHTML+'<div class="chp" onclick="xd314.Href(\'https://axd-t.com/zhanlan/tuiguang.html?yuangong='+data[i].id+'\')"><div style="width:100%;text-align:right;color:white;padding:8px;font-size:14px;"><span style="color:white;margin-right:8px;font-size:14px;">' + data[i].name+'</span>' + data[i].phone+'</div></div>';
    }
    htm1.innerHTML=htm1.innerHTML+'<div style="height:40px;">ffff</div>';
    
}

function xr1(data) {
    
}

function xr2() {
    var htm = xd314.Id.M5;
    htm.innerHTML = htm.innerHTML + '<div  style="margin:15px;font-size:18px;border-bottom:0px  solid  white;text-align:center;"  onclick="xd314.Href(\'https://axd-t.com/hl_articl/articl2.html\')">联系商家</div>';
    htm.innerHTML = htm.innerHTML + '<div  style="margin:15px;font-size:18px;border-bottom:0px  solid  white;text-align:center;"  onclick="tucao1()">没事吐个槽吧</div>';
    htm.innerHTML = htm.innerHTML + '<div  style="margin:15px;font-size:18px;border-bottom:0px  solid  white;text-align:center;"  onclick="xd314.Href(\'https://axd-t.com/hl_articl/articl1.html\')">教您养花</div>';
    htm.innerHTML = htm.innerHTML + '<div  style="margin:15px;font-size:18px;border-bottom:0px  solid  white;text-align:center;"  onclick="xd314.Href(\'https://axd-t.com/hl_articl/articl.html\')">卡片寄语大全</div>';
     htm.innerHTML = htm.innerHTML + '<div  style="margin:15px;font-size:18px;border-bottom:0px  solid  white;text-align:center;"  onclick="xd314.Href(\'https://axd-t.com/weixin/wx_index.php?state=xh2\')">订单服务</div>';
 htm.innerHTML = htm.innerHTML + '<div  style="margin:15px;font-size:18px;border-bottom:0px  solid  white;text-align:center;"  onclick="reset()">关闭</div>';
}




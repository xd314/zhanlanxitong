//展览系统微信js文件
//黄楼鲜花礼品 徐丹 2019.1.19
var xdwx={Cookie:function(key){var k=document.cookie.split(key+'=')[1];if(k==undefined){return'undefined'}else{return k.split(';')[0]}},Config:function(){wx.config({debug:false,appId:this.Cookie('appId'),timestamp:this.Cookie('timestamp'),nonceStr:this.Cookie('nonceStr'),signature:this.Cookie('signature'),jsApiList:['chooseWXPay','chooseImage','onMenuShareAppMessage','onMenuShareTimeline']})},Img:function(imgfu){wx.chooseImage({count:1,sizeType:['original','compressed'],sourceType:['album','camera'],success:function(res){imgfu(res);}})},Pay:function(data){wx.chooseWXPay({timestamp:data.timeStamp,nonceStr:data.nonceStr,package:data.package,signType:data.signType,paySign:data.paySign,success:function(res){window.location.href=data.url}})}}



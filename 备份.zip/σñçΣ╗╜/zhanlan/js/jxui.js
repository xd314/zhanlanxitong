// JXUI-JS main 
!function(window) {
	"use strict"

	var doc = window.document;
	var jxui = {};

	var tools = jxui.tools = {

		/**
		*封装AJAX函数
		*@param {string}opt.method 选择http连接方式，POST与GET
		*@param {string}opt.url 请求地址URL
		*@param {boolean}opt.async 是否异步操作，ture为异步
		*@param {object}opt.data 发送的参数，格式为对象类型
		*@param {function}opt.success 成功后的回调函数
		**/ 
		AJAX: function(opt) {
			opt = opt || {};
			opt.method = opt.method.toUpperCase() || 'POST';
			opt.url = opt.url || '';
			opt.async = opt.async || true;
			opt.data = opt.data || null;
			opt.success = opt.success || function() {};
			var xmlHttp = null;
			if (XMLHttpRequest) {
				xmlHttp = new XMLHttpRequest();
			}else{
				xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
			}
			var params = [];
			for (var key in opt.data) {
				params.push(key + '=' + opt.data[key]);
			}
			var postData = params.join('&');
			if (opt.method.toUpperCase() === "POST") {
				xmlHttp.open(opt.method, opt.url, opt.async);
				xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
				xmlHttp.send(postData);
			}else if (opt.method.toUpperCase() === 'GET') {
				xmlHttp.open(opt.method, opt.url + '?' + postData, opt.async);
				xmlHttp.send(null);
			}
			xmlHttp.onreadystatechange = function() {
				if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
					console.log(xmlHttp.responseText);
					// console.log(typeof(xmlHttp.responseText));
					opt.success(xmlHttp.responseText);
				}
			}
		},

		/**
		*本地存储
		**/ 
		localStorage: function() {
			return storage(window.localStorage);
		}(),

		/**
		*session存储
		**/
		sessionStorage: function() {
			return storage(window.sessionStorage);
		}(), 

		/**
		*cookie操作
		**/ 
		cookie: function() {
			return {
            	/**
            	 * 获取 Cookie
            	 * @param  {String} name
            	 * @return {String}
            	 */
            	get: function (name) {
                	var m = doc.cookie.match('(?:^|;)\\s*' + name + '=([^;]*)');
                	return (m && m[1]) ? decodeURIComponent(m[1]) : '';
            	},
            	/**
            	 * 设置 Cookie
            	 * @param {String}  name 名称
            	 * @param {String}  val 值
            	 * @param {Number} expires 单位（秒）
            	 * @param {String}  domain 域
            	 * @param {String}  path 所在的目录
            	 * @param {Boolean} secure 跨协议传递
            	 */
            	set: function (name, val, expires, domain, path, secure) {
                	var text = String(encodeURIComponent(val)),
                    	date = expires;
                	// 从当前时间开始，多少秒后过期
                	if (typeof date === 'number') {
                	    date = new Date();
                	    date.setTime(date.getTime() + expires * 1000);
                	}
                	date instanceof Date && (text += '; expires=' + date.toUTCString());
                	!!domain && (text += '; domain=' + domain);
                	text += '; path=' + (path || '/');
                	secure && (text += '; secure');
                	doc.cookie = name + '=' + text;
            	}
        	}
		}(),

		/**
		*序列化
		**/ 
		serialize: function(value) {
			if (typeof value === 'string') return value;
            return JSON.stringify(value);
		},

		/**
		*反序列化
		**/ 
		deserialize: function(value) {
			if (typeof value !== 'string') return undefined;
            try {
                return JSON.parse(value);
            } catch (e) {
                return value || undefined;
            }

		},


		/**
		*获取地址栏参数
		**/ 
		getQueryString: function (name) {
        	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"),
            	r = window.location.search.substr(1).match(reg),
            	qs = '';
        	if (r != null)qs = decodeURIComponent(r[2]);
        	return qs;
    	},

		/**
		*格式化参数
		**/ 
		parseOptions: function (string) {
            if (typeof(string) === 'object') {
                return string;
            }
            var start = (string ? string.indexOf('{') : -1),
                options = {};
            if (start != -1) {
                try {
                    options = (new Function('', 'var json = ' + string.substr(start) + '; return JSON.parse(JSON.stringify(json));'))();
                } catch (e) {
                }
            }
            return options;
        },


		/**
		*向地址栏传送参数
		**/ 



		/**
		*倒计时
		**/ 


		/**
		*日期格式化
		**/ 


		/**
		*页面滑动管理
		**/ 



		/**
		*懒加载css/script
		**/ 
		lazyload: function() {
			return {
				lazyloadCss: function(cssUrl) {
					var head = document.getElementsByTagName('head')[0];
					var link = document.createElement('link');
					link.rel = "stylesheet";
					link.href = cssUrl;
					head.appendChild(link);
				},

				lazyloadScript: function(scriptUrl) {
					var head = document.getElementsByTagName('head')[0];
					var script = document.createElement('script');
					script.type = "text/javascript";
					script.src = scriptUrl;
					head.appendChild(script);
				}

			}
		}(),

		/**
		*读取图片文件，返回DateUrl
		**/ 




	};

	/**
	*H5 存储构建
	**/ 
	function storage(jxstr) {
		return {
			set: function(key, value) {
				jxstr.setItem(key, tools.serialize(value));
			},
			get: function(key) {
				return tools.deserialize(jxstr.getItem(key));
			},
			remove: function(key) {
				jxstr.removeItem(key);
			},
			clear: function() {
				jxstr.clear();
			}
		};
	}


	if (typeof define === 'function') {
        define(jxui);
    } else {
        window.JXUI = jxui;
    }
}(window);

!function(window) {
	"use strict"

	var sizeStore = 0;

	window.JXUI.tools.localStorage.size = function() {
		if (window.localStorage) {
			for (let item in window.localStorage) {
				if (window.localStorage.hasOwnProperty(item)) {
					sizeStore =+ window.localStorage.getItem(item).length;
				}
			}
		}
		console.log((sizeStore / 1024 / 1024).toFixed(2) + 'M');
	}

}(window);
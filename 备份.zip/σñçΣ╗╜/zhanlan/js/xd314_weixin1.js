
var xdwx={
Cookie:function(key){
var k=document.cookie.split(key+'=')[1];
if(k==undefined){
return 'undefined';
}else{
return k.split(';')[0];
}
},
Config:function(){
    alert('aaaaaaaa');
    alert(this.Cookie('signature'));
wx.config({
    debug: true, 
    appId:this.Cookie('appId'), 
    timestamp:this.Cookie('timestamp'),
    nonceStr:this.Cookie('nonceStr'), 
    signature:this.Cookie('signature'),
    jsApiList: ['chooseWXPay','chooseImage'] 
});

},
Img:function(){
wx.chooseImage({
count: 1,
sizeType: ['original', 'compressed'],
sourceType: ['album', 'camera'], 
success: function (res) {
return res.localIds;
}
});
},
Pay:function(data){
alert(data.appId);
    alert(data.timeStamp);
    alert(data.nonceStr);
    alert(data.package);
    alert(data.signType);
    alert(data.paySign);

wx.chooseWXPay({
appId:data.appId ,
timeStamp: data.timeStamp, 
nonceStr: data.nonceStr, 
package: data.package, 
signType: data.signType, 
paySign: data.paySign, 
success: function (res) {
}
});
}
}




<?php
/*
*调用微信接口的固定php文件。
*by xd314 2018.12.11
*/
require_once('class/wx_config.php');
header('Access-Control-Allow-Origin:*');
switch ($_POST['caidan']){
case 'access'://获取access_tocket
$post_data=array();
$result=json_decode(send_post('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$wxgzhappid.'&secret='.$wxgzhsecret,$post_data),true);
$result1=json_decode(send_post('https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token='.$result['access_token'].'&type=jsapi',$post_data),true);
$timestamp=time();
$nonceStr=str_rand();
$signature1='jsapi_ticket='.$result1['ticket'].'&noncestr='.$nonceStr.'&timestamp='.$timestamp.'&url='.$_POST['cururl'];
$signature=sha1($signature1);
$time=time();
//setcookie('jsapi_ticket',$signature1.'|'.$signature.'|'.$_POST['cururl'],time()+7200,'/');//测试定位用
setcookie('access_t',$result['access_token'],time()+7200,'/');
setcookie('appId',$wxgzhappid,time()+7200,'/');
setcookie('timestamp',$timestamp,time()+7200,'/');
setcookie('nonceStr',$nonceStr,time()+7200,'/');
setcookie('signature',$signature,time()+7200,'/');
echo json_encode(array('state'=>'success'));//data为数据$_COOKIE
break;
case 'pay'://支付(out_trade_no的填写规则uid..pid..用户uid和课程id)
if(!empty($_POST['number'])){
$nonce_str=str_rand();
$time=time();
if(empty($_POST['out_trade_no'])){$_POST['out_trade_no']='whn'.$time;}
$ip=get_ip();
$stringA='appid='.$wxgzhappid.'&body=woheni_pay&device_info=whn&mch_id='.$wxmch_id.'&nonce_str='.$nonce_str.'&notify_url='.$_POST['notify_url'].'&openid='.$_COOKIE['openid'].'&out_trade_no='.$_POST['out_trade_no'].'&spbill_create_ip='.$ip.'&total_fee='.$_POST['number'].'&trade_type=JSAPI&key='.$wxapikey;
$sign=strtoupper(md5($stringA));
$post_data='
    <xml>
       <appid><![CDATA['.$wxgzhappid.']]></appid>
       <body><![CDATA[woheni_pay]]></body>
       <device_info><![CDATA[whn]]></device_info>
       <mch_id><![CDATA['.$wxmch_id.']]></mch_id>
       <nonce_str><![CDATA['.$nonce_str.']]></nonce_str>
       <notify_url><![CDATA['.$_POST['notify_url'].']]></notify_url>
       <openid><![CDATA['.$_COOKIE['openid'].']]></openid>
       <out_trade_no><![CDATA['.$_POST['out_trade_no'].']]></out_trade_no>
       <spbill_create_ip><![CDATA['.$ip.']]></spbill_create_ip>
       <total_fee><![CDATA['.$_POST['number'].']]></total_fee>
       <trade_type><![CDATA[JSAPI]]></trade_type>
       <sign><![CDATA['.$sign.']]></sign>
    </xml>';
//print_r($_COOKIE);
$data=https_post('https://api.mch.weixin.qq.com/pay/unifiedorder',$post_data);
$data=xmlToArray($data);
$data1['appId']=$data['appid'];
$data1['timeStamp']=$time;
$data1['nonceStr']=$data['nonce_str'];
$data1['prepay_id']=$data['prepay_id'];
$data1['package']='prepay_id='.$data['prepay_id'];
$data1['signType']='MD5';
$str='appId='.$data1['appId'].'&nonceStr='.$data1['nonceStr'].'&package='.$data1['package'].'&signType='.$data1['signType'].'&timeStamp='.$data1['timeStamp'].'&key='.$wxapikey;
$data1['paySign']=strtoupper(md5($str));
    $data1['url']='https://axd-t.com/weixin/wx_index.php?state=xh';
echo json_encode(array('data'=>$data1,'state'=>'success'));//data为数据
}else{
    echo json_encode(array('state'=>'fail'));//data为数据
}
break;
default:
echo json_encode(array('state'=>'NoParameter'));//data为数据
break;
}

function https_post($url,$data,$ssl = false)
{
    $ch = curl_init ();
    curl_setopt ( $ch, CURLOPT_URL, $url );
    curl_setopt ( $ch, CURLOPT_CUSTOMREQUEST, "POST" );
    curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
    curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, FALSE );
    if($ssl) {
        curl_setopt ( $ch,CURLOPT_SSLCERT,$this->sslcert_path);
        curl_setopt ( $ch,CURLOPT_SSLKEY,$this->sslkey_path);
    }
    curl_setopt ( $ch, CURLOPT_FOLLOWLOCATION, 1 );
    curl_setopt ( $ch, CURLOPT_AUTOREFERER, 1 );
    curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data );
    curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        return 'Errno: '.curl_error($ch);
    }
    curl_close($ch);
    return $result;
}

function xmlToArray($xml)
    {
        libxml_disable_entity_loader(true);
        $xmlstring = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA);
        $val = json_decode(json_encode($xmlstring),true);
        return $val;
    }


function str_rand($length = 32, $char = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') {
    if(!is_int($length) || $length < 0) {
        return false;
     }

    $string = '';
     for($i = $length; $i > 0; $i--) {
         $string .= $char[mt_rand(0, strlen($char) - 1)];
     }
 
     return $string;
}

function get_ip()
{
    foreach (array(
                'HTTP_CLIENT_IP',
                'HTTP_X_FORWARDED_FOR',
                'HTTP_X_FORWARDED',
                'HTTP_X_CLUSTER_CLIENT_IP',
                'HTTP_FORWARDED_FOR',
                'HTTP_FORWARDED',
                'REMOTE_ADDR') as $key) {
        if (array_key_exists($key, $_SERVER)) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if ((bool) filter_var($ip, FILTER_VALIDATE_IP,
                                FILTER_FLAG_IPV4 |
                                FILTER_FLAG_NO_PRIV_RANGE |
                                FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
    }
    return null;
}


function send_post($url, $post_data) {
  $postdata = http_build_query($post_data);
  $options = array(
    'http' => array(
      'method' => 'POST',
      'header' => 'Content-type:application/x-www-form-urlencoded',
      'content' => $postdata,
      'timeout' => 15 * 60 // 超时时间（单位:s）
    )
  );
  $context = stream_context_create($options);
  $result = file_get_contents($url, false, $context);
  return $result;
}
?>

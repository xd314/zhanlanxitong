<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_COOKIE['hlxh']==1){
switch ($_GET["a"]){
case '1':
tjia($_GET["b"],$_GET["c"]);//------------------------------------------------------------------------产品上架
break;
case '1zl':
tjiazl($_GET["b"],$_GET["c"]);//------------------------------------------------------------------------种类上架
break;
case '2':
e($_GET[b]);//-------------------------------------------------------------------------修改产品页
break;
case '2_':
b($_G,$_POST,$_POST['tid'],$_POST['x1']);//-------------------------------------------------------------------------修改产品
echo '<script language="JavaScript">window.location.href="https://www.axd-t.com/plugin.php?id=xiaochxu:manage";</script>';	
break;
case '4':
//a($_G,$_POST[tid],$_POST[0],$_POST[1],$_POST[2],$_POST[3],$_POST[4],$_POST[5],$_POST[6],$_POST[7],$_POST[8],$_POST[9],$_POST[10],$_POST[11],$_POST[12],$_POST[14]);//-------------------------------------------------------------------------删除产品页
break;
case '5':
h($_GET[b]);
echo '<script language="JavaScript">window.location.href="https://www.axd-t.com/plugin.php?id=xiaochxu:manage";</script>';	
break;
case '6'://-------------------------------------------------------------------------增加产品
i();
echo '<script language="JavaScript">window.location.href="https://axd-t.com/plugin.php?id=xiaochxu:manage";</script>';	
break;
case '7'://-------------------------------------------------------------------------查找产品
j($_POST[content],$_GET[y1]);
//echo '<script language="JavaScript">window.location.href="https://axd-t.com/plugin.php?id=xiaochxu:manage";</script>';	
break;
case '8'://-------------------------------------------------------------------------查找词汇
j($_GET[content],$_GET[y1]);
break;
case '9'://-----------------------------------------------------------------------上传图标
//echo '<script language="JavaScript">alert("4");</script>';
shangchuant1($_FILES['upfile'],$_GET['b']);
//echo '<script language="JavaScript">alert("3");</script>';
e($_GET[b]);//-------------------------------------------------------------------------修改产品页
break;
case 'shangchuan'://-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------上传图片
$t=shangchuant($_FILES['upfile'],$_GET['b']);
//echo '<script language="JavaScript">window.location.href="https://axd-t.com/plugin.php?id=xiaochxu:manage&a=ttupian&b='.$_GET['b'].'";</script>';
lb_t1($_GET['b']);	
break;
case 'tt'://------------------------------------------------------------------------------------------------------------------------------图片详情
 xq_t($_GET[ft2],$_GET[ft1]);
break;
case 'ttupian'://--------------------------------------------------------------------------------------------------------------------------------------------图片设置页面    
  lb_t1($_GET['b']);
break;
case 'ttupian1'://--------------------------------------------------------------------------------------------------------------------------------------------图片设置页面1   
$b='<div  style="font-size:70px;position:fixed;top:40%;left:20%;">'.lang('plugin/xiaochxu', 'mp40').'</div>'; 
 include template('xiaochxu:xq');
break;
case 'tyidongt'://-------------------------------------------------------------------------------------------------------------------------------------------------移动图片
yidongt($_GET['b'],$_GET['c'],$_GET['f']);
lb_t1($_GET['c']);
break;
case 'delete'://----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------删除文件
deletet($_GET['b'],$_GET['c']);
lb_t1($_GET['c']);
break;
default:
c($_GET[y1]);//查看产品页
//caozuo();
//caozuo();
break;
}
}



//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------功能函数
function  caozuo(){//----------------------------------------操作   参数：
/*
$a= DB::query("CREATE TABLE  ".DB::table('xchx_studio')."  (
	`yid` int(11) NOT NULL,
	`x` text NULL,`x1` text NULL,`x2` text NULL,`x3` text NULL,`x4` text NULL,`x5` text NULL,`x6` text NULL,`x7` text NULL,`x8` text NULL,`x9` text NULL,`x10` text NULL,`x11` text NULL,`x12` text NULL,`x13` text NULL,`x14` text NULL,`x15` text NULL,`x16` text NULL,`x17` text NULL,`x18` text NULL,`x19` text NULL,`x20` text NULL,
`x21` text NULL,`x22` text NULL,`x23` text NULL,`x24` text NULL,
	PRIMARY KEY (`yid`)
) ENGINE=MyISAM
DEFAULT CHARACTER SET=utf8
CHECKSUM=0
DELAY_KEY_WRITE=0;");
echo '<script language="JavaScript">alert("成功！");</script>';
*/
}

function  creat(){//创建产品库

$a= DB::query("DELETE  FROM ".DB::table('chpk'));
$fso=opendir('xchx_img/'); 
$a=0;
while($flist=readdir($fso)){ 
if($flist!="."&&$flist!=".."){
echo $flist;
$ftype2=explode('、',explode('.jpg',$flist)[0])[1];   
$array= DB::fetch_all("SELECT * FROM ".DB::table('chpk')."   ORDER BY  tid  DESC")[0];
$a= DB::query("INSERT ".DB::table('chpk')." VALUES (".($array[tid]+1).",'产品','奇石','','".$ftype2."','价格面议','','','','https://www.axd-t.com/xchx_img/".$flist."','','','','','','','','1','','','','','','','','')");
$a+=1;
}
} 
closedir($fso);
echo  'succes';
}


function  b(array  $_G,array  $post,$tid,$x1){//-----------------------------------------修改产品   参数：
if(!empty($x1)){
$a= DB::query("UPDATE ".DB::table('chpk')." SET  tid=".$post['thtid'].",x1='".$x1."',x='".$post[0]."',x2='".$post['x2']."',title='".$post[3]."',jiage='".$post[4]."',tubiao='".$post[8]."',xiangqt='".$post[12]."',xiangqing='".$post[9]."',x16='".$post[11]."',x24='".$post[24]."'  WHERE  tid=".intval($tid));
}
}

	
function  c($y1){//----------------------------------------查看产品   参数：$y1      分页
$b='<span  style="font-size:40px">产品系统管理</span>&nbsp&nbsp<a href="https://www.axd-t.com/plugin.php?id=xiaochxu:manage&y1=0" ><span  style="font-size:20px">首页</span></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="https://www.axd-t.com/plugin.php?id=xiaochxu:manage&a=6" ><span  style="font-size:20px">上架产品</span></a><a  href="javascript:void(0);" onclick="a()"><span  style="float:right;color:black;margin-top:20px">搜索</span></a><input      id="sosu" type="text"  style="width:20%;height:30px;float:right;margin:15px"  value=""   placeholder="'.lang('plugin/xiaochxu', 'chpk7').'"/><hr/>';
$array= DB::fetch_all("SELECT * FROM ".DB::table('chpk')."    ORDER BY  tid  DESC");
$t=count($array);//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------总条数
$t1=30;//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------每页条数
$y=intval($t/30)+1;//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------总页数
$t2=$y1*30;//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------开始条号
$t3=($y1+1)*30;//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------结束条号
for ($x=$t2; $x<$t3; $x++) { if(!empty($array[$x])){
$b=$b.'
<a href="plugin.php?id=xiaochxu:manage&a=2&b='.$array[$x][tid].'"><div class="font1" style="">'.$array[$x][tid].'|'.$array[$x][title].'|'.$array[$x][jiage].'|'.$array[$x][x5].'<span  style="float:right">访问量：'.count(explode('|',$array[$x][x13])).'</span></div></a>
';}}
if($y1>0){$x1=$y1-1;}else{$x1=$y1;}
if($y1<($y-1)){$x2=$y1+1;}else{$x2=$y1;}
$b1='<div  class="font2"></div><table  style="width:100%"  border="0" cellspacing="0" cellpadding="0" ><tr  align="center"><td  style="width:20%"  align="right"><a  href="plugin.php?id=xiaochxu:manage&y1='.$x1.'"><<</a></td><td style="width:60%"><div  style="width:90%;overflow:scroll"><table  style=""><tr>';
for ($x=0; $x<$y; $x++) {
  if(!empty($array[$x])){ if($y1==$x){$b1=$b1.'<td align="center"  style="plugin.php?id=xiaochxu:manage&y1='.$x.'"><a href=""><div style="color:blue;width:30px">'.$x.'</div></a></td>';}else{$b1=$b1.'<td align="center"  style=""><a href="plugin.php?id=xiaochxu:manage&y1='.$x.'" ><div style="color:black;width:30px">'.$x.'</div></a></td>';}
} }
$b1=$b1.'</tr></table></div></td><td  style="width:20%"  align="left"><a  href="plugin.php?id=xiaochxu:manage&y1='.$x2.'"  style="color:black">>></a></td></tr></table><div  class="font2"></div>';



$dizhi_b='plugin.php?id=xiaochxu:manage&a=7';
include template('xiaochxu:manage');
}



function  e($tid){//-----------------------------------------修改产品页   参数：$tid产品id
$array= DB::fetch_all("SELECT * FROM ".DB::table('chpk')." WHERE  tid=".$tid)[0]; 
//echo '<script language="JavaScript">alert("'.$tid.'");</script>';
$b='<h1>产品系统管理</h1>
<fieldset>
<form  id="f" action="plugin.php?id=xiaochxu:manage&a=2_" method="post">
<legend align="left">增加产品</legend>
<p>产品号：
<input name="tid" type="text"   style="width:90%"   value="'.$tid.'"/>
</p>
<p>替换的产品号：
<input name="thtid" type="text"   style="width:90%"   value="'.$tid.'"/>
</p>
<p>产品一级分类：
<input name="0" type="text"   style="width:90%"  value="'.$array[x].'"/>
</p>
<p>产品二级分类：
<input name="x1" type="text"  style="width:90%"   value="'.$array[x1].'"/>
</p>
<p>产品代号：
<input name="2" type="text"  style="width:90%"    value="'.$array[x2].'"/>
</p>
<p>产品名称：
<input name="3" type="text"  style="width:90%"   value="'.$array[title].'"/>
</p>
<p>产品价格：
<input name="4" type="text"    style="width:90%"  value="'.$array[jiage].'"/>
</p>
<p>产品积分：
<input name="5" type="text"   style="width:90%"    value="'.$array[x5].'"/>
</p>
<p>产品规格：
<input name="6" type="text"   style="width:90%"   value="'.$array[x6].'"/>
</p>
<p>论坛地址：
<input name="7" type="text"   style="width:90%"    value="'.$array[x7].'"/>
</p>
<p>产品图标：
<input name="8" type="text"   style="width:90%"     value="'.$array[tubiao].'"/>
</p>
<p>产品详情图：
<textarea name="12" rows="1"   style="width:90%"    value="" >'.$array['xiangqt'].'</textarea>
</p>
<p>产品介绍：
<textarea name="9"    rows="1"    style="width:90%"    value="" >'.$array[xiangqing].'</textarea>
</p>
<p>产品功能：
<textarea name="10"  rows="1"  style="width:90%"    value="" >'.$array[x10].'</textarea>
</p>
<p>创建者uid：
<textarea name="11"  rows="1"  style="width:90%"    value="" >'.$array[x16].'</textarea>
</p>
<p>注意事项：
<textarea name="12" rows="1"   style="width:90%"    value="" >'.$array[x12].'</textarea>
</p>
    <p>上线：
    <textarea name="24" rows="1"   style="width:90%"    value="" >'.$array[x24].'</textarea>
    </p>
</fieldset>
</form>

<hr/>
<a href="javascript:void(0)" onClick="delet()"><div class="font1" style="">删除产品</div></a>
<a href="javascript:void(0)" onClick="f()"><div class="font1" style="">修改产品</div></a>
<script>
function  f(){document.getElementById("f").submit();}
function  delet(){
    if (confirm("你确定删除吗？")) {  
      window.open("plugin.php?id=xiaochxu:manage&a=5&b='.$tid.'");
        
   }
 }
</script>
';
$dizhi_b1='plugin.php?id=xiaochxu:manage&a=9&b='.$tid;
include template('xiaochxu:manage');
}

function  h($tid){//-----------------------------------------删除产品   参数：$tid产品id
$a= DB::query("DELETE  FROM ".DB::table('chpk')." WHERE  tid=".$tid);
$path='./chpk/ch/'.$tid;
delsvndir($path); //----------------------------------------------------------------------------------------------删除文件夹
include template('xiaochxu:manage');
}

function  tjia($tid,$ratetimes){//----------------------------------------增加产品（从帖子）   参数： $tid,fid
$value= DB::fetch_all("SELECT * FROM ".DB::table('forum_post')."  WHERE  ratetimes=".$ratetimes."    AND   tid=".$tid)[0];
if(!empty($value)){
$chpk= DB::fetch_all("SELECT * FROM ".DB::table('chpk')."  WHERE  tid=".$tid)[0];
if(!empty($chpk)){$a= DB::query("DELETE  FROM ".DB::table('chpk')." WHERE  tid=".$tid);}

$aa='';
$tubiao1=explode('^',explode('图标：',$value['message'])[1])[0];
if(!empty($tubiao1)&&$tubiao1!=''){
$ftype1=explode('[/attach]',$tubiao1);
if(count($ftype1)>1){
$ftype2=explode('[attach]',$ftype1[0])[1];   
$ftype2=str_replace('&nbsp;','',$ftype2);
if(!empty($ftype2)||$ftype2!=''){
$n41=DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.substr($value['tid'],-1))." WHERE  aid=".$ftype2)[0];   
$tubiao='https://axd-t.com/data/attachment/forum/'.$n41['attachment'];
}
}else{
$aa=explode('https',$tubiao1)[1];
if(!empty($aa)){
$tubiao='https'.explode('[',$aa)[0];
}else{
	$tubiao='https://axd-t.com/source/plugin/xiaochxu/img/timg.jpg';
}
}
}else{
$tubiao='https://axd-t.com/source/plugin/xiaochxu/img/timg.jpg';
}

$xiangqt1=explode('^',explode('详情图：',$value['message'])[1])[0];
$ftype1=explode('[/attach]',$xiangqt1);
if(count($ftype1)>1){
foreach($ftype1  as  $key1=>$value1){
$ftype2=explode('[attach]',$value1)[1];   

if(!empty($ftype2)){
$n41=DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.substr($value[tid],-1))." WHERE  aid=".$ftype2)[0];   
if(!empty($n41[attachment])){
$xiangqt[$key1]='https://axd-t.com/data/attachment/forum/'.$n41['attachment'];
}}}
$xiangqt2=implode("|", $xiangqt);
}

$a= DB::query("INSERT ".DB::table('chpk')." VALUES (".$tid.",'','','','".$value['subject']."','".explode('^',explode('价格：',$value['message'])[1])[0]."','','','','".$tubiao."','".explode('^',explode('详情：',$value['message'])[1])[0]."','','','','','','".time()."','".$value['authorid']."','".$value['ratetimes']."','','".$xiangqt2."','','','','','')");
}else{
echo '<script language="JavaScript">alert("添加失败！");</script>';
}
echo '<script language="JavaScript">window.location.href="https://www.axd-t.com/home.php?mod=space&uid='.$value['authorid'].'&do=thread&view=me&from=space";</script>';	
}

function  tjiazl($tid,$ratetimes){//----------------------------------------增加产品（从帖子）   参数： $tid,fid
$value= DB::fetch_all("SELECT * FROM ".DB::table('forum_post')."  WHERE  ratetimes=".$ratetimes."    AND   tid=".$tid)[0];
if(!empty($value)){
$chpk= DB::fetch_all("SELECT * FROM ".DB::table('chpk')."  WHERE  tid=".$tid)[0];
if(!empty($chpk)){$a= DB::query("DELETE  FROM ".DB::table('chpk')." WHERE  tid=".$tid);}

$aa='';
$tubiao1=explode('^',explode('图标：',$value['message'])[1])[0];
if(!empty($tubiao1)&&$tubiao1!=''){
$ftype1=explode('[/attach]',$tubiao1);
if(count($ftype1)>1){
$ftype2=explode('[attach]',$ftype1[0])[1];   
$ftype2=str_replace('&nbsp;','',$ftype2);
if(!empty($ftype2)||$ftype2!=''){
$n41=DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.substr($value['tid'],-1))." WHERE  aid=".$ftype2)[0];   
$tubiao='https://axd-t.com/data/attachment/forum/'.$n41['attachment'];
}
}else{
$aa=explode('https',$tubiao1)[1];
if(!empty($aa)){
$tubiao='https'.explode('[',$aa)[0];
}else{
	$tubiao='https://axd-t.com/source/plugin/xiaochxu/img/timg.jpg';
}
}
}else{
$tubiao='https://axd-t.com/source/plugin/xiaochxu/img/timg.jpg';
}

$xiangqt1=explode('^',explode('详情图：',$value['message'])[1])[0];
$ftype1=explode('[/attach]',$xiangqt1);
if(count($ftype1)>1){
foreach($ftype1  as  $key1=>$value1){
$ftype2=explode('[attach]',$value1)[1];   

if(!empty($ftype2)){
$n41=DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.substr($value[tid],-1))." WHERE  aid=".$ftype2)[0];   
if(!empty($n41[attachment])){
$xiangqt[$key1]='https://axd-t.com/data/attachment/forum/'.$n41['attachment'];
}}}
$xiangqt2=implode("|", $xiangqt);
}  

$a= DB::query("INSERT ".DB::table('chpk')." VALUES (".$tid.",'种类','','','".$value['subject']."','".explode('^',explode('价格：',$value['message'])[1])[0]."','','','','".$tubiao."','".explode('^',explode('详情：',$value['message'])[1])[0]."','','','','','','".time()."','".$value['authorid']."','".$value['ratetimes']."','','".$xiangqt2."','','','','','')");
}else{
echo '<script language="JavaScript">alert("添加失败！");</script>';
}
echo '<script language="JavaScript">window.location.href="https://www.axd-t.com/home.php?mod=space&uid='.$value['authorid'].'&do=thread&view=me&from=space";</script>';	
}

function  i(){//----------------------------------------增加   参数：    
$array= DB::fetch_all("SELECT * FROM ".DB::table('chpk')."   ORDER BY  tid  DESC")[0];
$a= DB::query("INSERT ".DB::table('chpk')." VALUES (".($array[tid]+1).",'','','','','','','','','','','','','','','','','','','','','','','','','')");
}
function  j($content,$y1){//----------------------------------------查找   参数：     $content搜索内容
//echo '<script language="JavaScript">alert("'.$content.'");</script>';
$array= DB::fetch_all("SELECT * FROM ".DB::table('chpk')." WHERE    title  LIKE  '%".$content."%'"); 
$b='
<span  style="font-size:40px">产品系统管理</span>&nbsp&nbsp<a href="plugin.php?id=xiaochxu:manage" ><span  style="font-size:20px">首页</span></a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="https://www.axd-t.com/forum.php?mod=post&action=newthread&fid=37" ><span  style="font-size:20px">增加产品</span></a><a  href="javascript:void(0);" onclick="a()"><span  style="float:right;color:black;margin-top:20px">搜索</span></a><input      id="sosu" type="text"  style="width:20%;height:30px;float:right;margin:15px"  value=""   placeholder="'.lang('plugin/xiaochxu', 'chpk7').'"/><hr/>
';
$t=count($array);//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------总条数
$t1=30;//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------每页条数
$y=intval($t/30)+1;//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------总页数
$t2=$y1*30;//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------开始条号
$t3=($y1+1)*30;//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------结束条号
for ($x=$t2; $x<$t3; $x++) { if(!empty($array[$x])){
if($array[$x][x14]!=1){$array[$x][x14]='(未上架)';}else{$array[$x][x14]='';}
$b=$b.'
<a href="plugin.php?id=xiaochxu:manage&a=2&b='.$array[$x][tid].'"><div class="font1" style="">'.$array[$x][tid].'|'.$array[$x][title].$array[$x][x14].'|'.$array[$x][jiage].'|'.$array[$x][x5].'<span  style="float:right">访问量：'.count(explode('|',$array[$x][x13])).'</span></div></a>
';}}
if($y1>0){$x1=$y1-1;}else{$x1=$y1;}
if($y1<($y-1)){$x2=$y1+1;}else{$x2=$y1;}
$b1='<div  class="font2"></div><table  style="width:100%"  border="0" cellspacing="0" cellpadding="0" ><tr  align="center"><td  style="width:20%"  align="right"><a  href="plugin.php?id=xiaochxu:manage&a=8&y1='.$x1.'&content='.$content.'"><<</a></td><td style="width:60%"><div  style="width:90%;overflow:scroll"><table  style=""><tr>';
for ($x=0; $x<$y; $x++) {
  if(!empty($array[$x])){ if($y1==$x){$b1=$b1.'<td align="center"  style="plugin.php?id=xiaochxu:manage&a=8&y1='.$x.'&content='.$content.'"><a href=""><div style="color:blue;width:30px">'.$x.'</div></a></td>';}else{$b1=$b1.'<td align="center"  style=""><a href="plugin.php?id=xiaochxu:manage&a=8&y1='.$x.'&content='.$content.'" ><div style="color:black;width:30px">'.$x.'</div></a></td>';}
} }
$b1=$b1.'</tr></table></div></td><td  style="width:20%"  align="left"><a  href="plugin.php?id=xiaochxu:manage&a=8&y1='.$x2.'&content='.$content.'"  style="color:black">>></a></td></tr></table><div  class="font2"></div>';
//echo '<script language="JavaScript">alert("2");</script>';
$dizhi_b='plugin.php?id=xiaochxu:manage&a=7';
include template('xiaochxu:manage');
}
function  shangchuant1(array $file,$tid){//----------------------------------------上传图标     参数：$file上传图片信息,$tid产品id
//echo '<script language="JavaScript">alert("2");</script>';
$array= DB::fetch_all("SELECT * FROM ".DB::table('chpk')." WHERE  tid=".$tid)[0]; 
$arrType=array('image/jpg','image/gif','image/png','image/bmp','image/jpeg');
$max_size='10000000000';      // 最大文件限制（单位：byte）
   if($_SERVER['REQUEST_METHOD']=='POST'){ //判断提交方式是否为POST
   
  if($file['size']>$max_size){  //判断文件大小是否大于500000字节
     echo "<font color='#FF0000'>".lang('plugin/xiaochxu', 'xiaochxu12')."</font>";
    exit;
   } 
  if(!in_array($file['type'],$arrType)){  //判断图片文件的格式
     echo "<font color='#FF0000'>".lang('plugin/xiaochxu', 'xiaochxu13')."</font>";
     exit;
   }
$c=strrev($file['name']);
$ftype=explode('.',$c); 
$ftype=strrev($ftype[0]);
  if($ftype=="PNG"){$ftype="png";}
 if($ftype=="JPG"){$ftype="jpg";}
$path='./chpk/ch/'.$tid.'/'.$array[tid].'.'.$ftype;
  $result = unlink($path);
   if(!move_uploaded_file($file['tmp_name'],$path)){  
    echo "<font color='#FF0000'>".lang('plugin/xiaochxu', 'xiaochxu15')."</font>";
    exit;
    }
$nn=$array[tid].'.'.$ftype;
$a= DB::query("UPDATE ".DB::table('chpk')." SET tubiao='".$nn."'   WHERE  tid=".$tid);
      
}else{}
 
return  $path;
}


function  shezhi_t($t,$tid){//----------------------------------------图片设置    参数：$t设置的图片,$array1 mp数据
$array= DB::fetch_all("SELECT * FROM ".DB::table('chpk')." WHERE  tid=".$tid)[0];
$t1=file_get_contents('./chpk/ch/'.$tid.'/t.txt');

file_put_contents ('./chpk/ch/'.$tid.'/t.txt',$t1.$t.'|');
}

function  xq_t($name,$mid){//----------------------------------------图片详情     参数：$name 图片名,$mid 名片id
$path=dzh($mid,'t1').'/'.$name;   
$b='<img  id="i" src="'.$path.'" width=100%  />';
$dizhi_f='';//返回键地址
include template('xiaochxu:xq');	
}

function  lb_t1($tid){//----------------------------------------图片列表1     参数：$array  wjk数据,$array1  mp数据 
$array= DB::fetch_all("SELECT * FROM ".DB::table('chpk')." WHERE  tid=".$tid)[0];
$n=file_get_contents('./chpk/ch/'.$tid.'/t.txt');
$ftype=explode('|',$n); 
foreach($ftype as $key =>$value){
//echo '<script language="JavaScript">alert("'.$value.'");</script>';
if(!empty($value)){
$arr[$key]='<div style="width:150px;height:200px;float:left;margin:0 0 10px   10px;background:url(\'./chpk/ch/'.$tid.'/im/'.$value.'\') no-repeat;background-size:100% 100%;"><a href="plugin.php?id=xiaochxu:manage&a=delete&b='.$value.'&c='.$tid.'"><input  type="button"  style="color:black;font-size:15px;background:#F0F0F0;margin:2px" value="'.lang('plugin/xiaochxu', 'hdp12').'"/></a><br/>
<a href="plugin.php?id=xiaochxu:manage&a=tyidongt&b='.$value.'&c='.$tid.'&f=0"><input  type="button"  style="color:black;font-size:15px;background:#F0F0F0;margin-top:148px;" value="'.lang('plugin/xiaochxu', 'hdp13').'"/></a><a href="plugin.php?id=xiaochxu:manage&a=tyidongt&b='.$value.'&c='.$tid.'&f=1"><input  type="button"  style="color:black;font-size:15px;background:#F0F0F0;margin-left:9px;margin-top:148px;float:right" value="'.lang('plugin/xiaochxu', 'hdp14').'"/></a></div>';
//echo '<script language="JavaScript">alert("./chpk/ch/'.$tid.'/im/'.$value.'");</script>';
}
}
$title1="t1";
$title=lang('plugin/xiaochxu', 'mp16');
$dizhi_f='plugin.php?id=xiaochxu:manage&a=tmp';//返回键地址
//$dizhi_delete='plugin.php?id=xiaochxu:manage&a=delete&me=0';//删除页面地址
$gl='<a href="plugin.php?id=xiaochxu:manage&a=tmp">
<span  style="float:right;color:white;height:26px;margin-right:5px;font-size:15px">'.lang('plugin/xiaochxu', 'hdp15').'</span></a>
<a href="javascript:void(0);" onclick="a()"> <span  style="float:right;color:white;height:26px;margin-right:30px;font-size:15px">'.lang('plugin/xiaochxu', 'hdp16').'</span></a> ';
$b='<div class="font1" style=""><a href="javascript:void(0);" onclick="a1()">上传产品图片</a>&nbsp&nbsp&nbsp<a href="plugin.php?id=xiaochxu:manage" ><span  style="font-size:20px">首页</span></a></div>';
$dizhi_b1='plugin.php?id=xiaochxu:manage&a=shangchuan&b='.$tid;//表单提交地址
include template('xiaochxu:manage');	
}
function  yidongt($name1,$tid,$f){//----------------------------------------移动图片    参数：$name1图片本地名,$tid数据,$f 方向（0为左，1为右）
$array= DB::fetch_all("SELECT * FROM ".DB::table('chpk')." WHERE  tid=".$tid)[0]; 
$n=file_get_contents('./chpk/ch/'.$tid.'/t.txt');
$ftype=explode('|',$n); 
$result1=array_search($name1,$ftype);
if("0"==$f){
$result2=$ftype[$result1-1].'|';
if($result2!='|'){
$result3=$name1.'|';
$ftype1=explode($result2.$result3,$n); 
$ftype1=$ftype1[0].$result3.$result2.$ftype1[1];
file_put_contents ('./chpk/ch/'.$tid.'/t.txt',$ftype1);
}
}else if("1"==$f){
$result2=$ftype[$result1+1].'|';
if($result2!='|'){
$result3=$name1.'|';
$ftype1=explode($result3.$result2,$n); 
$ftype1=$ftype1[0].$result2.$result3.$ftype1[1];
file_put_contents ('./chpk/ch/'.$tid.'/t.txt',$ftype1);
}
}
}

function  deletet($name,$tid){//----------------------------------------删除图片     参数：$name文件名,$array文件箱数据
$array= DB::fetch_all("SELECT * FROM ".DB::table('chpk')." WHERE  tid=".$tid)[0]; 
$n=file_get_contents('./chpk/ch/'.$tid.'/t.txt');
$ftype=explode($name.'|',$n); 
$ftype1=$ftype[0];
$ftype2=$ftype[1];
file_put_contents ('./chpk/ch/'.$tid.'/t.txt',$ftype1.$ftype2);
$result = unlink('./chpk/ch/'.$tid.'/im/'.$name); 
}

function  shangchuant(array $file,$tid){//----------------------------------------上传图片    参数：$file上传图片信息,$tid产品id
//echo '<script language="JavaScript">alert("2");</script>';
$array= DB::fetch_all("SELECT * FROM ".DB::table('chpk')." WHERE  tid=".$tid)[0]; 
$arrType=array('image/jpg','image/gif','image/png','image/bmp','image/jpeg');
$max_size='10000000000';      // 最大文件限制（单位：byte）
   if($_SERVER['REQUEST_METHOD']=='POST'){ //判断提交方式是否为POST
 if(!is_uploaded_file($file['tmp_name'])){ //判断上传文件是否存在
    echo "<font color='#FF0000'>".lang('plugin/xiaochxu', 'xiaochxu11')."</font>";
    exit;
    }
  if($file['size']>$max_size){  //判断文件大小是否大于500000字节
     echo "<font color='#FF0000'>".lang('plugin/xiaochxu', 'xiaochxu12')."</font>";
    exit;
   } 
  if(!in_array($file['type'],$arrType)){  //判断图片文件的格式
     echo "<font color='#FF0000'>".lang('plugin/xiaochxu', 'xiaochxu13')."</font>";
     exit;
   }
$c=strrev($file['name']);
$ftype=explode('.',$c); 
$ftype=strrev($ftype[0]);
  if($ftype=="PNG"){$ftype="png";}
 if($ftype=="JPG"){$ftype="jpg";}
$path='./chpk/ch/'.$tid.'/im/'.$file['name'];
 // $result = unlink($path);

 if(file_exists($path)){
    echo "<font color='#FF0000'>".lang('plugin/xiaochxu', 'xiaochxu14')."</font>";
    exit;
     }
$n=file_get_contents('./chpk/ch/'.$tid.'/t.txt');
file_put_contents ('./chpk/ch/'.$tid.'/t.txt',$n.$file['name'].'|');
   if(!move_uploaded_file($file['tmp_name'],$path)){  
    echo "<font color='#FF0000'>".lang('plugin/xiaochxu', 'xiaochxu15')."</font>";
    exit;
    }
}else{}

return  $file['name'];
}
function delsvndir($svndir){//----------------------------------------------------------------------------------------------删除文件夹
    //先删除目录下的文件：
    $dh=opendir($svndir);
    while($file=readdir($dh)){
        if($file!="."&&$file!=".."){
            $fullpath=$svndir."/".$file;
            if(is_dir($fullpath)){
                delsvndir($fullpath);
            }else{
                unlink($fullpath);
            }
        }
        
    }
    closedir($dh);
    //删除目录文件夹
    if(rmdir($svndir)){
        return  true;
    }else{
        return false;
    }
    
}
?>

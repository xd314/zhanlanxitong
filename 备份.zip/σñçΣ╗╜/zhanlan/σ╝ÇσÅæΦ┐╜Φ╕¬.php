//此文件追踪自己的思想，追踪开发的过程，记录儒子花仙类的形成过程。
//域名：axd-t.com  ip:47.96.137.4
//数据库密码：lXk5zhO35o5B
//创建数据表
//用户留言信息
//添加字段ALTER TABLE   pre_it618_credits_buygroup_sale   ADD   liwu1      varchar(100) DEFAULT NULL;
select * from  pre_serviceStation;
ALTER TABLE pre_product  MODIFY danwei text DEFAULT NULL;
insert   pre_personnelwork set title='节日庆典花束花篮';
$strsql="
//员工工作类型
DROP TABLE `pre_personnelwork`;
CREATE TABLE pre_personnelwork(
                         `id` int(11) NOT NULL AUTO_INCREMENT,
                         `title` text DEFAULT NULL,
                         `state` int(20) DEFAULT '0',
                         `tubiao` text DEFAULT NULL,
                         `xiangqing` text DEFAULT NULL,
                         `leibie1` text DEFAULT NULL,
                         `leibie2` text DEFAULT NULL,
                         `time` int(50) DEFAULT '0',
                         PRIMARY KEY (`id`)
                         ) ENGINE=MyISAM
DEFAULT CHARACTER SET=utf8
CHECKSUM=0
DELAY_KEY_WRITE=0;
//产品表
DROP TABLE `pre_product`;
CREATE TABLE pre_product(
                         `id` int(11) NOT NULL AUTO_INCREMENT,
                         `title` text DEFAULT NULL,
                         `jiage` int(20) DEFAULT '0',
                         `yuanjia` int(20) DEFAULT '0',
                         `state` int(20) DEFAULT '0',
                         `tubiao` text DEFAULT NULL,
                         `xiangqing` text DEFAULT NULL,
                         `yuangong` text DEFAULT NULL,
                         `leibie1` text DEFAULT NULL,
                         `leibie2` text DEFAULT NULL,
                         `time` int(50) DEFAULT '0',
                         PRIMARY KEY (`id`)
                         ) ENGINE=MyISAM
DEFAULT CHARACTER SET=utf8
CHECKSUM=0
DELAY_KEY_WRITE=0;
//服务站表
DROP TABLE `pre_serviceStation`;
CREATE TABLE pre_serviceStation(
                                `id` int(11) NOT NULL AUTO_INCREMENT,
                                `name` text DEFAULT NULL,
                                `weizhi` text DEFAULT NULL,
                                `time` int(20) DEFAULT '0',
                                `state` int(20) DEFAULT '0',
                                `x1` text DEFAULT NULL,
                                `x2` text DEFAULT NULL,
                                `x3` text DEFAULT NULL,
                                PRIMARY KEY (`id`)
                                ) ENGINE=MyISAM
DEFAULT CHARACTER SET=utf8
CHECKSUM=0
DELAY_KEY_WRITE=0;
//员工表
DROP TABLE `pre_personnel`;
CREATE TABLE pre_personnel(
                           `id` int(11) NOT NULL AUTO_INCREMENT,
                           `name` text DEFAULT NULL,
                           `phone` text DEFAULT NULL,
                           `serviceStation` text DEFAULT NULL,
                           `jobContent` varchar(100) DEFAULT NULL,
                           `time` int(20) DEFAULT '0',
                           `state` int(20) DEFAULT '0',
                           `x1` text DEFAULT NULL,
                           `x2` text DEFAULT NULL,
                           `x3` text DEFAULT NULL,
                           PRIMARY KEY (`id`)
                           ) ENGINE=MyISAM
DEFAULT CHARACTER SET=utf8
CHECKSUM=0
DELAY_KEY_WRITE=0;
//笔记表
DROP TABLE `pre_words`;
CREATE TABLE pre_words(
                       `id` int(11) NOT NULL AUTO_INCREMENT,
                       `words` text DEFAULT NULL,
                       `openid` varchar(100) DEFAULT NULL,
                       `time` int(20) DEFAULT '0',
                       `state` int(20) DEFAULT '0',
                       `x1` text DEFAULT NULL,对应的trackid
                       `x2` text DEFAULT NULL,
                       `x3` text DEFAULT NULL,
                       PRIMARY KEY (`id`)
                       ) ENGINE=MyISAM
DEFAULT CHARACTER SET=utf8
CHECKSUM=0
DELAY_KEY_WRITE=0;";
//用户（地址）信息
DROP TABLE `pre_userinfo`;
CREATE TABLE pre_userinfo(
                          `id` int(11) NOT NULL AUTO_INCREMENT,
                          `uid` int(11) NOT NULL,
                          `openid` text DEFAULT NULL,
                          `name` text DEFAULT NULL,
                          `phone` int(20) DEFAULT '0',
                          `sheng` text DEFAULT NULL,
                          `shi` text DEFAULT NULL,
                          `qu` text DEFAULT NULL,
                          `jiedao` text DEFAULT NULL,
                          `dizhi` text DEFAULT NULL,
                          `moren` int(20) DEFAULT '0',
                          `time` int(60) DEFAULT '0',
                          `x1` text DEFAULT NULL,
                          PRIMARY KEY (`id`)
                          ) ENGINE=MyISAM
DEFAULT CHARACTER SET=utf8
CHECKSUM=0
DELAY_KEY_WRITE=0;";
//用户追踪信息
DROP TABLE `pre_usertrack`;
CREATE TABLE pre_usertrack(
                           `id` int(11) NOT NULL AUTO_INCREMENT,
                           `chpid` text DEFAULT NULL,//产品id
                           `chpname` text DEFAULT NULL,//产品名称
                           `chpjiage` text DEFAULT NULL,//产品价格
                           `chpshuliang` text DEFAULT NULL,//产品数量
                           `beizhu` text DEFAULT NULL,//备注
                           `openid` varchar(100) DEFAULT NULL,//openid
                           `time` int(20) DEFAULT '0',//时间
                           `state` int(20) DEFAULT '0',//用户订单管理
                           `state1` int(20) DEFAULT '0',//交易流程管理
                           `tuiguang` text DEFAULT NULL,//分享者openid
                           `x1` text DEFAULT NULL,
                           `x2` text DEFAULT NULL,//是否选中  为一时未选中。
                           `x3` text DEFAULT NULL,//对应的支付单号
                           PRIMARY KEY (`id`)
                           ) ENGINE=MyISAM
DEFAULT CHARACTER SET=utf8
CHECKSUM=0
DELAY_KEY_WRITE=0;";
//用户信息
$strsql="DROP TABLE `pre_user`;
CREATE TABLE pre_user(
                      `id` int(11) NOT NULL AUTO_INCREMENT,
                      `name` text DEFAULT NULL,//用户名称
                      `phone` text DEFAULT NULL,//用户电话
                      `openid` varchar(100) DEFAULT NULL,//h用户openid
                      `time` int(20) DEFAULT '0',//s注册时间
                      `state` int(20) DEFAULT '0',//用户标记   反馈推送
                      'FeedbackPush text DEFAULT NULL,//反馈推送信息
                      `x1` text DEFAULT NULL,//
                      `x2` text DEFAULT NULL,//
                      `x3` text DEFAULT NULL,//
                      PRIMARY KEY (`id`)
                      ) ENGINE=MyISAM
DEFAULT CHARACTER SET=utf8
CHECKSUM=0
DELAY_KEY_WRITE=0;";
//产品物资信息

tid       | int(11) | NO   | PRI | NULL    |       |
| x         | text    | YES  |     | NULL    |    类别1  （产品，文章） |
| x1        | text    | YES  |     | NULL    |       类别2（鲜花）|
| x2        | text    | YES  |     | NULL    |     负责员工的id  |
| title     | text    | YES  |     | NULL    |      产品标题 |
| jiage     | text    | YES  |     | NULL    |       产品价格|
| x5        | text    | YES  |     | NULL    |       产品原价|
| x6        | text    | YES  |     | NULL    |       |
| x7        | text    | YES  |     | NULL    |       |
| tubiao    | text    | YES  |     | NULL    |       产品图标|
| xiangqing | text    | YES  |     | NULL    |       产品详情|
| x10       | text    | YES  |     | NULL    |       |
| x11       | text    | YES  |     | NULL    |       |
| x12       | text    | YES  |     | NULL    |       |
| x13       | text    | YES  |     | NULL    |       |
| x14       | text    | YES  |     | NULL    |       |
| x15       | text    | YES  |     | NULL    |       |
| x16       | text    | YES  |     | NULL    |       |
| x17       | text    | YES  |     | NULL    |       |
| x18       | text    | YES  |     | NULL    |       |
| xiangqt   | text    | YES  |     | NULL    |       |
| x20       | text    | YES  |     | NULL    |       |
| x21       | text    | YES  |     | NULL    |       |
| x22       | text    | YES  |     | NULL    |       |
| x23       | text    | YES  |     | NULL    |       |
| x24       | text    | YES  |     | NULL          是否上架。1为上架

$strsql="DROP TABLE `pre_chpk`;
CREATE TABLE pre_chpk(
                      `id` int(11) NOT NULL AUTO_INCREMENT,
                      `chpid` text DEFAULT NULL,
                      `chpshuliang` text DEFAULT NULL,
                      `beizhu` text DEFAULT NULL,
                      `openid` varchar(100) DEFAULT NULL,
                      `time` int(20) DEFAULT '0',
                      `state` int(20) DEFAULT '0',
                      `x1` text DEFAULT NULL,
                      `x2` text DEFAULT NULL,
                      `x3` text DEFAULT NULL,
                      PRIMARY KEY (`id`)
                      ) ENGINE=MyISAM
DEFAULT CHARACTER SET=utf8
CHECKSUM=0
DELAY_KEY_WRITE=0;
//js动画的效果比css好，功能更强大。
//vue的更新数据函数研究
//尽量显示的时候用渐变
//主要功能：相关信息，产品列表，购买需求
//开发步奏：基础功能，体验优化
//后端传输的数据如果需要传输两个表里的内容，要传输两个数组，而不是合并成一个数组（效率更差）
//开发与推广交替
//模块的方式开发，如同程序中封闭的函数。具有确定性的输入输出。具有很好的稳定性，可控性，可读性。
//开发以产品为中心，起点和终点。
//产品详情图放在1⃣️产品号为名的文件夹里
//各个页面的关系分互斥，共存的关系。
//页面由模块构成，y必须有ID，值为M开头。
//用代号标记有利于分清各元素的关系
//id优先于class
//购买流程：            订单状态状态
用户发送请求。     state 0    state1 0
用户已支付              state 0    state1 1
商家已制作送货完成  state 0    state1 2
用户已确定受到货物  state 0    state1 3
用户已评价              state 0    state1 4
商家已感谢              state 1   state1 4

//产品要千锤百炼
//用户与商家在产品订单这一点上进行交互。
//反馈推送 FeedbackPush=0  欢迎光临黄楼鲜花礼品店
//系统永远都要有复位功能
//一般情况下界面功能不能同时运行多个。
//系统永远都要有反馈功能。
//网站系统要点：操作权限判断，页面复位（最原始的状态，保证稳定与安全），页面反馈（对人进行交互和控制，即是页面显示）。各功能模块要相互孤立，才能发挥各自功能
//系统本质目的：一切为数据的收集和页面的完美显示
//微信config配置签名失败的原因是当前地址最多只能有一个参数。
//跨页面的数据交互主要是用cookie的方法。
//xh.js页的逻辑（过程结构）：
1.判断openid是否存在
2.加载页面显示信息
3.配置微信功能
4.判断开启服务模块
5.进行反馈推送
8.添加节日z祝福的f功能
//让展示系统与用户进行更多的交流。
//增加用户吐槽的功能
//展示系统吸引捕捉用户信息
//展示系统控制花店活动
//印象就是品牌
//对用户多给予少索取
//以短信的d方式通信，虽然收费高点，但是这样收益最高。
//用户的核心识别信息为手机号。因为方便验证，而且便于记忆，而且唯一识别。
//系统完善之后去掉discuz
//程序一般有三级：基础功能，类，应用
//这个系统是人工智能系统。因为他是可以和人交流的系统。这个系统有名有性，他叫小徐，是男的。
//在这个系统中以第一视角表达
//店铺宗旨：祝福，帮助
//添加建议与心愿系统
//添加祝福系统
//添加输入过滤
//程序必须写注释，以防止迷失定位
//添加语音表达
//提交订单后提醒完善联系方式
//尽量都用手机端显示。这样无形中会提高工作效率。
//应用系统构成：数据库，用户交互端，商家交互端。
//php主要用来处理数据。显示尽量纯用html
//系统是测试出来的
//高手与初学者的差别在与。解决问题的速度更快。收到技术方面问题的干扰更少。
//力出一孔，利出一孔。这一孔就是人工智能（可与人交流的智能，人造的智能）。
//不看说明，不去测试就不会知道怎么做。本来程序语言又不是自己创立的。
//发送的信息对客户要有针对性。
//信息控制主要包括：展览系统、短信、微信
//我的主要目标：想法与不同的人进行不同的交流。以此帮助更多的人，销售更多的产品。
//axd-t含义：aid extreme develop tool 辅助极限开发工具
//短信通知商家在用户已支付的时候z通知一次。用户在商家已完成的时候通知一次。
//阿里云账号要升级为企业账号。为了短信通知无限。
//此系统主要包含两部分，一部分是业务功能部分，另一部分是推广部分。
//如何推广：真正正确的做法不是去花精力寻求新客户。而是集中力量发掘老用户的传播力量。这也是唯一的方法，因为老用户都发掘不了，新用户就更难认同了。这也可见老用户对一家公司的重要性。可以说是最重要的。
//不要在开发好的程序上实验。不仅仅x影响现有用户的使用，也g使自己增加好多的额外的工作量，易导致疲劳。
//长的帅和美的人本身就具有优越性。因为人们对他们的期望更大。他们也会更有动力。因为他们开始会让很多人失望，但是他们渐渐的就不会了。
//只要改一下支付和登陆功能就可以脱离微信的x影响。
//我是专做软件的（力出一孔）。需要找花店和微商合作和渠道商合作。
// 程序的目的使功能。而不是框架。框架有时主要是为开发服务的。根据开发条件的不同需要不同的开发模式。所以不能局限于用哪个框架。要把主要时间放在功能的实现上。
//制作独家教程,发展连锁店,用以支持网上展示系统的发展。
//工作的时候很难全心地做我的软件。而我喜欢全心做事。在有了一定的基础后再开始创业。
//主要实现业务功能。页面的渲染功能不宜太多。避免干扰用户的关注点。
//多接触社群，这是网上高质量推广的要点。
//程序也是生物。凡是有用的功能，不管其实现方法是否先进都要保留。
//推广标题要满足这几个要素：强调需求（一般的需求：用途，性价比），当前可以干什么，
//主要的工作是找问题
//男人和女人做爱，总感觉女的吃亏。卖家和买家交易，总感觉买家吃亏。
//二维码优化
//<div style="height:40px;"></div><div style="width:100%;display:flex;justify-content:space-around;align-items:center;"><img src="../artic_img/gzh.jpg"  style="width:30%;"></img> <div style="color:#4F4F4F;font-size:15px;">长按扫描二维码<br/>关注更多信息</div><div style="width:1px;"></div></div>二维码图不用
//自创一派，发展自己的推广方法。
//儒子花仙是一家公司。有自己独立的软件系统，推广系统，组织系统。它的目标是帮助人们解决礼节的问题。它的主体是软件。主题是让你更快乐！
//儒子花仙是一个类（这是理想），黄楼鲜花是一个实例。
//公司由五个要素构成：生产（展览销售系统，花束，花艺教程），产品即是由于直接盈利的东西（花束，花艺教程），推广（推广的目的是定位到需要自己产品的用户。推广的方法是大范围的覆盖广告，逐渐聚合需要的用户，逐渐的提纯。具体：一个微信号，一个公众号，一个群，，，），销售（有实体店），售后（曾经推广的用户，推送情况，推送福利）。
//公司的组织架构已五要素为基础。最基本的是找五个负责人。这五个人的薪酬不算成本，而是在总收益中划分出。此外用人的薪酬都是有上限的，算在成本中。
//第一批用户很重要。不仅是用户，还是实现理想的同志。
//完善儒子花仙（花店）类。
//开始时以生产为中心。现在生产已经有了一定的成果就要以推广为中心。五要素的实现时有顺序的。实现之后又是相互配合的。
//人的心情决定行为。所以要让人们有购买的心情。
//管理页面只有我能用在使用之前需要在cookie中写入我的代号openid=xd314，其他人如果需要用有单独的页面。
//网站主要有两个密码最重要，一个是数据库密码，一个是网站管理员密码。如果这两个密码别人不知道，就不要担心数据库和网站会被别人攻击。网页是最透明的，关键的信息不可以经网页端处理判断。
//推广群里和公众号里每次发的东西都要足够的给人惊喜。朋友圈里就随意的多。
//邢和猫一样，太懒太滑了，好奇心重，又好逞能，又居功自傲。不能重用。可以放在调节公司生活气氛上。
//优化wx_index机制
//做具有专业知识性的和服务型的个人网站。
//为了保护黄楼鲜花店，有必要修改我网站花店类的‘黄楼鲜花礼品’实例的名称。
//js工具添加处理元素的功能。
//能用html文件处理的就不用其他的方式。
//能用文件夹系统管理的就不要用数据库。
//花店人员的品质（也是所有人需要的品质）：诚实（提高效率），勤奋（迭代发展），专注（拥有极致，有价值），服务（拥有客户和支持，核心目的），工具（扩展能力）
//分模块开发
//添加取消订单功能和总付款功能
//添加总计功能 相当于购物车.优化购物车功能。
//添加删除订单功能。
//整体优化
//除了展示页再增加主页推广页和订单页。页面的功能不同但是页面的构成相同。除了推广页和帖子页，其他的都是属于同一物种,都属于展览馆系统。
//能用js实现的就用js实现。这是最高效，最灵活，开发最方便的方式。
//写几个函数可以生成整合了元素，样式，事件功能的软件功能体。
//有了这几个函数就需要用更基础的js语言开发了。
//修改s网站和数据库密码为：123qweasd,./
//类别页加个首页小图标
//成为用户后方可以成为员工。员工与用户共用一个数据表。员工有特殊标志和所处服务部信息。
//建立服务部信息表，记录各服务部的基本信息。
//服务站与员工管理页面manage.html
//列表的记录修改不再单设置一个输入框。而是直接在列表上修改。可以通过修改其样式来实现打开输入框的效果。这样就极大的提高开发的效率，和使用的可靠性
//相比较其他的元素，<input>是特殊的。
//用js直接生成元素比html标签效率要高。因为html还有解析的过程。
//不同平台显示使用不同的系统
//建立以z网站为核心的计划经济体制。为基层民众服务。提供基础性的必要的用品与食物。价格相对最低。十元起送。送到家门口。
//首页显示所在地的各种服务信息。
//员工页显示相应的产品信息。
//员工的服务内容
//从基层建立计划经济机制，建立社会人力调配机制
//员工工作内容分类：
节日庆典花束花篮
日用品套装
应季蔬菜水果
水果拼盘
健康品
物业
公安
营业厅
水电气费
insert   pre_personnelwork set title='日用品套装';
insert   pre_personnelwork set title='应季蔬菜水果';
insert   pre_personnelwork set title='水果拼盘';
insert   pre_personnelwork set title='健康养生品';
insert   pre_personnelwork set title='物业信息';
insert   pre_personnelwork set title='电梯信息';
insert   pre_personnelwork set title='公安信息';
insert   pre_personnelwork set title='营业厅';
insert   pre_personnelwork set title='水电天然气费';
//10t元之下不可以支付。
//产品不要批量，一个一个定价
//最基本的功能是显示和上传图片的功能
//有些时候只能用相对地址

<?php
header('Access-Control-Allow-Origin:*');
require_once('class/mysql_xd314.php');
require_once('class/basic_xd314.php');
require_once('class/user_xd314.php');
$mysql_xd314=new  mysql_xd314;
$basic_xd314=new  basic_xd314;
$user_xd314=new  user_xd314;
switch ($_POST["caidan"]){
case 'main'://废弃
if(empty($_POST['page'])){$_POST['page']=0;}
$array=$mysql_xd314->search('pre_chpk',"   WHERE x='产品' AND  x1='鲜花'  AND x24='1'  ");
$fy=$basic_xd314->body_fy($array,$_POST['page'],1);//---------------------------------------列表(输出区间限制数组array($t2,$t3,$t,$t1,$y,$y1))   参数：array $array  列表数据,$y1  页码(固定为$_GET[ft0]),$t1每页条数
$array=$mysql_xd314->search('pre_chpk',"   WHERE x='产品'  AND  x1='鲜花'  AND x24='1'   LIMIT   ".$fy[0].",".$fy[3]);
//$array[0]=$basic_xd314->mult_iconv($array[0],"gb2312","utf-8");
       
        $fso=opendir('../hl_product/hl'.$array[0]['tid'].'/');
        $a=0;
        while($flist=readdir($fso)){
            if($flist!="."&&$flist!=".."){
                $pimg[]='https://www.axd-t.com/hl_product/hl'.$array[0]['tid'].'/'.$flist;
                $a+=1;
            }
        }
        closedir($fso);
echo json_encode(array('data'=>$array,'data1'=>$pimg,'page'=>$fy[4]));//data为数据
break;
    case 'listyuangong':
       // if(empty($_POST['pageid'])){$_POST['pageid']=0;}
        $array=$mysql_xd314->search('pre_personnel'," WHERE serviceStation='".$_POST['tid']."'");
       // $paging=$mysql_xd314->paging($array,$_POST['pageid'],10);
       // $array=$mysql_xd314->search('pre_personnel'," WHERE serviceStation='".$_POST['fid']."' ORDER BY time DESC  LIMIT ".$paging[0].",10");
        echo json_encode(array('data'=>$array));//data用户
        break;
case 'FanKuiTuiSong'://反馈推送信息。在页面和短信上分别通知
$usertrack=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND   openid='".$_POST['openid']."'",' id,chpjiage,chpshuliang,chpname ');
$usertrack1=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND state1=1 AND  openid='".$_POST['openid']."'",' id,chpname ');
$usertrack2=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND  state1=2 AND openid='".$_POST['openid']."'",' id,chpname ');
$usertrack3=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND  state1=3 AND openid='".$_POST['openid']."'",' id,chpname ');
$usertrack4=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND state1=4 AND openid='".$_POST['openid']."'",' id,chpname ');
$usertrack5=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND  state1=5 AND openid='".$_POST['openid']."'",' id,chpname ');

if(count($usertrack4)>0){//用户已评价
    $track=$usertrack4;
$FeedbackPush='感谢您的光临，我将再接再厉，精益求精，努力为您提供更好的服务！您可以在【相关信息】【自我介绍】中关注本店公众号获取更多本店信息！';
$a=$mysql_xd314->modify('pre_usertrack'," SET state=1 WHERE id=".$usertrack4[0]['id']);
}else if(count($usertrack3)>0){//用户已收到货物
    $track=$usertrack3;
$FeedbackPush='请点击<span style="color:#FF9797;" onclick="tucao1()">此处</span>给个评价或者建议吧！非常感谢！';
}else if(count($usertrack2)>0){//商家已完成订单
    $track=$usertrack2;
$FeedbackPush='产品【'.$usertrack2[0]['chpname'].'】已完成订单，请查看是否收到货物！如果收到请点击<span style="color:#FF9797;" onclick="shezhiliucheng(\''.$usertrack2[0]['id'].'\',3)">此处</span>确定收到！';
}else if(count($usertrack1)>0){//用户已支付
    $track=$usertrack1;
$FeedbackPush='产品【'.$usertrack1[0]['chpname'].'】已支付，请等待商家制作';
}else if(count($usertrack)>0){//订单建立
    $track=$usertrack;
    $FeedbackPush='产品【'.$usertrack[0]['chpname'].'】已提交订单！请点<span style="color:#FF9797;" onclick="xd314.Href(\'https://axd-t.com/weixin/wx_index.php?state=xh2\')">此处</span>完成支付！之后才可以提供商品服务！';
}else{
    $FeedbackPush='';
       $track[0]=[];
}     
        
        
echo json_encode(array('data'=>$FeedbackPush,'track'=>$track[0]));
break;
    case 'dizhishanchu'://删除地址
        if(!empty($_POST['id'])){
            $array=$mysql_xd314->delete('pre_userinfo'," WHERE id=".$_POST['id']);
            echo json_encode(array('state'=>'已删除'));
        }else{
            echo json_encode(array('state'=>'删除失败'));
        }
         //echo json_encode(array('state'=>$_POST['id']));
        break;
case 'deletrack'://删除追踪
        if(!empty($_POST['zid'])){
            $array=$mysql_xd314->delete('pre_usertrack'," WHERE id=".$_POST['zid']);
            echo json_encode(array('state'=>'已取消'));
        }else{
            echo json_encode(array('state'=>'失败'));
        }
        
break;
case 'shouhuoxinxi':
        if(!empty($_POST['openid'])){
        $array=$mysql_xd314->search('pre_userinfo',"  WHERE openid='".$_POST['openid']."'");
}
        if(count($array)>0){
        echo json_encode(array('data'=>$array));//data为数据,页码
        }else{
            echo json_encode(array('data'=>''));//data为数据,页码
        }
break;
case 'whetherxz'://是否选择
        if(!empty($_POST['zid'])){
            $track=$mysql_xd314->search('pre_usertrack',"WHERE id=".$_POST['zid']);
            if($track[0]['x2']==1){
                $array=$mysql_xd314->modify('pre_usertrack'," SET x2=0 WHERE id=".$_POST['zid']);
                echo json_encode(array('state'=>'已选择'));
            }else{
            $array=$mysql_xd314->modify('pre_usertrack'," SET x2=1 WHERE id=".$_POST['zid']);
                 echo json_encode(array('state'=>'已取消选择'));
            }
           
        }else{
            echo json_encode(array('state'=>'设置失败'));
        }
        
break;
case 'tucao':
if(!empty($_POST['tucao'])&&!empty($_POST['openid'])){
$a=$mysql_xd314->increase('pre_words'," SET words='".$_POST['tucao']."',openid='".$_POST['openid']."',time='".time()."',x1='".$_POST['trackid']."'");
$a=$mysql_xd314->modify('pre_usertrack'," SET state1=4 WHERE id=".$_POST['trackid']);
echo json_encode(array('state'=>'已发送'));
}else{
echo json_encode(array('state'=>'Missing'));
}
break;
case 'shezhiliucheng':
if(!empty($_POST['state'])&&!empty($_POST['trackid'])){
$a=$mysql_xd314->modify('pre_usertrack'," SET state1=".$_POST['state']." WHERE id=".$_POST['trackid']);
            echo json_encode(array('state'=>true));
    }else{
        echo json_encode(array('state'=>'Missing')); 
    }
break;
case 'main1':
$array=$mysql_xd314->search('pre_product',"    WHERE id=".$_POST['id']);
        /*
        $fso=opendir('../hl_product/hl'.$_POST['id'].'/');
        $a=0;
        while($flist=readdir($fso)){
            if($flist!="."&&$flist!=".."){
                $pimg[]='https://www.axd-t.com/hl_product/hl'.$_POST['id'].'/'.$flist;
                $a+=1;
            }
        }
        closedir($fso);
         */
echo json_encode(array('data'=>$array));//data为数据,页码
break;
case 'listchanpin':
$array=$mysql_xd314->search('pre_product',"    WHERE leibie1='产品'  AND  leibie2='鲜花'  AND state=1");
echo json_encode(array('data'=>$array));//data为数据,页码 
break;
case 'yigou':
$array=$mysql_xd314->search('pre_usertrack',"  WHERE NOT state=1  AND  openid='".$_POST['openid']."'");
if(count($array)>0){
foreach($array as $key=>$value){
if(empty($value['chpname'])){$value['chpname']='';}
if(empty($value['chpjiage'])){$value['chpjiage']='';}
if(empty($value['chptubiao'])){$value['chptubiao']='';}
//$chpk=$mysql_xd314->search('pre_chpk',"  WHERE  tid=".$value['chpid'],' tubiao ')[0];
$value['title']=$value['chpname'];
$value['jiage']=$value['chpjiage'];
$value['tubiao']=$value['chptubiao'];
$value['time']=date('Y-m-d h:i',$value['time']);
$array[$key]=$value;
}
echo json_encode(array('data'=>$array));//data为数据,页码
}else{
    echo json_encode(array('data'=>'no'));//data为数据,页码
}

break;
case 'article':
$array=$mysql_xd314->search('pre_chpk',"   WHERE x='文章' AND x1='鲜花' ",' tid,title,tubiao ');
echo json_encode(array('data'=>$array));//data为数据,页码 
break;
case 'shdz':
$user=$mysql_xd314->search('pre_user'," WHERE openid='".$_POST['openid']."'")[0];
$array1=$mysql_xd314->search('pre_usertrack'," WHERE openid='".$_POST['openid']."' AND chpid='".$_POST['tid']."' AND NOT state=1 AND  state1=0");
if(count($array1)>0){
    $array['shuliang']=$array1[0]['chpshuliang'];
    $array['dizhi']=$array1[0]['dizhi'];
    $array['beizhu']=$array1[0]['beizhu'];
}else{
$array['shuliang']='';
    $array['dizhi']='';
    $array['beizhu']='';
}

echo json_encode(array('data'=>$array,'phone'=>$user['phone']));//data为数据,页码
break;
case 'yhxinxi':
$aa=$mysql_xd314->search('pre_user'," WHERE openid='".$_POST['openid']."'")[0];
$array=array();
$array['phone']=$aa['phone'];
echo json_encode(array('data'=>$array));
break;
case 'fsshxx':
$user=$mysql_xd314->search('pre_user'," WHERE openid='".$_POST['openid']."'")[0];
$a=$mysql_xd314->increase('pre_userinfo'," SET uid=".$user['id'].",name='".$_POST['name']."',phone='".$_POST['phone']."',dizhi='".$_POST['dizhi']."',openid='".$_POST['openid']."',time=".time());
        echo json_encode(array('state'=>$_POST['phone']));
break;
case 'fs':
$usertrack=$mysql_xd314->search('pre_usertrack'," WHERE openid='".$_POST['openid']."' AND chpid='".$_POST['tid']."' AND  NOT state=1 AND state1=0",' id ');
$chpk=$mysql_xd314->search('pre_product',"    WHERE id=".$_POST['tid'],' title,jiage,tubiao ')[0];
if(empty($_POST['shuling'])||$_POST['shuling']==''){$_POST['shuling']=1;}
if(count($usertrack)<1){
    $a=$mysql_xd314->increase('pre_usertrack'," SET chpid='".$_POST['tid']."',chpshuliang='".$_POST['shuling']."',dizhi='".$_POST['dizhi']."',beizhu='".$_POST['beizhu']."',openid='".$_POST['openid']."',time='".time()."',tuiguang='".$_POST['tuiguang']."',state=0,chpname='".$chpk['title']."',chpjiage='".$chpk['jiage']."',x2='2',chptubiao='".$chpk['tubiao']."'");
}else{
$a=$mysql_xd314->modify('pre_usertrack'," SET chpshuliang='".$_POST['shuling']."',dizhi='".$_POST['dizhi']."',beizhu='".$_POST['beizhu']."' WHERE openid='".$_POST['openid']."' AND chpid='".$_POST['tid']."' AND  state=0");
}
//$a=$mysql_xd314->modify('pre_user'," SET name='".$_POST['name']."',phone='".$_POST['phone']."' WHERE openid='".$_POST['openid']."'");
$usertrack=$mysql_xd314->search('pre_usertrack'," WHERE openid='".$_POST['openid']."' AND chpid='".$_POST['tid']."' AND  NOT state=1 AND state1=0",' id,chpjiage,chpshuliang,state1 ')[0];
//$usertrack['chpjiage']=$chpk['jiage'];
echo json_encode(array('data'=>'ok','usertrack'=>$usertrack));
break;
case 'fsyonghu':
if(!empty($_POST['phone'])&&!empty($_POST['openid'])){
    $_POST['caidan']='yanzheng';
    $post_data=$_POST;
    $code=json_decode(send_post('https://www.axd-t.com/dysms/msg.php',$post_data),true);
    if($_POST['yanzheng']==$code){
$a=$mysql_xd314->modify('pre_user'," SET phone='".$_POST['phone']."' WHERE openid='".$_POST['openid']."'");
echo json_encode(array('state'=>'已绑定'));
}else{
    echo json_encode(array('state'=>'请填写验证码！')); 
}
}else{
    echo json_encode(array('state'=>'请填写完整！')); 
}
break;
default:
echo json_encode('参数缺失');
break;
}


function send_post($url, $post_data) {
    $postdata = http_build_query($post_data);
    $options = array(
      'http' => array(
        'method' => 'POST',
        'header' => 'Content-type:application/x-www-form-urlencoded',
        'content' => $postdata,
        'timeout' => 15 * 60 // 超时时间（单位:s）
      )
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    return $result;
  }
?>

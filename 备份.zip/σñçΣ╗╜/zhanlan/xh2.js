//鲜花展览系统js文件
//黄楼鲜花礼品 徐丹 2019.1.19
//alert(xd314.Cookie('openid'));

if (xd314.Cookie('openid') == 'undefined') { xd314.Href('https://axd-t.com/weixin/wx_index.php?state=xh2-' + xd314.GetState()); }
xd314.ShowInit();
  loading();
xd314.IdInit(["M12","yanzheng","M11","body", "M9", "M10", "M", "M2", "M4", "lis", "Mb", "M5", "M8", "M7","phone"]);
xd314.Id.body.onscroll = function () { reset(); };
xd314.Id.M4.style.height = xd314.Height * 60 / 100 + 'px';
xd314.Id.M8.style.height = document.body.clientHeight + 'px';
xd314.Id1('xiangqing').style.height = xd314.Height * 60 / 100 + 'px';
xd314.Id.M9.style.height = xd314.Height * 45 / 100 + 'px';
var conreset=1;
var x = 0;
var tid;
var product = [];
var track = [];
var user = [];
var pimg = [];
var scrolltop;
var fsong=0;
function conf() {
    xd314.DATA = {
        method: 'POST',
        url: 'https://www.axd-t.com/weixin/xd314_weixin.php',
        data: {
            caidan: 'access',
            cururl: window.location.href
        },                                         
        success: function (respone) {
            xdwx.Config();
        }
    };
    xd314.AJAX(xd314.DATA);
}

wx.ready(function () {
    sharepongyouquan();
       yigou();
});

function sharepongyouquan() {//product.title
    wx.onMenuShareTimeline({
        title: product.title+'（情人节倒计时！提前预定有优惠！！！）',
        link: 'https://axd-t.com/weixin/wx_index.php?state=xh2-' + product.tid + '-' + xd314.Cookie('openid')+'-0',
        imgUrl: 'https://www.axd-t.com/hl_img1/'+product.tubiao,
        success: function () { }
    });
    wx.onMenuShareAppMessage({
        title: product.title,
        desc: '黄楼鲜花礼品店（情人节倒计时！提前预定有优惠！！！）', 
        link: 'https://axd-t.com/weixin/wx_index.php?state=xh2-' + product.tid + '-' + xd314.Cookie('openid')+'-0',
        imgUrl: 'https://www.axd-t.com/hl_img1/'+product.tubiao,
        success: function () { }

    });
}

function FanKuiTuiSong() {
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    xd314.DATA.data = {
        caidan: 'FanKuiTuiSong',
        openid: xd314.Cookie('openid')
    };
    xd314.DATA.success = function (respone) {
        track=respone.track;
        if (xd314.Cookie('func') == 1) {
            if(respone.data!=''&&respone.data!=undefined){
                xd314.Id.yigou.style.display = "block";
                xd314.Id.yigou.style.opacity = 0;
            }
        }else if (xd314.Cookie('func') == 2){
            if(respone.data!=''&&respone.data!=undefined){
                xd314.Id.yigou.style.display = "block";
                xd314.Id.yigou.style.opacity = 0;
            }
        yigou();
        }else{
            if(respone.data!=''&&respone.data!=undefined){
                if(track.state1<1){  xd314.Id1('Ma').innerHTML = respone.data;xd314.Id.M.style.display = "block";}
           // xd314.Id.yigou.style.display = "block";
           // xd314.Id.yigou.style.opacity = 0;
            }
        }
    };
    xd314.AJAX(xd314.DATA);
}

function deletrack(a){
    if (confirm("您确定取消么？")) {
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    xd314.DATA.data = {
    caidan: 'deletrack',
    zid:a,
    openid: xd314.Cookie('openid')
    };
    xd314.DATA.success = function (respone) {
        alert(respone.state);
       // setTimeout(yigou(), 2 * 1000 );
        yigou();
    };
    xd314.AJAX(xd314.DATA);
    }
}

function whetherxz(a){
        xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
        xd314.DATA.data = {
        caidan: 'whetherxz',
        zid:a,
        openid: xd314.Cookie('openid')
        };
        xd314.DATA.success = function (respone) {
            //alert(respone.state);
            // setTimeout(yigou(), 2 * 1000 );
            yigou();
        };
        xd314.AJAX(xd314.DATA);
}

function loading(){
    xd314.Show('<div class="column" style=" display: flex;justify-content: center;"><div class="container animation-1"><div class="shape shape1"></div><div class="shape shape2"></div><div class="shape shape3"></div><div class="shape shape4"></div></div></div>','33%',false);
}

window.onload = function () {
    if (xd314.GetState() == 'undefined') {
        tid = 277;
    } else {
        tid = xd314.GetState();
    }
    conf();
}


function yigou(){
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    xd314.DATA.data = {
    caidan: 'yigou',
    openid: xd314.Cookie('openid')
    };
    xd314.DATA.success = function (respone) {
        data = respone.data;
       // alert(data);console.log(respone);
        var htm = xd314.Id1('xiangqing');
        var htm1 = xd314.Id.M7;
        if(data!='no'){
        var state;
        var zshuliang=0;
        var zjiage=0;
        for (var i = 0; i < data.length; i++) {
           if(data[i].x2!=1&&data[i].state1==0){
            zshuliang=zshuliang+parseFloat(data[i].chpshuliang);
            zjiage=zjiage+(data[i].jiage*data[i].chpshuliang);
           }
        }
        
        
            if(zjiage==0){
                htm1.innerHTML=' <div class="M7a" style="background:white;"><div   style="color:#FF9797;text-align:center;">总价格：'+zjiage+'</div><div style="color:white;width:100px;font-size:20px;background:#FF9797"  onclick="javascript:alert(\'请选择需要支付的产品！\');">支付</div></div>';
            }else{
            htm1.innerHTML=' <div class="M7a" style="background:white;"><div   style="color:#FF9797;text-align:center;">总价格：'+zjiage+'</div><div style="color:white;width:100px;font-size:20px;background:#FF5151"  onclick="pay1()">支付</div></div>';
            }
        
        htm.innerHTML='';
        for (var i = 0; i < data.length; i++) {
            if(data[i].state1==0){//用户已下单
                state='已提交订单！<br/>请点支付之后才可以提供商品服务！';
            }else if(data[i].state1==1){//用户已支付
                state='已支付，请等待商家制作！';
            }else if(data[i].state1==2){//商家确定完成
                state='已支付<br/>已完成订单<br/>请查看是否收到货物！如果收到请点击<span style="color:#FF9797;" onclick="shezhiliucheng(\''+data[i].id+'\',3)">此处</span>确定收到！';
            }else if(data[i].state1==3){//用户确定收货
                state='已支付<br/>已完成订单<br/>请点击<span style="color:#FF9797;" onclick="tucao1()">此处</span>给个评价或者建议吧！非常感谢!';
            }else if(data[i].state1==4){//用户已评价
                state='已支付<br/>已完成订单<br/>已评价，感谢了！';
            }
            htm.innerHTML = htm.innerHTML + '<div id="a' + data[i].id + '"  class="yigou"><img class="yigouimg"  src="https://www.axd-t.com/hl_img1/' + data[i].tubiao + '"></img><br/><span class="yigoufont">' + data[i].title + '</span><br/>价格：' + data[i].jiage + '数量：' + data[i].chpshuliang + '<br/>地址：' + data[i].dizhi + '<br/>备注：' + data[i].beizhu+'<br/>时间：' + data[i].time + '<br/>'+state;
            if(data[i].state1<1){
                if(data[i].x2==1){
                htm.innerHTML = htm.innerHTML + '<div style="width:100%;height:40px;line-height:40px;color:#FF9797;text-align:right;background:white;position: relative;"><div id="xz'+data[i].id+'" style="position:absolute;top:-240px;right:0%;border:1px solid #FF5151;width:30px;height:30px;line-height:30px;border-radius:15px;background:white;margin:5px;" onclick="whetherxz(\'' + data[i].id + '\')">✔︎</div><span style="margin:8px;color:#FF9797;" onclick="deletrack(\'' + data[i].id + '\')">取消订单</span><span  style="margin:8px;color:#FF9797;" onclick="now(\'' + data[i].chpid + '\',1)">修改订单</span></div>';
                }else{
                    htm.innerHTML = htm.innerHTML + '<div style="width:100%;height:40px;line-height:40px;color:#FF9797;text-align:right;background:white;position: relative;"><div id="xz'+data[i].id+'" style="position:absolute;top:-240px;right:0%;border:1px solid #FF5151;width:30px;height:30px;line-height:30px;border-radius:15px;background:#FF5151;margin:5px;" onclick="whetherxz(\'' + data[i].id + '\')">✔︎</div><span style="margin:8px;color:#FF9797;" onclick="deletrack(\'' + data[i].id + '\')">取消订单</span><span  style="margin:8px;color:#FF9797;" onclick="now(\'' + data[i].chpid + '\',1)">修改订单</span></div>';
                }
            }
            htm.innerHTML = htm.innerHTML + '</div>';
        }
            htm.innerHTML = htm.innerHTML + ' <div style="width:100%;height:90px;"></div>';
        }else{htm.innerHTML = '<div style="width:100%;text-align:center;color:#FF9797;">还没有订单！';htm1.innerHTML='';}
       xd314.HideShow();
    };
    xd314.AJAX(xd314.DATA);
}

function tucao1() {
     conreset=0;
   xd314.Id.M12.style.display = 'block';
}

function tucao() {
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    xd314.DATA.data = {
    caidan: 'tucao',
    tucao:xd314.Id1('tucao').value,
    trackid:track.id,
    openid: xd314.Cookie('openid')
    };
    xd314.DATA.success = function (respone) {
        alert(respone.state);
        xd314.Id.M12.style.display = 'none';
        yigou();
    };
    xd314.AJAX(xd314.DATA);
}

function yhxinxi(){
    if (xd314.Id.M11.style.display = 'none') {
        loading();
        xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
        xd314.DATA.data = {
            caidan: 'yhxinxi',
            openid: xd314.Cookie('openid'),
            access_t:xd314.Cookie('access_t')
        };
        xd314.DATA.success = function (respone) {
            xd314.Id.phone.value = respone.data.phone;
            xd314.Id.M11.style.display = 'block';
            xd314.HideShow();
        };
        xd314.AJAX(xd314.DATA);
    } else {
        xd314.Id.M11.style.display = 'none';
    }
}



function shezhiliucheng(trackid,sta) {//设置流程
    if(trackid==0){trackid=track.id;}
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
            xd314.DATA.data = {
                caidan: 'shezhiliucheng',
                trackid: trackid,
                state:sta
            };
            xd314.DATA.success = function (respone) {
                alert('已完成订单！');
                reset();
                yigou();
            };
            xd314.AJAX(xd314.DATA);
}

function fsyonghu() {
    xd314.DATA.url = 'https://www.axd-t.com/zhanlan/xh.php';
    if (xd314.Cookie('openid') != 'undefined') {
        if(xd314.Id.phone.value.length==0){
            alert('请填写手机号！');
        }else if(xd314.Id.yanzheng.value.length==0){
            alert('请填写验证码！');
        }else{
            xd314.DATA.data = {
                caidan: 'fsyonghu',
                phone: xd314.Id.phone.value,
                yanzheng: xd314.Id.yanzheng.value,
                openid: xd314.Cookie('openid')
            };
            xd314.DATA.success = function (respone) {
                xd314.Show('<div   style="background:#003E3E;">'+respone.state+'</div>');
                if(respone.state=='已绑定'){
                    xd314.Id1('phone').value=xd314.Id.phone.value;
                }
               xd314.Id.M11.style.display = 'none';
            };
            xd314.AJAX(xd314.DATA);
        }
    } else {
        alert('未登录！');
    }
}

function fsyanzheng() {
xd314.DATA.url = 'https://www.axd-t.com/dysms/msg.php';
xd314.DATA.data = {
    caidan: 'fasong',
    phone: xd314.Id.phone.value
};
xd314.DATA.success = function (respone) {
    xd314.Show('<div  style="background:#003E3E;">'+respone.date.Message+'</div>');
    xd314.Id1('yzhm').style.color="white";xd314.Id1('yzhm').onclick='';var i=60;var timer=setInterval(function(){xd314.Id1('yzhm').innerHTML="重新发送("+i+")";i=i-1;
   if(i==0){
clearInterval(timer);
xd314.Id1('yzhm').innerHTML="发送手机验证码！";
xd314.Id1('yzhm').style.color="#FF9797";
xd314.Id1('yzhm').addEventListener('click',fsyanzheng,false);
    }
    },1000);
};
xd314.AJAX(xd314.DATA);
}



function now(pg, func = 0) {
    xd314.Href('https://axd-t.com/weixin/wx_index.php?state=xh1-' + pg + '--' + func);
}



function nlist() {
   
}

function scroll() {
    xd314.Id.body.scrollTop = scrolltop;
}

function article() {
    if (xd314.Id.M5.style.display == "block") {
        xd314.Id.M5.style.display = "none";
        xd314.Id.M8.style.display = "none";
        xd314.Id.M2.style.display = "block";
        xd314.Id.Mb.innerHTML = "相关信息";
        xd314.Id.Mb.style.opacity = 0.9;
    } else {
        reset();
        xd314.Id.Mb.style.opacity = 0;
        xd314.Id.Mb.innerHTML = "收起";
        xd314.Id.M5.style.display = "block";
        xd314.Id.M5.innerHTML = "";
        xr2();
    }
}

function article1(ti) {
 
}

function reset() {
    if(conreset==1){
  //  xd314.Id.lis.innerHTML = "目录";
  //  xd314.Id.yigou.style.opacity = 0.9;
    xd314.Id.lis.style.opacity = 0.9;
    xd314.Id.Mb.innerHTML = "相关信息";
    xd314.Id.Mb.style.opacity = 1;
    xd314.Id.M4.style.display = 'none';
    xd314.Id.M5.style.display = "none";
   // xd314.Id.wych.style.opacity = 0.9;
    xd314.Id.M9.style.display = "none";
    xd314.Id.M8.style.display = "none";
    xd314.Id.body.onscroll = '';
    xd314.Id.M.style.display = "none";
    xd314.Id.M12.style.display = 'none';
    fsong=0;
    xd314.Id.M11.style.display = 'none';
}else{
    conreset=1;
}
    xd314.HideShow();
}


function pay(chpid, jiage, shuliang) {
    jiage = jiage * shuliang;
    xd314.Href('https://axd-t.com/weixin/wx_index.php?state=pay-' + jiage + '-' + xd314.Cookie('openid') + '-' + chpid, true);
}
function pay1(){
    xd314.Href('https://axd-t.com/weixin/wx_index.php?state=zpay-0-' + xd314.Cookie('openid') + '-0', true);
}


function xiangqing(data) {
   
}

function xr1(data) {
    for (var i = 0; i < data.length; i++) {
        var htm = xd314.Id.M4;
        if (tid == data[i].tid) {
            htm.innerHTML = htm.innerHTML + '<div id="' + data[i].tid + '"  class="chanpin"  style="width:100%;margin-top:12px;font-size:15px;border-bottom:1px  solid  white;display: flex;align-items:center;"    onclick="now(' + data[i].tid + ')"><img style="width:100px;height:100px;margin-right:8px;" src="https://www.axd-t.com/hl_img1/' + data[i].tubiao + '"></img><span style="margin:8px;color:#FF9797;">' + data[i].title + '</span></div>';
        } else {
            htm.innerHTML = htm.innerHTML + '<div  id="' + data[i].tid + '"   class="chanpin"     style="width:100%;margin-top:12px;font-size:15px;border-bottom:1px  solid  white;display: flex;align-items:center;"    onclick="now(' + data[i].tid + ')"><img style="width:100px;height:100px;" src="https://www.axd-t.com/hl_img1/' + data[i].tubiao + '"></img><span style="margin:8px;">' + data[i].title + '</span></div>';
        }
    }
    xd314.Id.M4.scrollTop = xd314.Id1(tid).offsetTop - xd314.Id.M4.style.height.split('px')[0] + 60;
}

function xr2(data) {
    var htm = xd314.Id.M5;
    htm.innerHTML = htm.innerHTML + '<div  style="margin:15px;font-size:18px;border-bottom:0px  solid  white;text-align:center;"  onclick="xd314.Href(\'https://axd-t.com/weixin/wx_index.php?state=xh\')">进入首页</div>';
}

